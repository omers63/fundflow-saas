<div class="space-y-2">
    @foreach($getState() as $check)
    <div class="flex items-center gap-3 p-3 rounded-lg border {{ $check['pass'] ? 'border-success-200 bg-success-50' : 'border-danger-200 bg-danger-50' }}">
        @if($check['pass'])
            <x-heroicon-o-check-circle class="w-5 h-5 text-success-500 flex-shrink-0"/>
        @else
            <x-heroicon-o-x-circle class="w-5 h-5 text-danger-500 flex-shrink-0"/>
        @endif
        <span class="flex-1 text-sm font-medium {{ $check['pass'] ? 'text-success-800' : 'text-danger-800' }}">{{ $check['label'] }}</span>
        <span class="text-xs text-gray-500">{{ $check['detail'] }}</span>
    </div>
    @endforeach
</div>
