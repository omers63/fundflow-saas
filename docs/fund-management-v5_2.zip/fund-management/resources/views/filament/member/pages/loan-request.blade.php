<x-filament-panels::page>
@php
    $member  = auth()->user();
    $config  = \App\Models\SystemConfig::current();
    $checks  = [
        ['label'=>'Membership tenure',    'pass'=>$member->tenure_years >= $config->min_membership_years, 'detail'=>$member->tenure_years.' yrs — min '.$config->min_membership_years,'required'=>true],
        ['label'=>'Fund balance',          'pass'=>$member->fund_balance >= $config->min_fund_balance,     'detail'=>'SAR '.number_format($member->fund_balance,0).' — min SAR '.number_format($config->min_fund_balance,0),'required'=>true],
        ['label'=>'No delinquency',        'pass'=>!in_array($member->status->value,['delinquent','suspended']),'detail'=>'Status: '.$member->status->getLabel(),'required'=>true],
        ['label'=>'Active loan count',     'pass'=>$member->activeLoans()->count() < $config->max_active_loans,'detail'=>$member->activeLoans()->count().' active — max '.$config->max_active_loans,'required'=>true],
        ['label'=>'Borrow limit available','pass'=>$member->borrow_cap > 0,'detail'=>'Max SAR '.number_format($member->borrow_cap,0),'required'=>true],
        ['label'=>'Guarantor available',   'pass'=>true,'detail'=>'Must be named in step 3','required'=>false],
    ];
    $allPass = collect($checks)->where('required',true)->every(fn($c)=>$c['pass']);
@endphp

<div x-data="{
    step: 1,
    loanType: 'standard',
    amount: '',
    graceCycles: 0,
    purpose: '',
    guarantorId: '',
    scheduleOption: 'rollup',
    emiTier() {
        const a = parseFloat(this.amount) || 0;
        if (a >= 1000 && a <= 10000) return { label: 'Tier 1', emi: 1000 };
        if (a >= 11000 && a <= 30000) return { label: 'Tier 2', emi: 1500 };
        if (a >= 31000 && a <= 60000) return { label: 'Tier 3', emi: 2500 };
        return { label: '—', emi: 0 };
    },
    threshold() {
        return (parseFloat(this.amount) || 0) * 1.05;
    },
    cycles() {
        const emi = this.emiTier().emi;
        if (!emi) return 0;
        return Math.ceil(this.threshold() / emi);
    }
}" class="space-y-6">

{{-- Step indicator --}}
<div class="flex items-center gap-0">
    @foreach([1=>'Eligibility',2=>'Loan details',3=>'Guarantor',4=>'Review & submit'] as $n=>$label)
    <div class="flex items-center {{ $n < 4 ? 'flex-1' : '' }}">
        <div class="flex items-center gap-2 flex-shrink-0">
            <div :class="step >= {{ $n }} ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-400'"
                 class="w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-colors">
                {{ $n }}
            </div>
            <span :class="step === {{ $n }} ? 'text-gray-900 font-medium' : 'text-gray-400'"
                  class="text-xs hidden sm:block transition-colors">{{ $label }}</span>
        </div>
        @if($n < 4)
        <div :class="step > {{ $n }} ? 'bg-primary-400' : 'bg-gray-200'"
             class="flex-1 h-px mx-3 transition-colors"></div>
        @endif
    </div>
    @endforeach
</div>

{{-- STEP 1: Eligibility --}}
<div x-show="step===1">
    @if($allPass)
    <div class="flex items-start gap-3 p-4 rounded-xl bg-success-50 border border-success-200 text-success-800 text-sm mb-4">
        <x-heroicon-o-check-circle class="w-5 h-5 text-success-500 flex-shrink-0 mt-0.5"/>
        All eligibility checks passed. You may proceed with your loan request.
    </div>
    @else
    <div class="flex items-start gap-3 p-4 rounded-xl bg-danger-50 border border-danger-200 text-danger-800 text-sm mb-4">
        <x-heroicon-o-x-circle class="w-5 h-5 text-danger-500 flex-shrink-0 mt-0.5"/>
        Some eligibility checks failed. An admin override is required to proceed.
    </div>
    @endif

    <x-filament::section heading="Eligibility checks">
        <div class="divide-y divide-gray-100">
            @foreach($checks as $check)
            <div class="flex items-center gap-3 py-3">
                @if($check['pass'])
                    <x-heroicon-o-check-circle class="w-5 h-5 text-success-500 flex-shrink-0"/>
                @elseif($check['required'])
                    <x-heroicon-o-x-circle class="w-5 h-5 text-danger-500 flex-shrink-0"/>
                @else
                    <x-heroicon-o-information-circle class="w-5 h-5 text-gray-400 flex-shrink-0"/>
                @endif
                <span class="flex-1 text-sm font-medium">{{ $check['label'] }}</span>
                <span class="text-xs text-gray-400">{{ $check['detail'] }}</span>
            </div>
            @endforeach
        </div>
    </x-filament::section>

    <div class="flex justify-end mt-4">
        <button @click="{{ $allPass ? 'step=2' : '' }}" {{ !$allPass ? 'disabled' : '' }}
            class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed">
            Continue <x-heroicon-m-arrow-right class="w-4 h-4"/>
        </button>
    </div>
</div>

{{-- STEP 2: Loan details --}}
<div x-show="step===2" x-cloak>
    <x-filament::section heading="Loan details">
        <div class="grid grid-cols-2 gap-5 mb-5">
            <div>
                <label class="text-xs font-medium text-gray-600 block mb-1.5">Loan type</label>
                <select x-model="loanType" class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400">
                    <option value="standard">Standard</option>
                    <option value="emergency">Emergency</option>
                </select>
            </div>
            <div>
                <label class="text-xs font-medium text-gray-600 block mb-1.5">
                    Requested amount (SAR) — max SAR {{ number_format($member->borrow_cap,0) }}
                </label>
                <input type="number" x-model="amount" min="1000" max="{{ $member->borrow_cap }}"
                    placeholder="e.g. 15000"
                    class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400"/>
            </div>
            <div>
                <label class="text-xs font-medium text-gray-600 block mb-1.5">EMI tier (auto-assigned)</label>
                <input type="text" :value="emiTier().label + ' — SAR ' + emiTier().emi.toLocaleString() + '/cycle'" readonly
                    class="w-full text-sm px-3 py-2.5 border border-gray-100 bg-gray-50 rounded-xl text-gray-500"/>
            </div>
            <div>
                <label class="text-xs font-medium text-gray-600 block mb-1.5">Grace period</label>
                <select x-model="graceCycles" class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400">
                    <option value="0">0 cycles — start immediately</option>
                    <option value="1">1 cycle grace</option>
                    <option value="2">2 cycles grace</option>
                </select>
            </div>
            <div class="col-span-2">
                <label class="text-xs font-medium text-gray-600 block mb-1.5">Purpose (optional)</label>
                <textarea x-model="purpose" rows="2" placeholder="Brief description of how funds will be used…"
                    class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400 resize-none"></textarea>
            </div>
        </div>

        {{-- Live loan summary --}}
        <div class="bg-gray-50 rounded-xl p-4 text-sm">
            <div class="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-3">Loan summary</div>
            <div class="space-y-2">
                <div class="flex justify-between"><span class="text-gray-500">Requested amount</span><span x-text="'SAR ' + (parseFloat(amount)||0).toLocaleString()"></span></div>
                <div class="flex justify-between"><span class="text-gray-500">Member fund portion</span><span x-text="'SAR ' + Math.min(parseFloat(amount)||0, {{ $member->fund_balance }}).toLocaleString()"></span></div>
                <div class="flex justify-between"><span class="text-gray-500">Master fund portion</span><span x-text="'SAR ' + Math.max(0,(parseFloat(amount)||0) - {{ $member->fund_balance }}).toLocaleString()"></span></div>
                <div class="flex justify-between"><span class="text-gray-500">Repayment threshold (5%)</span><span x-text="'SAR ' + threshold().toLocaleString(undefined,{maximumFractionDigits:0})"></span></div>
                <div class="flex justify-between"><span class="text-gray-500">EMI per cycle</span><span x-text="'SAR ' + emiTier().emi.toLocaleString()"></span></div>
                <div class="flex justify-between font-medium border-t border-gray-200 pt-2 mt-2"><span>Estimated cycles</span><span x-text="cycles() + ' cycles'"></span></div>
            </div>
        </div>
    </x-filament::section>

    <div class="flex justify-between mt-4">
        <button @click="step=1" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50">
            <x-heroicon-m-arrow-left class="w-4 h-4"/>Back
        </button>
        <button @click="step=3" :disabled="!amount || emiTier().emi===0"
            class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700 disabled:opacity-50">
            Continue <x-heroicon-m-arrow-right class="w-4 h-4"/>
        </button>
    </div>
</div>

{{-- STEP 3: Guarantor --}}
<div x-show="step===3" x-cloak>
    <x-filament::section heading="Guarantor details">
        <div class="flex items-start gap-3 p-3 mb-5 rounded-xl bg-info-50 border border-info-200 text-info-800 text-sm">
            <x-heroicon-o-information-circle class="w-5 h-5 text-info-500 flex-shrink-0 mt-0.5"/>
            <span>Your guarantor must be an active member in good standing with no active delinquency.
            They will be notified once you submit this request. By submitting, your guarantor agrees to be liable
            for the master fund portion plus 5% settlement threshold if you miss 6 consecutive EMIs.</span>
        </div>
        <div class="grid grid-cols-2 gap-5">
            <div>
                <label class="text-xs font-medium text-gray-600 block mb-1.5">Guarantor member ID</label>
                <input type="text" x-model="guarantorId" placeholder="e.g. #1038"
                    class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400"/>
            </div>
            <div>
                <label class="text-xs font-medium text-gray-600 block mb-1.5">Guarantor name (auto-filled on ID entry)</label>
                <input type="text" placeholder="Will fill after ID entry" readonly
                    class="w-full text-sm px-3 py-2.5 border border-gray-100 bg-gray-50 rounded-xl text-gray-400"/>
            </div>
        </div>
    </x-filament::section>

    <div class="flex justify-between mt-4">
        <button @click="step=2" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50">
            <x-heroicon-m-arrow-left class="w-4 h-4"/>Back
        </button>
        <button @click="step=4" :disabled="!guarantorId"
            class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700 disabled:opacity-50">
            Continue <x-heroicon-m-arrow-right class="w-4 h-4"/>
        </button>
    </div>
</div>

{{-- STEP 4: Review & submit --}}
<div x-show="step===4" x-cloak>
    <div class="flex items-start gap-3 p-4 rounded-xl bg-success-50 border border-success-200 text-success-800 text-sm mb-4">
        <x-heroicon-o-check-circle class="w-5 h-5 text-success-500 flex-shrink-0 mt-0.5"/>
        All eligibility checks passed. Your request will be placed in the approval queue and processed in order.
        Emergency requests are prioritised at the front of the queue.
    </div>

    <x-filament::section heading="Request summary">
        <div class="bg-gray-50 rounded-xl p-4 space-y-2 text-sm mb-4">
            <div class="flex justify-between"><span class="text-gray-500">Loan type</span><span x-text="loanType.charAt(0).toUpperCase()+loanType.slice(1)"></span></div>
            <div class="flex justify-between"><span class="text-gray-500">Amount</span><span x-text="'SAR ' + (parseFloat(amount)||0).toLocaleString()"></span></div>
            <div class="flex justify-between"><span class="text-gray-500">Grace period</span><span x-text="graceCycles + ' cycle' + (graceCycles==1?'':'s')"></span></div>
            <div class="flex justify-between"><span class="text-gray-500">EMI per cycle</span><span x-text="'SAR ' + emiTier().emi.toLocaleString()"></span></div>
            <div class="flex justify-between"><span class="text-gray-500">Repayment threshold</span><span x-text="'SAR ' + threshold().toLocaleString(undefined,{maximumFractionDigits:0})"></span></div>
            <div class="flex justify-between"><span class="text-gray-500">Estimated cycles</span><span x-text="cycles()"></span></div>
            <div class="flex justify-between font-medium border-t border-gray-200 pt-2 mt-1"><span>Guarantor</span><span x-text="'Member ' + guarantorId"></span></div>
        </div>
    </x-filament::section>

    <div class="flex justify-between mt-4">
        <button @click="step=3" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50">
            <x-heroicon-m-arrow-left class="w-4 h-4"/>Back
        </button>
        <button class="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700">
            <x-heroicon-m-paper-airplane class="w-4 h-4"/>Submit loan request
        </button>
    </div>
</div>

</div>
</x-filament-panels::page>
