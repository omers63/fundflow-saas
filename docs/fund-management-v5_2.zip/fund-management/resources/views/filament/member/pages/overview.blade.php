<x-filament-panels::page>
@php
    $member = auth()->user();
    $activeLoan = $member->activeLoans()->with(['emiCycles','guarantor'])->first();
    $nextEmi = $activeLoan?->emiCycles()->where('status','pending')->orderBy('cycle_month')->first();
    $daysUntil = $nextEmi ? \Carbon\Carbon::parse($nextEmi->cycle_month)->diffInDays(now(), false) : null;
@endphp

{{-- Amber notice: upcoming EMI --}}
@if($nextEmi && $daysUntil !== null && $daysUntil <= 7)
<div class="flex items-start gap-3 p-4 mb-6 rounded-xl bg-warning-50 border border-warning-200 text-warning-800 text-sm">
    <x-heroicon-o-clock class="w-5 h-5 flex-shrink-0 mt-0.5 text-warning-500"/>
    <span>Your next EMI of <strong>SAR {{ number_format($activeLoan->emi_amount,2) }}</strong> is due in
    <strong>{{ max(0, (int)\Carbon\Carbon::parse($nextEmi->cycle_month)->startOfMonth()->diffInDays(now(),false) * -1) }} days</strong>
    ({{ \Carbon\Carbon::parse($nextEmi->cycle_month)->format('1 M Y') }}).
    Ensure your cash account is funded before the debit date.</span>
</div>
@endif

{{-- Account balance cards --}}
<div class="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-6">
    {{-- Cash account card --}}
    <div class="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
        <div class="flex items-center gap-2 text-xs font-semibold text-gray-500 uppercase tracking-widest mb-2">
            <x-heroicon-o-wallet class="w-4 h-4"/>Cash account
        </div>
        <div class="text-3xl font-semibold text-gray-900 mb-1">SAR {{ number_format($member->cash_balance,2) }}</div>
        <div class="text-xs text-gray-400 mb-4">Available balance</div>
        <div class="flex gap-2 flex-wrap">
            <a href="{{ route('filament.member.pages.cash-account') }}"
               class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 text-xs text-gray-600 hover:bg-gray-50">
                <x-heroicon-m-arrow-down-left class="w-3.5 h-3.5"/>Deposit
            </a>
            <a href="{{ route('filament.member.pages.cash-out') }}"
               class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 text-xs text-gray-600 hover:bg-gray-50">
                <x-heroicon-m-banknotes class="w-3.5 h-3.5"/>Cash out
            </a>
            <a href="{{ route('filament.member.pages.transactions') }}"
               class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 text-xs text-gray-600 hover:bg-gray-50">
                <x-heroicon-m-clock class="w-3.5 h-3.5"/>History
            </a>
        </div>
    </div>

    {{-- Fund account card (purple) --}}
    <div class="border border-purple-200 rounded-2xl p-5 shadow-sm" style="background:linear-gradient(135deg,#EEEDFE,#DDD9FC)">
        <div class="flex items-center gap-2 text-xs font-semibold text-purple-600 uppercase tracking-widest mb-2">
            <x-heroicon-o-building-library class="w-4 h-4"/>Fund account
        </div>
        <div class="text-3xl font-semibold text-purple-800 mb-1">SAR {{ number_format($member->fund_balance,2) }}</div>
        <div class="text-xs text-purple-500 mb-4">Accumulated contributions · loan cap: SAR {{ number_format($member->borrow_cap,0) }}</div>
        <div class="flex gap-2">
            <a href="{{ route('filament.member.pages.fund-account') }}"
               class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-purple-300 text-xs text-purple-700 hover:bg-purple-100">
                <x-heroicon-m-chart-bar class="w-3.5 h-3.5"/>History
            </a>
            <a href="{{ route('filament.member.pages.statements') }}"
               class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-purple-300 text-xs text-purple-700 hover:bg-purple-100">
                <x-heroicon-m-document-text class="w-3.5 h-3.5"/>Statement
            </a>
        </div>
    </div>
</div>

{{-- Active loan panel + Quick actions --}}
<div class="grid grid-cols-1 lg:grid-cols-5 gap-5 mb-6">
    {{-- Active loan panel (3/5) --}}
    <div class="lg:col-span-3">
        <x-filament::section heading="Active loan">
            @if($activeLoan)
                <div class="flex justify-between items-baseline mb-3">
                    <div>
                        <div class="text-2xl font-semibold">SAR {{ number_format($activeLoan->requested_amount,2) }}</div>
                        <div class="text-xs text-gray-400 mt-0.5">{{ $activeLoan->loan_number }} · Tier B · EMI SAR {{ number_format($activeLoan->emi_amount,2) }}/cycle</div>
                    </div>
                    <span class="text-xs bg-success-100 text-success-700 px-2 py-1 rounded-full font-medium">In repayment</span>
                </div>

                {{-- Progress bar --}}
                <div class="w-full bg-gray-100 rounded-full h-2 mb-1">
                    <div class="bg-success-500 h-2 rounded-full transition-all" style="width:{{ $activeLoan->repaid_percent }}%"></div>
                </div>
                <div class="flex justify-between text-xs text-gray-400 mb-4">
                    <span>SAR {{ number_format($activeLoan->total_repaid,2) }} repaid ({{ $activeLoan->repaid_percent }}%)</span>
                    <span>SAR {{ number_format($activeLoan->remaining_threshold,2) }} remaining</span>
                </div>

                {{-- Detail chips --}}
                <div class="grid grid-cols-3 gap-3 mb-4">
                    @foreach([
                        ['EMIs completed', $activeLoan->emiCycles->where('status','collected')->count().' of '.$activeLoan->emiCycles->count()],
                        ['Threshold', 'SAR '.number_format($activeLoan->settlement_threshold,0)],
                        ['Guarantor', $activeLoan->guarantor?->name ?? '—'],
                    ] as [$lbl,$val])
                    <div class="bg-gray-50 rounded-xl p-3">
                        <div class="text-xs text-gray-400 mb-0.5">{{ $lbl }}</div>
                        <div class="text-sm font-semibold">{{ $val }}</div>
                    </div>
                    @endforeach
                </div>

                {{-- Next EMI cell --}}
                @if($nextEmi)
                <div class="flex items-center justify-between bg-gray-50 rounded-xl p-3 mb-4">
                    <div>
                        <div class="text-xs text-gray-400">Next EMI due</div>
                        <div class="text-sm font-semibold">{{ \Carbon\Carbon::parse($nextEmi->cycle_month)->format('1 M Y') }}</div>
                    </div>
                    <div class="text-base font-semibold text-primary-700">SAR {{ number_format($activeLoan->emi_amount,2) }}</div>
                </div>
                @endif

                {{-- Settle buttons --}}
                <div class="flex gap-3">
                    <a href="{{ route('filament.member.pages.my-loans') }}"
                       class="flex-1 text-center text-sm py-2 px-4 rounded-xl border border-gray-200 hover:bg-gray-50 transition-colors">
                        Partial settle
                    </a>
                    <a href="{{ route('filament.member.pages.my-loans') }}"
                       class="flex-1 text-center text-sm py-2 px-4 rounded-xl border border-primary-300 text-primary-700 hover:bg-primary-50 transition-colors">
                        Full settle
                    </a>
                </div>
            @else
                <div class="text-center py-8 text-gray-400">
                    <x-heroicon-o-currency-dollar class="w-10 h-10 mx-auto mb-2"/>
                    <p class="text-sm">No active loans.</p>
                    <a href="{{ route('filament.member.pages.loan-request') }}" class="text-sm text-primary-600 hover:underline mt-1 inline-block">Request a loan →</a>
                </div>
            @endif
        </x-filament::section>
    </div>

    {{-- Quick actions (2/5) --}}
    <div class="lg:col-span-2">
        <x-filament::section heading="Quick actions">
            @php $actions = [
                ['icon'=>'heroicon-o-arrow-down-left','bg'=>'bg-success-50','color'=>'text-success-600','title'=>'Deposit funds','sub'=>'Bank transfer or direct cash','url'=>route('filament.member.pages.cash-account')],
                ['icon'=>'heroicon-o-document-text','bg'=>'bg-primary-50','color'=>'text-primary-600','title'=>'Request a loan','sub'=>'Max: SAR '.number_format($member->borrow_cap,0),'url'=>route('filament.member.pages.loan-request')],
                ['icon'=>'heroicon-o-banknotes','bg'=>'bg-info-50','color'=>'text-info-600','title'=>'Cash out','sub'=>'Available: SAR '.number_format($member->cash_balance,0),'url'=>route('filament.member.pages.cash-out')],
                ['icon'=>'heroicon-o-arrow-down-tray','bg'=>'bg-warning-50','color'=>'text-warning-600','title'=>'Download statement','sub'=>'Cash, fund, or loan history','url'=>route('filament.member.pages.statements')],
            ]; @endphp
            <div class="space-y-2">
                @foreach($actions as $a)
                <a href="{{ $a['url'] }}" class="flex items-center gap-3 p-3 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                    <div class="w-9 h-9 rounded-xl {{ $a['bg'] }} flex items-center justify-center flex-shrink-0">
                        <x-dynamic-component :component="$a['icon']" class="w-5 h-5 {{ $a['color'] }}"/>
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="text-sm font-medium">{{ $a['title'] }}</div>
                        <div class="text-xs text-gray-400 truncate">{{ $a['sub'] }}</div>
                    </div>
                    <x-heroicon-m-chevron-right class="w-4 h-4 text-gray-300 flex-shrink-0"/>
                </a>
                @endforeach
            </div>
        </x-filament::section>
    </div>
</div>

{{-- Recent transactions --}}
<x-filament::section heading="Recent transactions">
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="text-xs text-gray-400 border-b border-gray-100">
                <tr>
                    <th class="py-2 text-left">Description</th>
                    <th class="py-2 text-left">Date</th>
                    <th class="py-2 text-right">Credit</th>
                    <th class="py-2 text-right">Debit</th>
                    <th class="py-2 text-left pl-3">Type</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
            @forelse(\App\Models\Transaction::where('member_id',$member->id)->latest('effective_date')->take(6)->get() as $t)
                <tr>
                    <td class="py-2.5 pr-4 text-gray-700">{{ $t->description }}</td>
                    <td class="py-2.5 pr-4 text-gray-400 text-xs whitespace-nowrap">{{ \Carbon\Carbon::parse($t->effective_date)->format('d M Y') }}</td>
                    <td class="py-2.5 pr-4 text-right font-medium {{ $t->cr_amount > 0 ? 'text-success-600' : 'text-gray-300' }}">
                        {{ $t->cr_amount > 0 ? '+SAR '.number_format($t->cr_amount,2) : '—' }}
                    </td>
                    <td class="py-2.5 pr-4 text-right font-medium {{ $t->dr_amount > 0 ? 'text-danger-600' : 'text-gray-300' }}">
                        {{ $t->dr_amount > 0 ? '−SAR '.number_format($t->dr_amount,2) : '—' }}
                    </td>
                    <td class="py-2.5 pl-3">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium bg-gray-100 text-gray-600">{{ $t->tag }}</span>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5" class="py-8 text-center text-gray-400">No transactions yet</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    <div class="mt-3 text-right">
        <a href="{{ route('filament.member.pages.transactions') }}" class="text-xs text-primary-600 hover:underline">View all transactions →</a>
    </div>
</x-filament::section>
</x-filament-panels::page>
