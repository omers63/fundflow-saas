<x-filament-panels::page>
@php $member = auth()->user(); @endphp

<div x-data="{ tab: 'profile' }" class="space-y-0">
{{-- Tab bar --}}
<div class="flex gap-0 border-b border-gray-200 mb-6">
    @foreach(['profile'=>'Profile','notifications'=>'Notifications','bank'=>'Bank details','security'=>'Security'] as $key=>$label)
    <button @click="tab='{{ $key }}'"
        :class="tab==='{{ $key }}' ? 'border-b-2 border-primary-600 text-primary-700 font-medium' : 'text-gray-400 hover:text-gray-600'"
        class="px-4 py-3 text-sm transition-colors border-b-2 border-transparent -mb-px">
        {{ $label }}
    </button>
    @endforeach
</div>

{{-- Profile tab --}}
<div x-show="tab==='profile'">
    <x-filament::section heading="Personal information">
        <form class="grid grid-cols-2 gap-5">
            <div><label class="text-xs font-medium text-gray-600 block mb-1.5">Full name</label>
            <input type="text" value="{{ $member->name }}" class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400"/></div>
            <div><label class="text-xs font-medium text-gray-600 block mb-1.5">Member ID</label>
            <input type="text" value="#{{ $member->id }}" readonly class="w-full text-sm px-3 py-2.5 border border-gray-100 bg-gray-50 rounded-xl text-gray-400"/></div>
            <div><label class="text-xs font-medium text-gray-600 block mb-1.5">Phone</label>
            <input type="tel" value="{{ $member->phone }}" class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400"/></div>
            <div><label class="text-xs font-medium text-gray-600 block mb-1.5">Email</label>
            <input type="email" value="{{ $member->email }}" class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400"/></div>
            <div class="col-span-2 flex justify-end pt-2 border-t border-gray-100">
                <button type="button" class="px-5 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700">Save changes</button>
            </div>
        </form>
    </x-filament::section>
</div>

{{-- Notifications tab --}}
<div x-show="tab==='notifications'" x-cloak>
    <x-filament::section heading="Notification preferences">
        <div class="divide-y divide-gray-100">
            @foreach([
                ['label'=>'EMI due reminder (6 days before)','default'=>'sms_email'],
                ['label'=>'Contribution debit notification','default'=>'sms_email'],
                ['label'=>'Late fee applied','default'=>'sms_email'],
                ['label'=>'Loan status updates','default'=>'sms_email'],
                ['label'=>'Deposit received','default'=>'email'],
            ] as $notif)
            <div class="flex items-center justify-between py-3.5">
                <span class="text-sm text-gray-700">{{ $notif['label'] }}</span>
                <select class="text-xs px-2.5 py-1.5 border border-gray-200 rounded-lg focus:outline-none focus:border-primary-400 bg-white">
                    <option value="sms_email" {{ $notif['default']==='sms_email'?'selected':'' }}>SMS + Email</option>
                    <option value="email" {{ $notif['default']==='email'?'selected':'' }}>Email only</option>
                    <option value="sms">SMS only</option>
                    <option value="off">Off</option>
                </select>
            </div>
            @endforeach
        </div>
        <div class="flex justify-end pt-3 border-t border-gray-100 mt-2">
            <button class="px-5 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700">Save preferences</button>
        </div>
    </x-filament::section>
</div>

{{-- Bank details tab --}}
<div x-show="tab==='bank'" x-cloak>
    <x-filament::section heading="Registered bank account">
        <x-slot name="headerActions">
            <button class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-primary-300 text-xs text-primary-700 hover:bg-primary-50">
                <x-heroicon-m-pencil class="w-3.5 h-3.5"/>Edit
            </button>
        </x-slot>
        <div class="grid grid-cols-2 gap-4 text-sm">
            @foreach(['Bank name'=>'Al Rajhi Bank','Account name'=>$member->name,'IBAN'=>'SA44 0000 1234 5678 9012','Verified'=>'✓ Verified'] as $lbl=>$val)
            <div class="py-2 border-b border-gray-50">
                <div class="text-xs text-gray-400 mb-0.5">{{ $lbl }}</div>
                <div class="font-medium {{ $lbl==='Verified' ? 'text-success-600' : '' }}">{{ $val }}</div>
            </div>
            @endforeach
        </div>
    </x-filament::section>
</div>

{{-- Security tab --}}
<div x-show="tab==='security'" x-cloak>
    <x-filament::section heading="Change password">
        <form class="space-y-4 max-w-md">
            <div><label class="text-xs font-medium text-gray-600 block mb-1.5">Current password</label>
            <input type="password" class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400"/></div>
            <div><label class="text-xs font-medium text-gray-600 block mb-1.5">New password</label>
            <input type="password" class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400"/></div>
            <div><label class="text-xs font-medium text-gray-600 block mb-1.5">Confirm new password</label>
            <input type="password" class="w-full text-sm px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400"/></div>
            <button type="button" class="px-5 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700">Update password</button>
        </form>
    </x-filament::section>
</div>
</div>
</x-filament-panels::page>
