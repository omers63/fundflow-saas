<x-filament-panels::page>
<x-filament::section heading="Frequently asked questions">
    @php
    $faqs = [
        ['q'=>'When is my contribution collected?','a'=>'Your contribution is auto-debited from your cash account on Day 1 of the collection window each month. If your balance is insufficient, a partial debit is posted and the remainder is collected when funds arrive. The window stays open for a configurable number of days before late fees begin.'],
        ['q'=>'Why am I exempt from contributions?','a'=>'Members with an active loan — including those in a grace period — are automatically exempt from the monthly contribution. This prevents double-charging. The exemption lifts in the cycle after your loan is fully repaid.'],
        ['q'=>'How is my loan repayment threshold calculated?','a'=>'Your loan is fully repaid when the master fund portion plus the settlement threshold percentage (5% of the original loan amount by default) has been repaid. You can see your specific threshold on the My Loans page.'],
        ['q'=>'What happens if I miss EMI payments?','a'=>'Missed EMIs follow the same late fee tiers as contributions. After a configured number of consecutive missed EMIs, your guarantor is formally notified. After a further threshold, the loan is transferred to your guarantor and your account is suspended pending admin review.'],
        ['q'=>'How do I partially settle my loan?','a'=>'Go to My Loans → Settle loan. Enter a partial amount (minimum 1 EMI) and choose whether to roll up your schedule (shortening it) or skip upcoming cycles (giving you a gap before EMIs resume). The updated schedule is shown before you confirm.'],
        ['q'=>'How do I add funds to my cash account?','a'=>'Go to Cash Account and use the Deposit form. You can deposit via bank transfer (IBAN) or direct cash. Bank transfers are credited once the bank import is matched — typically 1–2 business days. Direct cash deposits are credited immediately.'],
        ['q'=>'What is my guarantor responsible for?','a'=>'Your guarantor is responsible for the master fund portion of your loan plus the settlement threshold percentage, only if you miss the configured number of consecutive EMI payments. Their liability does not include your own fund equity portion.'],
        ['q'=>'How do I request a cash out?','a'=>'Go to Cash Out. You can withdraw up to your available balance (cash account balance minus any reserved EMI for the current cycle). Withdrawals are processed to your registered IBAN within 1–2 business days.'],
    ];
    @endphp

    <div class="divide-y divide-gray-100" x-data="{open:null}">
        @foreach($faqs as $i => $faq)
        <div class="py-3.5">
            <button type="button" @click="open = open === {{ $i }} ? null : {{ $i }}"
                class="flex justify-between items-center w-full text-left text-sm font-medium text-gray-800 focus:outline-none group">
                <span>{{ $faq['q'] }}</span>
                <x-heroicon-m-chevron-down
                    class="w-4 h-4 text-gray-400 transition-transform flex-shrink-0 ml-3 group-hover:text-gray-600"
                    x-bind:class="open === {{ $i }} ? 'rotate-180' : ''" />
            </button>
            <div x-show="open === {{ $i }}" x-cloak x-collapse
                class="mt-2 text-sm text-gray-500 leading-relaxed pr-6">
                {{ $faq['a'] }}
            </div>
        </div>
        @endforeach
    </div>
</x-filament::section>
</x-filament-panels::page>
