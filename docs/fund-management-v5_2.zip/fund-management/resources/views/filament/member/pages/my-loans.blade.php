<x-filament-panels::page>
@php
    $member    = auth()->user();
    $activeLoans = $member->activeLoans()->with(['emiCycles','guarantor'])->get();
    $histLoans   = $member->loans()->where('status','repaid')->latest()->get();
    $settleTarget = request('settle') ? $activeLoans->first() : null;
@endphp

<div x-data="{ tab: '{{ request('tab','active') }}', settleType: 'full', scheduleOpt: 'rollup' }" class="space-y-6">

{{-- Tab bar --}}
<div class="flex gap-1 border-b border-gray-200 pb-0 -mb-px">
    @foreach(['active'=>'Active loans ('.$activeLoans->count().')','history'=>'Loan history','settle'=>'Settle loan'] as $key=>$label)
    <button @click="tab='{{ $key }}'"
        :class="tab==='{{ $key }}' ? 'border-b-2 border-primary-600 text-primary-700 font-medium' : 'text-gray-400 hover:text-gray-600'"
        class="px-4 py-3 text-sm transition-colors border-b-2 border-transparent">
        {{ $label }}
    </button>
    @endforeach
</div>

{{-- ACTIVE LOANS TAB --}}
<div x-show="tab==='active'" x-cloak>
    @forelse($activeLoans as $loan)
    <x-filament::section class="mb-4">
        <x-slot name="heading">{{ $loan->loan_number }} <span class="text-xs font-normal text-gray-400 ml-2">Approved {{ \Carbon\Carbon::parse($loan->approved_at)->format('M Y') }}</span></x-slot>
        <x-slot name="headerActions">
            <button @click="tab='settle'" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-primary-300 text-xs text-primary-700 hover:bg-primary-50">
                <x-heroicon-m-check-circle class="w-4 h-4"/>Settle loan
            </button>
        </x-slot>

        <div class="flex justify-between items-baseline mb-2">
            <div class="text-2xl font-semibold">SAR {{ number_format($loan->requested_amount,2) }}</div>
            <div class="text-xs text-gray-400">{{ $loan->emiCycles->where('status','collected')->count() }} of {{ $loan->emiCycles->count() }} EMIs · EMI SAR {{ number_format($loan->emi_amount,2) }}/cycle</div>
        </div>
        <div class="w-full bg-gray-100 rounded-full h-2 mb-1"><div class="bg-success-500 h-2 rounded-full" style="width:{{ $loan->repaid_percent }}%"></div></div>
        <div class="flex justify-between text-xs text-gray-400 mb-5">
            <span>SAR {{ number_format($loan->total_repaid,2) }} repaid</span>
            <span>SAR {{ number_format($loan->remaining_threshold,2) }} to threshold</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-5">
            @foreach([
                ['Threshold','SAR '.number_format($loan->settlement_threshold,0)],
                ['Guarantor',$loan->guarantor?->name ?? '—'],
                ['Fund tier',strtoupper($loan->fund_tier ?? '—')],
                ['Grace period',$loan->grace_cycles.' cycle'.($loan->grace_cycles===1?'':'s')],
                ['Next EMI',\Carbon\Carbon::now()->startOfMonth()->addMonth()->format('1 M Y')],
                ['EMI amount','SAR '.number_format($loan->emi_amount,2)],
            ] as [$lbl,$val])
            <div class="bg-gray-50 rounded-xl p-3"><div class="text-xs text-gray-400 mb-0.5">{{ $lbl }}</div><div class="text-sm font-semibold">{{ $val }}</div></div>
            @endforeach
        </div>

        <div class="border-t border-gray-100 pt-4">
            <div class="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-3">Repayment schedule</div>
            <div class="overflow-x-auto">
                <table class="w-full text-xs">
                    <thead class="text-gray-400 border-b border-gray-100"><tr>
                        <th class="py-2 text-left">Cycle</th><th class="py-2 text-left">EMI due</th>
                        <th class="py-2 text-left">Status</th><th class="py-2 text-left">Collected</th>
                    </tr></thead>
                    <tbody class="divide-y divide-gray-50">
                    @foreach($loan->emiCycles->sortBy('cycle_number') as $emi)
                        <tr>
                            <td class="py-2">{{ \Carbon\Carbon::parse($emi->cycle_month)->format('M Y') }}</td>
                            <td class="py-2">{{ number_format($emi->emi_due,0) }}</td>
                            <td class="py-2">
                                <span class="px-2 py-0.5 rounded-full text-xs font-medium {{ match($emi->status) {
                                    'collected' => 'bg-success-100 text-success-700',
                                    'pending'   => 'bg-info-100 text-info-700',
                                    'overdue'   => 'bg-warning-100 text-warning-700',
                                    'scheduled' => 'bg-gray-100 text-gray-500',
                                    default     => 'bg-gray-100 text-gray-500'
                                } }}">{{ ucfirst($emi->status) }}</span>
                            </td>
                            <td class="py-2">{{ $emi->emi_collected > 0 ? 'SAR '.number_format($emi->emi_collected,0) : '—' }}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </x-filament::section>
    @empty
        <x-filament::section>
            <div class="text-center py-10 text-gray-400">
                <x-heroicon-o-currency-dollar class="w-12 h-12 mx-auto mb-3 text-gray-300"/>
                <p class="font-medium">No active loans</p>
                <a href="{{ route('filament.member.pages.loan-request') }}" class="mt-2 inline-block text-sm text-primary-600 hover:underline">Request your first loan →</a>
            </div>
        </x-filament::section>
    @endforelse
</div>

{{-- LOAN HISTORY TAB --}}
<div x-show="tab==='history'" x-cloak>
    <x-filament::section heading="Loan history">
        <table class="w-full text-sm">
            <thead class="text-xs text-gray-400 border-b border-gray-100"><tr>
                <th class="py-2 text-left">Loan #</th><th class="py-2 text-left">Amount</th>
                <th class="py-2 text-left">Status</th><th class="py-2 text-left">Approved</th><th class="py-2 text-left">Repaid</th>
            </tr></thead>
            <tbody class="divide-y divide-gray-50">
            @forelse($histLoans as $l)
                <tr>
                    <td class="py-2.5">{{ $l->loan_number }}</td>
                    <td class="py-2.5">SAR {{ number_format($l->requested_amount,0) }}</td>
                    <td class="py-2.5"><span class="bg-gray-100 text-gray-600 text-xs px-2 py-0.5 rounded-full">Repaid</span></td>
                    <td class="py-2.5 text-gray-400 text-xs">{{ \Carbon\Carbon::parse($l->approved_at)->format('M Y') }}</td>
                    <td class="py-2.5 text-gray-400 text-xs">{{ $l->total_repaid > 0 ? \Carbon\Carbon::parse($l->updated_at)->format('M Y') : '—' }}</td>
                </tr>
            @empty
                <tr><td colspan="5" class="py-8 text-center text-gray-400">No historical loans</td></tr>
            @endforelse
            </tbody>
        </table>
    </x-filament::section>
</div>

{{-- SETTLE LOAN TAB --}}
<div x-show="tab==='settle'" x-cloak>
@if($activeLoans->isNotEmpty())
@php $loan = $activeLoans->first(); $available = max(0,$member->cash_balance - $loan->emi_amount); $outstanding = $loan->remaining_threshold; @endphp
<x-filament::section heading="Settle loan — {{ $loan->loan_number }}">
    {{-- Info notice --}}
    <div class="flex items-start gap-3 p-3 mb-5 rounded-xl bg-info-50 border border-info-200 text-info-800 text-sm">
        <x-heroicon-o-information-circle class="w-5 h-5 text-info-500 flex-shrink-0 mt-0.5"/>
        <span>Outstanding threshold balance: <strong>SAR {{ number_format($outstanding,2) }}</strong>.
        Full settlement clears the loan immediately and releases your guarantor.
        Partial settlement lets you choose how to adjust the remaining schedule.</span>
    </div>

    {{-- Settlement type selector --}}
    <div class="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-3">Settlement type</div>
    <div class="grid grid-cols-2 gap-4 mb-6">
        <button @click="settleType='full'"
            :class="settleType==='full' ? 'border-primary-400 bg-primary-50 text-primary-800' : 'border-gray-200 text-gray-600'"
            class="text-left p-4 rounded-xl border-2 transition-colors">
            <div class="font-semibold text-sm mb-1">Full settlement</div>
            <div class="text-xs text-gray-500">Pay remaining SAR {{ number_format($outstanding,2) }} now — loan closed immediately</div>
        </button>
        <button @click="settleType='partial'"
            :class="settleType==='partial' ? 'border-primary-400 bg-primary-50 text-primary-800' : 'border-gray-200 text-gray-600'"
            class="text-left p-4 rounded-xl border-2 transition-colors">
            <div class="font-semibold text-sm mb-1">Partial settlement</div>
            <div class="text-xs text-gray-500">Pay a partial amount and adjust the schedule</div>
        </button>
    </div>

    {{-- Full settlement form --}}
    <div x-show="settleType==='full'">
        <div class="space-y-4">
            <div class="flex items-center justify-between py-2 border-b border-gray-100 text-sm"><span class="text-gray-500">Settlement amount</span><strong>SAR {{ number_format($outstanding,2) }}</strong></div>
            <div class="flex items-center justify-between py-2 border-b border-gray-100 text-sm"><span class="text-gray-500">Cash account balance</span><span>SAR {{ number_format($member->cash_balance,2) }}</span></div>
            @if($member->cash_balance < $outstanding)
            <div class="flex items-start gap-2 p-3 rounded-xl bg-warning-50 border border-warning-200 text-warning-800 text-sm">
                <x-heroicon-o-exclamation-triangle class="w-5 h-5 flex-shrink-0 mt-0.5 text-warning-500"/>
                <span>Your balance (SAR {{ number_format($member->cash_balance,2) }}) is below the required SAR {{ number_format($outstanding,2) }}.
                Please deposit SAR {{ number_format($outstanding - $member->cash_balance,2) }} first.</span>
            </div>
            <a href="{{ route('filament.member.pages.cash-account') }}"
               class="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 text-sm hover:bg-gray-50">
                <x-heroicon-m-arrow-down-left class="w-4 h-4"/>Deposit funds first
            </a>
            @else
            <button class="w-full py-2.5 px-4 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700">
                Confirm full settlement
            </button>
            @endif
        </div>
    </div>

    {{-- Partial settlement form --}}
    <div x-show="settleType==='partial'" x-cloak>
        <div class="space-y-4">
            <div>
                <label class="text-xs font-medium text-gray-600 block mb-1">Partial amount (SAR) — min 1 EMI (SAR {{ number_format($loan->emi_amount,0) }})</label>
                <input type="number" placeholder="{{ number_format($loan->emi_amount,0) }}" min="{{ $loan->emi_amount }}"
                    class="w-full text-sm px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-400"/>
            </div>

            <div class="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-2">Schedule treatment</div>
            <div class="grid grid-cols-2 gap-3">
                <button @click="scheduleOpt='rollup'"
                    :class="scheduleOpt==='rollup' ? 'border-primary-400 bg-primary-50' : 'border-gray-200'"
                    class="text-left p-3 rounded-xl border-2 transition-colors">
                    <div class="text-sm font-semibold mb-1">Roll-up (compress)</div>
                    <div class="text-xs text-gray-500">Covered cycles marked settled — schedule shortens</div>
                </button>
                <button @click="scheduleOpt='skip'"
                    :class="scheduleOpt==='skip' ? 'border-primary-400 bg-primary-50' : 'border-gray-200'"
                    class="text-left p-3 rounded-xl border-2 transition-colors">
                    <div class="text-sm font-semibold mb-1">Skip cycles</div>
                    <div class="text-xs text-gray-500">Covered cycles skipped — EMIs resume after gap</div>
                </button>
            </div>

            <button class="w-full py-2.5 px-4 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700">
                Confirm partial settlement
            </button>
        </div>
    </div>
</x-filament::section>
@else
<x-filament::section>
    <div class="text-center py-10 text-gray-400">
        <x-heroicon-o-check-circle class="w-10 h-10 mx-auto mb-3 text-gray-300"/>
        <p>No active loans to settle.</p>
    </div>
</x-filament::section>
@endif
</div>

</div>
</x-filament-panels::page>
