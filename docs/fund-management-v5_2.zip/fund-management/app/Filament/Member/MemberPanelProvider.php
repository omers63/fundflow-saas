<?php

namespace App\Filament\Member;

use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\AuthenticateSession;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;

/**
 * Member Panel Provider — FilamentPHP v5 (Livewire v4)
 */
class MemberPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->id('member')
            ->path('portal')
            ->login()
            ->colors([
                'primary' => Color::hex('#534AB7'),
                'success' => Color::hex('#1D9E75'),
                'warning' => Color::hex('#EF9F27'),
                'danger'  => Color::hex('#E24B4A'),
                'info'    => Color::hex('#378ADD'),
            ])
            ->brandName('FundAdmin — Member Portal')
            ->discoverResources(
                in: app_path('Filament/Member/Resources'),
                for: 'App\\Filament\\Member\\Resources'
            )
            ->discoverPages(
                in: app_path('Filament/Member/Pages'),
                for: 'App\\Filament\\Member\\Pages'
            )
            ->discoverWidgets(
                in: app_path('Filament/Member/Widgets'),
                for: 'App\\Filament\\Member\\Widgets'
            )
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([Authenticate::class]);
    }
}
