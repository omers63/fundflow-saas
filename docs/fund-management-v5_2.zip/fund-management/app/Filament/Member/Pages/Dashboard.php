<?php
namespace App\Filament\Member\Pages;

use Filament\Pages\Page;

class Dashboard extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-home';
    protected static ?string $title = 'Overview';
    protected static ?int $navigationSort = 1;
    protected static string $view = 'filament.member.pages.overview';
}
