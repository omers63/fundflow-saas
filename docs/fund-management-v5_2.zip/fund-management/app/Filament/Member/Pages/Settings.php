<?php
namespace App\Filament\Member\Pages;

use Filament\Pages\Page;

class Settings extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-cog-6-tooth';
    protected static ?string $navigationLabel = 'Settings';
    protected static ?string $navigationGroup = 'Self-Service';
    protected static ?int $navigationSort = 10;
    protected static string $view = 'filament.member.pages.settings';
}
