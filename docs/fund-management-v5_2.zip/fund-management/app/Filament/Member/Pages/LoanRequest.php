<?php
namespace App\Filament\Member\Pages;

use Filament\Pages\Page;

class LoanRequest extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-document-text';
    protected static ?string $navigationLabel = 'Request a Loan';
    protected static ?string $navigationGroup = 'Loans';
    protected static ?int $navigationSort = 5;
    protected static string $view = 'filament.member.pages.loan-request';
}
