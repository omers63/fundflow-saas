<?php
namespace App\Filament\Member\Pages;

use Filament\Pages\Page;

class MyLoans extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-currency-dollar';
    protected static ?string $navigationLabel = 'My Loans';
    protected static ?string $navigationGroup = 'Loans';
    protected static ?int $navigationSort = 4;
    protected static string $view = 'filament.member.pages.my-loans';
}
