<?php
namespace App\Filament\Member\Pages;

use Filament\Actions\Action;
use Filament\Pages\Page;

class Help extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-question-mark-circle';
    protected static ?string $navigationLabel = 'Help & FAQ';
    protected static ?string $navigationGroup = 'Self-Service';
    protected static ?int $navigationSort = 11;
    protected static string $view = 'filament.member.pages.help';

    protected function getHeaderActions(): array
    {
        return [
            Action::make('contact_support')
                ->label('Contact support')
                ->icon('heroicon-o-chat-bubble-left-right')
                ->color('gray')
                ->url('mailto:support@fundmanagement.com'),
        ];
    }
}
