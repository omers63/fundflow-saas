<?php
namespace App\Filament\Admin\Resources\ReconResource\Pages;

use App\Filament\Admin\Resources\ReconResource;
use App\Models\ReconException;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ListRecords;

class ListReconExceptions extends ListRecords
{
    protected static string $resource = ReconResource::class;

    protected function getHeaderWidgets(): array
    {
        return [\App\Filament\Admin\Widgets\ReconStatsWidget::class];
    }

    protected function getHeaderActions(): array { return []; }
}
