<?php
namespace App\Filament\Admin\Resources\ReconResource\Pages;

use App\Filament\Admin\Resources\ReconResource;
use App\Models\ReconException;
use Filament\Actions;
use Filament\Forms;
use Filament\Infolists;
use Filament\Infolists\Infolist;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ViewRecord;

class ViewReconException extends ViewRecord
{
    protected static string $resource = ReconResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('resolve')
                ->label('Post resolution & resume batch')
                ->color('primary')
                ->icon('heroicon-o-wrench-screwdriver')
                ->form([
                    Forms\Components\Select::make('resolution_action')
                        ->label('Resolution action')
                        ->options([
                            'post_correction'  => 'Post correction entry',
                            'reverse'          => 'Reverse transaction',
                            'reclassify'       => 'Reclassify',
                            'write_off'        => 'Write-off (LOW/MEDIUM only)',
                            'escalate'         => 'Escalate to supervisor',
                            'override_accept'  => 'Override and accept (supervisor sign-off)',
                        ])->required(),
                    Forms\Components\TextInput::make('correction_amount')
                        ->numeric()->prefix('SAR')->label('Correction amount (SAR)'),
                    Forms\Components\Select::make('reason_code')
                        ->label('Reason code')
                        ->options([
                            'rounding_emi'  => 'Rounding difference — EMI last instalment',
                            'fx_residual'   => 'FX conversion residual',
                            'manual_error'  => 'Manual posting error',
                            'timing_diff'   => 'Timing difference',
                            'other'         => 'Other',
                        ])->required(),
                    Forms\Components\Textarea::make('resolution_notes')
                        ->label('Resolution notes (mandatory for CRITICAL)')
                        ->required()
                        ->minLength(fn() => $this->record->severity?->value === 'critical' ? 20 : 1),
                ])
                ->action(function (array $data) {
                    $this->record->update([
                        'resolution_action' => $data['resolution_action'],
                        'reason_code'       => $data['reason_code'],
                        'resolution_notes'  => $data['resolution_notes'],
                        'resolved_at'       => now(),
                        'resolved_by'       => auth()->id(),
                        'is_open'           => false,
                    ]);
                    \App\Models\AuditLog::record('RECON_MANUAL_RESOLUTION','reconciliation',
                        "Exception {$this->record->exception_type} resolved",'RECON',$data,auth()->id(),$this->record->id);
                    Notification::make()->title('Exception resolved — batch can resume')->success()->send();
                    $this->refreshFormData(['is_open','resolved_at']);
                })
                ->visible(fn() => $this->record->is_open),
        ];
    }

    public function infolist(Infolist $infolist): Infolist
    {
        return $infolist->schema([
            Infolists\Components\Section::make('Exception details')->schema([
                Infolists\Components\TextEntry::make('id')->label('Exception ID')
                    ->formatStateUsing(fn($s) => 'EXC-'.str_pad($s,6,'0',STR_PAD_LEFT)),
                Infolists\Components\TextEntry::make('domain')->badge(),
                Infolists\Components\BadgeEntry::make('severity'),
                Infolists\Components\TextEntry::make('amount_delta')->money('SAR')->label('Delta'),
                Infolists\Components\TextEntry::make('raised_at')->dateTime()->label('Raised at'),
                Infolists\Components\TextEntry::make('sla_deadline')->dateTime()->label('SLA deadline'),
                Infolists\Components\TextEntry::make('auto_resolve_result')->label('Auto-resolve result')
                    ->default('Not attempted'),
                Infolists\Components\IconColumn::make('is_open')->boolean()->label('Currently open'),
            ])->columns(4),

            Infolists\Components\Section::make('Resolution')
                ->schema([
                    Infolists\Components\TextEntry::make('resolution_action')->label('Action taken'),
                    Infolists\Components\TextEntry::make('reason_code')->label('Reason code'),
                    Infolists\Components\TextEntry::make('resolution_notes')->label('Notes'),
                    Infolists\Components\TextEntry::make('resolved_at')->dateTime()->label('Resolved at'),
                ])->columns(2)
                ->visible(fn() => !$this->record->is_open),
        ]);
    }
}
