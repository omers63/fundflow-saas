<?php
namespace App\Filament\Admin\Resources\BankClearingResource\Pages;

use App\Filament\Admin\Resources\BankClearingResource;
use Filament\Resources\Pages\ListRecords;

class ListBankLines extends ListRecords
{
    protected static string $resource = BankClearingResource::class;

    protected function getHeaderWidgets(): array
    {
        return [\App\Filament\Admin\Widgets\BankClearingStatsWidget::class];
    }
}
