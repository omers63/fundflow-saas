<?php
namespace App\Filament\Admin\Resources\MemberResource\Pages;

use App\Enums\MemberStatus;
use App\Filament\Admin\Resources\MemberResource;
use App\Models\Member;
use Filament\Actions;
use Filament\Infolists;
use Filament\Infolists\Infolist;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ViewRecord;

class ViewMember extends ViewRecord
{
    protected static string $resource = MemberResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('suspend')
                ->label('Suspend account')
                ->color('danger')
                ->icon('heroicon-o-x-circle')
                ->requiresConfirmation()
                ->action(function () {
                    $this->record->update(['status' => MemberStatus::Suspended]);
                    Notification::make()->title('Member suspended')->warning()->send();
                    $this->refreshFormData(['status']);
                })
                ->visible(fn() => $this->record->status === MemberStatus::Active),

            Actions\Action::make('reinstate')
                ->label('Reinstate')
                ->color('success')
                ->icon('heroicon-o-check-circle')
                ->requiresConfirmation()
                ->action(function () {
                    $this->record->update(['status' => MemberStatus::Active]);
                    Notification::make()->title('Member reinstated')->success()->send();
                    $this->refreshFormData(['status']);
                })
                ->visible(fn() => $this->record->status === MemberStatus::Suspended),

            Actions\Action::make('admin_override')
                ->label('Admin override')
                ->color('warning')
                ->icon('heroicon-o-shield-exclamation')
                ->form([
                    \Filament\Forms\Components\Select::make('gate')
                        ->label('Gate to override')
                        ->options([
                            'tenure'    => 'Tenure requirement',
                            'balance'   => 'Minimum fund balance',
                            'delinquent'=> 'Delinquency flag',
                            'loan_limit'=> 'Active loan count',
                            'multiplier'=> 'Borrow multiplier',
                        ])->required(),
                    \Filament\Forms\Components\Textarea::make('reason')
                        ->label('Override reason (mandatory)')
                        ->required()->minLength(10),
                ])
                ->action(function (array $data) {
                    \App\Models\AuditLog::record(
                        'ADMIN_OVERRIDE', 'member',
                        "Admin override applied: gate={$data['gate']} reason={$data['reason']}",
                        'Override', $data, auth()->id(), $this->record->id
                    );
                    Notification::make()->title('Override recorded in audit log')->warning()->send();
                }),

            Actions\EditAction::make(),
        ];
    }

    public function infolist(Infolist $infolist): Infolist
    {
        return $infolist->schema([
            Infolists\Components\Tabs::make('Member detail')->tabs([

                Infolists\Components\Tabs\Tab::make('Profile')->schema([
                    Infolists\Components\Section::make('Personal details')->schema([
                        Infolists\Components\TextEntry::make('name'),
                        Infolists\Components\TextEntry::make('id')->label('Member ID')
                            ->formatStateUsing(fn($state) => '#' . $state),
                        Infolists\Components\TextEntry::make('join_date')->date('d M Y'),
                        Infolists\Components\BadgeEntry::make('status'),
                        Infolists\Components\TextEntry::make('phone'),
                        Infolists\Components\TextEntry::make('email'),
                        Infolists\Components\TextEntry::make('tenure_years')
                            ->label('Tenure')
                            ->formatStateUsing(fn($state) => $state . ' years'),
                        Infolists\Components\TextEntry::make('national_id')->label('National ID'),
                    ])->columns(2),

                    Infolists\Components\Section::make('Recent activity')->schema([
                        Infolists\Components\RepeatableEntry::make('transactions')
                            ->schema([
                                Infolists\Components\TextEntry::make('effective_date')->date()->label('Date'),
                                Infolists\Components\TextEntry::make('description')->label('Event'),
                                Infolists\Components\TextEntry::make('tag')->badge()->label('Type'),
                            ])
                            ->columns(3),
                    ]),
                ]),

                Infolists\Components\Tabs\Tab::make('Accounts')->schema([
                    Infolists\Components\Section::make('Cash account')->schema([
                        Infolists\Components\TextEntry::make('cash_balance')
                            ->money('SAR')->label('Balance')->size('lg'),
                        Infolists\Components\TextEntry::make('opening_cash_balance')
                            ->money('SAR')->label('Opening balance'),
                    ])->columns(2)->headerActions([
                        Infolists\Components\Actions\Action::make('post_manual_cash')
                            ->label('Post manual entry')
                            ->form([
                                \Filament\Forms\Components\TextInput::make('amount')
                                    ->numeric()->prefix('SAR')->required(),
                                \Filament\Forms\Components\Textarea::make('notes'),
                            ])
                            ->action(function (array $data) {
                                $this->record->increment('cash_balance', $data['amount']);
                                Notification::make()->title('Cash entry posted')->success()->send();
                            }),
                    ]),

                    Infolists\Components\Section::make('Fund account')->schema([
                        Infolists\Components\TextEntry::make('fund_balance')
                            ->money('SAR')->label('Balance')->size('lg'),
                        Infolists\Components\TextEntry::make('opening_fund_balance')
                            ->money('SAR')->label('Opening balance'),
                        Infolists\Components\TextEntry::make('borrow_cap')
                            ->money('SAR')->label('Borrow capacity (×3)'),
                    ])->columns(3),
                ]),

                Infolists\Components\Tabs\Tab::make('Loans')->schema([
                    Infolists\Components\RepeatableEntry::make('loans')->schema([
                        Infolists\Components\TextEntry::make('loan_number')->label('Loan #'),
                        Infolists\Components\TextEntry::make('requested_amount')->money('SAR'),
                        Infolists\Components\BadgeEntry::make('status'),
                        Infolists\Components\TextEntry::make('total_repaid')->money('SAR')->label('Repaid'),
                        Infolists\Components\TextEntry::make('emi_amount')->money('SAR')->label('EMI'),
                        Infolists\Components\TextEntry::make('guarantor.name')->label('Guarantor'),
                    ])->columns(3),
                ]),

                Infolists\Components\Tabs\Tab::make('Cycle history')->schema([
                    Infolists\Components\RepeatableEntry::make('contributionCycles')->schema([
                        Infolists\Components\TextEntry::make('cycle_month')
                            ->date('M Y')->label('Cycle'),
                        Infolists\Components\BadgeEntry::make('status'),
                        Infolists\Components\TextEntry::make('due_amount')->money('SAR')->label('Due'),
                        Infolists\Components\TextEntry::make('collected_amount')->money('SAR')->label('Collected'),
                        Infolists\Components\TextEntry::make('late_fee_amount')->money('SAR')->label('Late fee'),
                    ])->columns(5),
                ]),

                Infolists\Components\Tabs\Tab::make('Transactions')->schema([
                    Infolists\Components\RepeatableEntry::make('transactions')->schema([
                        Infolists\Components\TextEntry::make('effective_date')->date()->label('Date'),
                        Infolists\Components\TextEntry::make('description')->label('Description'),
                        Infolists\Components\TextEntry::make('dr_amount')
                            ->money('SAR')->label('Debit')
                            ->color('danger'),
                        Infolists\Components\TextEntry::make('cr_amount')
                            ->money('SAR')->label('Credit')
                            ->color('success'),
                        Infolists\Components\TextEntry::make('tag')->badge(),
                    ])->columns(5),
                ]),

            ])->columnSpanFull(),
        ]);
    }
}
