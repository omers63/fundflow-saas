<?php
namespace App\Filament\Admin\Resources;

use App\Enums\ReconSeverity;
use App\Filament\Admin\Resources\ReconResource\Pages;
use App\Models\ReconException;
use App\Services\ReconciliationService;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class ReconResource extends Resource
{
    protected static ?string $model = ReconException::class;
    protected static ?string $navigationIcon = 'heroicon-o-arrows-right-left';
    protected static ?string $navigationGroup = 'Finance';
    protected static ?string $navigationLabel = 'Reconciliation';
    protected static ?int $navigationSort = 6;

    public static function getNavigationBadge(): ?string
    {
        $c = ReconException::where('is_open', true)->count();
        return $c ? (string)$c : null;
    }

    public static function getNavigationBadgeColor(): string|array|null
    {
        return ReconException::where('severity','critical')->where('is_open',true)->exists()
            ? 'danger' : 'warning';
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('exception_type')->required(),
            Forms\Components\TextInput::make('domain')->required(),
            Forms\Components\Select::make('severity')->options(ReconSeverity::class)->required(),
            Forms\Components\TextInput::make('amount_delta')->numeric()->prefix('SAR'),
            Forms\Components\Toggle::make('is_open')->default(true),
            Forms\Components\Textarea::make('resolution_notes'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('raised_at','desc')
            ->headerActions([
                Tables\Actions\Action::make('run_batch')
                    ->label('Run batch now')
                    ->icon('heroicon-o-play')
                    ->color('primary')
                    ->requiresConfirmation()
                    ->modalHeading('Run nightly reconciliation batch')
                    ->modalDescription('This will run all 6 domain checks, auto-resolve where possible, and raise exceptions for manual review.')
                    ->action(function () {
                        ReconciliationService::runNightlyBatch();
                    }),
            ])
            ->columns([
                Tables\Columns\TextColumn::make('exception_type')->searchable()->label('Type')
                    ->wrap()->limit(40),
                Tables\Columns\TextColumn::make('domain')->badge()->label('Domain'),
                Tables\Columns\BadgeColumn::make('severity'),
                Tables\Columns\TextColumn::make('amount_delta')->money('SAR')->label('Delta'),
                Tables\Columns\TextColumn::make('sla_deadline')
                    ->label('SLA deadline')
                    ->dateTime()
                    ->color(fn(ReconException $r) => match($r->severity?->value) {
                        'critical' => 'danger',
                        'high'     => 'warning',
                        default    => 'gray',
                    })
                    ->description(fn(ReconException $r) => $r->severity?->getSla() ?? ''),
                Tables\Columns\IconColumn::make('is_open')->boolean()->label('Open'),
                Tables\Columns\TextColumn::make('raised_at')->dateTime()->sortable()->label('Raised'),
                Tables\Columns\TextColumn::make('resolved_at')->dateTime()->label('Resolved'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('severity')->options(ReconSeverity::class),
                Tables\Filters\TernaryFilter::make('is_open')->label('Open only'),
            ])
            ->actions([
                Tables\Actions\ViewAction::make()->label('Resolve'),
                Tables\Actions\EditAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListReconExceptions::route('/'),
            'view'   => Pages\ViewReconException::route('/{record}'),
        ];
    }
}
