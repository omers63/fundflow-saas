<?php
namespace App\Filament\Admin\Resources\CycleResource\Pages;

use App\Filament\Admin\Resources\CycleResource;
use App\Models\ContributionCycle;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
use Filament\Resources\Components\Tab;

class ListCycles extends ListRecords
{
    protected static string $resource = CycleResource::class;

    protected function getHeaderActions(): array
    {
        return [Actions\CreateAction::make()];
    }

    protected function getHeaderWidgets(): array
    {
        return [\App\Filament\Admin\Widgets\CycleStatsWidget::class];
    }

    public function getTabs(): array
    {
        $month = now()->format('Y-m-01');
        $prev  = now()->subMonth()->format('Y-m-01');
        return [
            'current' => Tab::make(now()->format('M Y').' (active)')
                ->modifyQueryUsing(fn($q) => $q->where('cycle_month', $month)),
            'previous'=> Tab::make(now()->subMonth()->format('M Y'))
                ->modifyQueryUsing(fn($q) => $q->where('cycle_month', $prev)),
            'all'     => Tab::make('All cycles'),
        ];
    }
}
