<?php
namespace App\Filament\Admin\Resources\LoanResource\Pages;

use App\Enums\LoanStatus;
use App\Filament\Admin\Resources\LoanResource;
use App\Models\Loan;
use App\Models\SystemConfig;
use Filament\Actions;
use Filament\Forms;
use Filament\Infolists;
use Filament\Infolists\Infolist;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ViewRecord;

class ViewLoan extends ViewRecord
{
    protected static string $resource = LoanResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('approve')
                ->label('Approve & disburse')
                ->color('success')
                ->icon('heroicon-o-check-circle')
                ->form([
                    Forms\Components\TextInput::make('approved_amount')
                        ->numeric()->prefix('SAR')->required()
                        ->default(fn() => $this->record->requested_amount)
                        ->label('Disbursement amount (SAR)'),
                    Forms\Components\Select::make('decision')
                        ->options(['full'=>'Full disbursement','partial'=>'Partial disbursement'])
                        ->required(),
                    Forms\Components\Textarea::make('admin_notes')->label('Admin notes (optional)'),
                ])
                ->action(function (array $data) {
                    $this->record->update([
                        'status'          => LoanStatus::PartiallyDisbursed,
                        'approved_amount' => $data['approved_amount'],
                        'admin_notes'     => $data['admin_notes'] ?? null,
                        'approved_at'     => now(),
                    ]);
                    \App\Models\AuditLog::record('LOAN_APPROVED','loan',
                        "Loan {$this->record->loan_number} approved",'Loan',$data,auth()->id(),$this->record->id);
                    Notification::make()->title('Loan approved')->success()->send();
                    $this->refreshFormData(['status']);
                })
                ->visible(fn() => $this->record->status === LoanStatus::PendingAdmin),

            Actions\Action::make('reject')
                ->label('Reject')
                ->color('danger')
                ->icon('heroicon-o-x-circle')
                ->form([
                    Forms\Components\Textarea::make('rejection_reason')->required(),
                ])
                ->action(function (array $data) {
                    $this->record->update(['status'=>LoanStatus::Rejected,'rejection_reason'=>$data['rejection_reason']]);
                    Notification::make()->title('Loan rejected')->danger()->send();
                    $this->refreshFormData(['status']);
                })
                ->visible(fn() => $this->record->status === LoanStatus::PendingAdmin),

            Actions\EditAction::make(),
        ];
    }

    public function infolist(Infolist $infolist): Infolist
    {
        $config = SystemConfig::current();
        $member = $this->record->member;

        $checks = [
            ['label'=>'Membership tenure',   'pass'=>$member?->tenure_years >= $config->min_membership_years, 'detail'=>($member?->tenure_years ?? 0).' yrs — min '.$config->min_membership_years],
            ['label'=>'Fund balance',         'pass'=>($member?->fund_balance ?? 0) >= $config->min_fund_balance, 'detail'=>'SAR '.number_format($member?->fund_balance ?? 0,0).' — min SAR '.number_format($config->min_fund_balance,0)],
            ['label'=>'No delinquency',       'pass'=>!in_array($member?->status?->value,['delinquent','suspended']), 'detail'=>'Status: '.($member?->status?->getLabel() ?? '—')],
            ['label'=>'Active loan count',    'pass'=>($member?->activeLoans()->count() ?? 0) < $config->max_active_loans, 'detail'=>($member?->activeLoans()->count() ?? 0).' active — max '.$config->max_active_loans],
            ['label'=>'Borrow limit',         'pass'=>$this->record->requested_amount <= ($member?->borrow_cap ?? 0), 'detail'=>'Request SAR '.number_format($this->record->requested_amount,0).' — cap SAR '.number_format($member?->borrow_cap ?? 0,0)],
            ['label'=>'Valid guarantor',      'pass'=>(bool)$this->record->guarantor_id, 'detail'=>$this->record->guarantor?->name ?? 'Not set'],
        ];

        $allPass = collect($checks)->every(fn($c) => $c['pass']);

        return $infolist->schema([
            Infolists\Components\Section::make('Request details')->schema([
                Infolists\Components\TextEntry::make('loan_number')->label('Loan #'),
                Infolists\Components\BadgeEntry::make('type'),
                Infolists\Components\TextEntry::make('requested_amount')->money('SAR')->label('Requested'),
                Infolists\Components\TextEntry::make('fund_tier')->label('Fund tier'),
                Infolists\Components\TextEntry::make('member.name')->label('Member'),
                Infolists\Components\TextEntry::make('guarantor.name')->label('Guarantor'),
                Infolists\Components\TextEntry::make('grace_cycles')->label('Grace period')
                    ->formatStateUsing(fn($s) => $s.' cycle'.($s===1?'':'s')),
                Infolists\Components\BadgeEntry::make('status'),
            ])->columns(4),

            Infolists\Components\Section::make('Eligibility checks')
                ->description($allPass ? '✓ All checks passed' : '⚠ Some checks failed — admin override required')
                ->schema([
                    Infolists\Components\ViewEntry::make('eligibility_checks')
                        ->view('filament.admin.infolists.eligibility-checks')
                        ->state($checks)
                        ->columnSpanFull(),
                ]),
        ]);
    }
}
