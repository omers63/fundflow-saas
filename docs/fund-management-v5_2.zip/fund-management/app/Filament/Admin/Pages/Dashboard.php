<?php
namespace App\Filament\Admin\Pages;

use App\Services\CollectionService;
use Filament\Actions\Action;
use Filament\Notifications\Notification;
use Filament\Pages\Dashboard as BaseDashboard;

class Dashboard extends BaseDashboard
{
    protected static ?string $navigationIcon = 'heroicon-o-home';
    protected static ?string $navigationGroup = 'Operations';
    protected static ?int $navigationSort = 1;
    protected static ?string $title = 'Dashboard';

    public function getColumns(): int|string|array { return 4; }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('run_batch')
                ->label('Run batch')
                ->icon('heroicon-o-play')
                ->color('primary')
                ->requiresConfirmation()
                ->modalHeading('Run debit batch')
                ->modalDescription('This will auto-debit all members for the current cycle. Continue?')
                ->action(function () {
                    CollectionService::runDebitBatch();
                    Notification::make()->title('Batch complete')->success()->send();
                }),

            Action::make('export')
                ->label('Export')
                ->icon('heroicon-o-arrow-down-tray')
                ->color('gray')
                ->action(function () {
                    Notification::make()->title('Export queued')->success()->send();
                }),
        ];
    }

    public function getWidgets(): array
    {
        return [
            \App\Filament\Admin\Widgets\StatsOverviewWidget::class,
            \App\Filament\Admin\Widgets\LoanQueueWidget::class,
            \App\Filament\Admin\Widgets\ReconAlertsWidget::class,
            \App\Filament\Admin\Widgets\CycleProgressWidget::class,
            \App\Filament\Admin\Widgets\MemberActivityWidget::class,
            \App\Filament\Admin\Widgets\FundTierWidget::class,
        ];
    }
}
