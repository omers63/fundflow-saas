<?php
namespace App\Filament\Admin\Widgets;

use App\Models\BankLine;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class BankClearingStatsWidget extends BaseWidget
{
    protected static bool $isLazy = false;

    protected function getStats(): array
    {
        $today     = today()->toDateString();
        $imported  = BankLine::whereDate('import_date', $today)->count();
        $matched   = BankLine::whereDate('import_date', $today)->where('status','cleared')->count();
        $unmatched = BankLine::whereIn('status',['unmatched','ambiguous','amount_mismatch'])->count();
        $stale     = BankLine::where('status','stale_pending')->count();

        return [
            Stat::make('Imported today', $imported)->icon('heroicon-o-arrow-down-tray')->color('primary'),
            Stat::make('Auto-matched', $matched)->icon('heroicon-o-check-circle')->color('success'),
            Stat::make('Unmatched', $unmatched)->icon('heroicon-o-exclamation-circle')->color($unmatched>0?'danger':'success'),
            Stat::make('Stale pending (>30d)', $stale)->icon('heroicon-o-clock')->color($stale>0?'warning':'gray'),
        ];
    }
}
