<?php
namespace App\Filament\Admin\Widgets;

use App\Models\ContributionCycle;
use App\Models\Loan;
use App\Models\Member;
use App\Models\ReconException;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class StatsOverviewWidget extends BaseWidget
{
    protected static ?int $sort = 1;
    protected int|string|array $columnSpan = 'full';

    protected function getDescription(): ?string
    {
        return 'Active cycle: ' . now()->format('F Y');
    }

    protected function getStats(): array
    {
        $month          = now()->format('Y-m-01');
        $totalMembers   = Member::count();
        $cycleCollected = ContributionCycle::where('cycle_month', $month)->where('status','collected')->count();
        $cycleTotal     = ContributionCycle::where('cycle_month', $month)->whereNotIn('status',['exempt'])->count();
        $pct            = $cycleTotal > 0 ? round(($cycleCollected / $cycleTotal) * 100) : 0;
        $activeLoans    = Loan::whereIn('status',['active','partially_disbursed'])->count();
        $queueCount     = Loan::where('status','pending_admin')->count();
        $openExceptions = ReconException::where('is_open', true)->count();
        $criticals      = ReconException::where('is_open', true)->where('severity','critical')->count();

        return [
            Stat::make('Total members', number_format($totalMembers))
                ->description(now()->format('F Y'))
                ->icon('heroicon-o-users')
                ->color('primary'),

            Stat::make('Collected this cycle', "{$pct}%")
                ->description("{$cycleCollected} of {$cycleTotal} members")
                ->icon('heroicon-o-check-circle')
                ->color('success'),

            Stat::make('Active loans', $activeLoans)
                ->description("{$queueCount} pending in queue")
                ->icon('heroicon-o-currency-dollar')
                ->color($queueCount > 0 ? 'warning' : 'primary'),

            Stat::make('Recon exceptions', $openExceptions)
                ->description($criticals > 0 ? "{$criticals} critical — batch halted" : 'No critical issues')
                ->icon('heroicon-o-exclamation-triangle')
                ->color($criticals > 0 ? 'danger' : ($openExceptions > 0 ? 'warning' : 'success')),
        ];
    }
}
