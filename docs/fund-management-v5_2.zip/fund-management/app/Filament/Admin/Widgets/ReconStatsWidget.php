<?php
namespace App\Filament\Admin\Widgets;

use App\Models\ReconException;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class ReconStatsWidget extends BaseWidget
{
    protected static ?int $sort = 1;
    protected static bool $isLazy = false;

    protected function getStats(): array
    {
        $open     = ReconException::where('is_open', true)->count();
        $resolved = ReconException::where('is_open', false)
            ->whereDate('resolved_at', today())->count();
        $lastBatch = \App\Models\AuditLog::where('event_type','RECON_BATCH_COMPLETE')
            ->latest('created_at')->value('created_at');
        $hasCritical = ReconException::where('is_open',true)->where('severity','critical')->exists();

        return [
            Stat::make('Open exceptions', $open)
                ->description($hasCritical ? '⚠ Batch halted — critical exception open' : 'Normal operations')
                ->icon('heroicon-o-exclamation-triangle')
                ->color($hasCritical ? 'danger' : ($open > 0 ? 'warning' : 'success')),

            Stat::make('Auto-resolved today', $resolved)
                ->icon('heroicon-o-check-badge')
                ->color('success'),

            Stat::make('Last batch run', $lastBatch ? \Carbon\Carbon::parse($lastBatch)->format('H:i d M') : 'Never')
                ->icon('heroicon-o-clock')
                ->color('gray'),

            Stat::make('Next batch', '00:01 ' . now()->addDay()->format('d M'))
                ->icon('heroicon-o-calendar')
                ->color('gray'),
        ];
    }
}
