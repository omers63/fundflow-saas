<?php
namespace App\Filament\Admin\Widgets;

use App\Models\ContributionCycle;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class CycleStatsWidget extends BaseWidget
{
    protected static ?int $sort = 1;
    protected static bool $isLazy = false;

    protected function getStats(): array
    {
        $month   = now()->format('Y-m-01');
        $base    = fn() => ContributionCycle::where('cycle_month', $month);
        $due     = $base()->whereNotIn('status',['exempt'])->count();
        $colSAR  = $base()->where('status','collected')->sum('collected_amount');
        $overdue = $base()->whereIn('status',['overdue','late_t1','late_t2','late_t3'])->count();
        $exempt  = $base()->where('status','exempt')->count();

        return [
            Stat::make('Due this cycle', $due.' members')->icon('heroicon-o-users')->color('primary'),
            Stat::make('Collected', 'SAR '.number_format($colSAR,0))->icon('heroicon-o-check-circle')->color('success'),
            Stat::make('Overdue', $overdue.' members')->icon('heroicon-o-exclamation-triangle')->color('danger'),
            Stat::make('Exempt (active loan)', $exempt.' members')->icon('heroicon-o-minus-circle')->color('gray'),
        ];
    }
}
