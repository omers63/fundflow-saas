<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

/**
 * Application Service Provider
 *
 * Registers both Filament v5 panel providers.
 * Livewire v4 (required by Filament v5) is auto-discovered
 * via the filament/filament package — no separate registration needed.
 */
class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}

    public function boot(): void
    {
        $this->app->register(\App\Filament\Admin\AdminPanelProvider::class);
        $this->app->register(\App\Filament\Member\MemberPanelProvider::class);
    }
}
