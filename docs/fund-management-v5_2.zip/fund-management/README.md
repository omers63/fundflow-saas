# Fund Management System — FilamentPHP v5

A full-stack fund management system built on **Laravel 11/12 + FilamentPHP v5 + Livewire v4**,
covering dual portals (Admin + Member), contribution collection, loan lifecycle,
bank clearing, reconciliation, and migration workflows.

---

## FilamentPHP v5 notes

Filament v5 is API-identical to v4. The sole change is its dependency on
**Livewire v4** (instead of Livewire v3). No Filament PHP classes, methods,
Blade components, or directives changed between v4 and v5.

**What changed in this project for v5:**
- `composer.json`: `filament/filament: ^5.0` + `livewire/livewire: ^4.1`
- `SESSION_DRIVER=database` (Livewire v4 recommendation — file sessions still work)
- Added session table migration (no-op if sessions table already exists)
- `post-autoload-dump` runs `filament:upgrade` automatically

---

## Quick start

```bash
# 1. Install dependencies
composer install
npm install && npm run build

# 2. Environment
cp .env.example .env
php artisan key:generate

# 3. Database (SQLite — zero config)
touch database/database.sqlite
php artisan migrate
php artisan db:seed

# 4. Run
php artisan serve
```

**Default credentials:**

| Portal | URL | Email | Password |
|--------|-----|-------|----------|
| Admin  | `/admin`  | `admin@fundmanagement.com` | `password` |
| Member | `/portal` | `youssef@example.com`      | `password` |

---

## Requirements

| Dependency | Version |
|---|---|
| PHP | ^8.2 |
| Laravel | ^11.0 or ^12.0 |
| FilamentPHP | ^5.0 |
| Livewire | ^4.1 (bundled via Filament) |

---

## Portal structure

### Admin portal (`/admin`)

| Page | URL |
|------|-----|
| Dashboard | `/admin` |
| Members | `/admin/members` |
| Loan queue | `/admin/loans` |
| Collection cycles | `/admin/cycles` |
| Disbursements | `/admin/disbursements` |
| Reconciliation | `/admin/recon-exceptions` |
| Bank clearing | `/admin/bank-lines` |
| Reports | `/admin/reports` |
| Migration | `/admin/migration-stubs` |
| Configuration | `/admin/configuration` |
| Audit log | `/admin/audit-log` |

### Member portal (`/portal`)

| Page | URL |
|------|-----|
| Overview | `/portal` |
| Cash account | `/portal/cash-account` |
| Fund account | `/portal/fund-account` |
| My loans | `/portal/my-loans` |
| Request a loan | `/portal/loan-request` |
| Contributions | `/portal/contributions` |
| Transactions | `/portal/transactions` |
| Cash out | `/portal/cash-out` |
| Statements | `/portal/statements` |
| Settings | `/portal/settings` |
| Help & FAQ | `/portal/help` |

---

## Architecture

```
app/
├── Enums/
│   ├── MemberStatus.php
│   ├── LoanStatus.php
│   ├── LoanType.php
│   ├── CycleStatus.php
│   ├── ReconSeverity.php
│   ├── BankLineStatus.php
│   └── MigrationClassification.php
│
├── Models/
│   ├── Member.php            # Authenticatable — member portal auth
│   ├── User.php              # Authenticatable — admin portal auth
│   ├── Loan.php
│   ├── ContributionCycle.php
│   ├── EmiCycle.php
│   ├── Disbursement.php
│   ├── BankLine.php
│   ├── ReconException.php
│   ├── MigrationStub.php
│   ├── Transaction.php
│   ├── SystemConfig.php      # Single-row config table
│   └── AuditLog.php
│
├── Services/
│   ├── CollectionService.php     # Debit batch, late fees, manual posting
│   ├── ReconciliationService.php # Nightly batch, 6 domain checks, auto-resolve
│   └── BankClearingService.php   # Import, auto-match, unmatched escalation
│
└── Filament/
    ├── Admin/
    │   ├── AdminPanelProvider.php   # Panel at /admin
    │   ├── Pages/
    │   │   ├── Dashboard.php        # 6-widget overview
    │   │   ├── Reports.php          # Standard + custom report builder
    │   │   ├── Configuration.php    # 5-tab system config
    │   │   └── AuditLog.php         # Filterable audit trail
    │   ├── Resources/
    │   │   ├── MemberResource/      # CRUD + 4 relation managers + suspend/reinstate
    │   │   ├── LoanResource/        # Queue + approve/reject/partial actions
    │   │   ├── CycleResource/       # Collection status + manual post
    │   │   ├── DisbursementResource/ # Tranche posting
    │   │   ├── BankClearingResource/ # Import + manual match
    │   │   ├── ReconResource/       # Exception queue + resolve action
    │   │   └── MigrationResource/   # Batch classify + clearance
    │   └── Widgets/
    │       ├── StatsOverviewWidget.php
    │       ├── LoanQueueWidget.php
    │       ├── ReconAlertsWidget.php
    │       ├── CycleProgressWidget.php
    │       ├── MemberActivityWidget.php
    │       └── FundTierWidget.php
    └── Member/
        ├── MemberPanelProvider.php  # Panel at /portal
        ├── Pages/
        │   ├── Dashboard.php        # Overview with notices + quick actions
        │   ├── CashAccount.php      # Balance + deposit form + history
        │   ├── FundAccount.php      # Fund balance detail + history
        │   ├── MyLoans.php          # EMI schedule + settle actions
        │   ├── LoanRequest.php      # 4-step wizard with eligibility check
        │   ├── Contributions.php    # Full cycle history
        │   ├── Transactions.php     # Filterable ledger
        │   ├── CashOut.php          # Withdrawal with reserved-balance check
        │   ├── Statements.php       # Statement generator + download history
        │   ├── Settings.php         # Profile, notifications, bank, security
        │   └── Help.php             # FAQ accordion
        └── Widgets/
            ├── AccountSummaryWidget.php
            ├── ActiveLoanWidget.php
            ├── QuickActionsWidget.php
            └── RecentTransactionsWidget.php

database/
├── migrations/   (13 files — includes Livewire v4 session table)
└── seeders/      (8 files — System config, Admin, Members, Loans,
                             Cycles, Bank lines, Recon exceptions)
```

---

## Key business rules implemented

| Rule | Location |
|---|---|
| Contribution exemption for active loan members | `CollectionService::runDebitBatch()` |
| Emergency loan requests jump the queue | `LoanResource` table default sort |
| Tiered late fees (replacement or cumulative) | `CollectionService::applyLateFees()` |
| Loan activation gate (schedule only after full disbursement) | `DisbursementResource` post_tranche action |
| Migration stubs created as UNRESOLVED (never MISSED) | `MemberSeeder`, `MigrationResource` |
| Master account invariant assertion before all batch posting | `ReconciliationService::checkMasterInvariant()` |
| Guarantor auto-transfer after Y missed EMIs | `ReconciliationService::reconcileEmis()` |
| Reconciliation severity SLAs (Critical = batch halted) | `ReconciliationService::raiseException()` |
| Late fees auto-reversed on migration cycles | `ReconciliationService::reconcileLateFees()` |

---

## Scheduled jobs

```php
// routes/console.php
Schedule::call(fn () => CollectionService::applyLateFees())
    ->dailyAt('01:00');

Schedule::call(fn () => ReconciliationService::runNightlyBatch())
    ->dailyAt('00:01');

Schedule::call(fn () => BankClearingService::runAutoMatch())
    ->everyThirtyMinutes();
```

Run the scheduler in production: `php artisan schedule:work`
