<?php
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// Scheduled jobs
Schedule::call(fn () => \App\Services\CollectionService::applyLateFees())
    ->dailyAt('01:00')
    ->name('apply-late-fees');

Schedule::call(fn () => \App\Services\ReconciliationService::runNightlyBatch())
    ->dailyAt('00:01')
    ->name('nightly-recon-batch');

Schedule::call(fn () => \App\Services\BankClearingService::runAutoMatch())
    ->everyThirtyMinutes()
    ->name('bank-auto-match');
