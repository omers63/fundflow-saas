<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Transaction extends Model
{
    protected $guarded = [];
    protected $casts = [
        'dr_amount'      => 'decimal:2',
        'cr_amount'      => 'decimal:2',
        'effective_date' => 'date',
    ];

    public function member(): BelongsTo { return $this->belongsTo(Member::class); }
    public function loan(): BelongsTo   { return $this->belongsTo(Loan::class); }

    public function getAmountAttribute(): float
    {
        return $this->cr_amount > 0 ? (float)$this->cr_amount : -(float)$this->dr_amount;
    }
}
