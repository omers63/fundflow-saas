<?php
namespace App\Models;

use App\Enums\MigrationClassification;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MigrationStub extends Model
{
    protected $guarded = [];
    protected $casts = [
        'cycle_date'     => 'date',
        'amount_due'     => 'decimal:2',
        'classification' => MigrationClassification::class,
        'classified_at'  => 'datetime',
    ];

    public function member(): BelongsTo { return $this->belongsTo(Member::class); }
}
