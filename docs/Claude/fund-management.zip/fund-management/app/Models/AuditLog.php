<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AuditLog extends Model
{
    public $timestamps = false;
    protected $guarded = [];
    protected $casts   = ['meta' => 'array', 'created_at' => 'datetime'];

    public static function record(
        string $event,
        string $domain,
        string $description,
        string $tag = '',
        array  $meta = [],
        ?int   $actorId = null,
        ?int   $entityId = null
    ): self {
        return static::create([
            'event_type'  => $event,
            'domain'      => $domain,
            'description' => $description,
            'tag'         => $tag,
            'meta'        => $meta,
            'actor_id'    => $actorId ?? auth()->id(),
            'entity_id'   => $entityId,
            'created_at'  => now(),
        ]);
    }
}
