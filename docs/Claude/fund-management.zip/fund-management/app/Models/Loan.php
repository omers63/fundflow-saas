<?php
namespace App\Models;

use App\Enums\LoanStatus;
use App\Enums\LoanType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Loan extends Model
{
    protected $guarded = [];

    protected $casts = [
        'type'                 => LoanType::class,
        'status'               => LoanStatus::class,
        'requested_amount'     => 'decimal:2',
        'approved_amount'      => 'decimal:2',
        'disbursed_amount'     => 'decimal:2',
        'member_portion'       => 'decimal:2',
        'master_portion'       => 'decimal:2',
        'settlement_threshold' => 'decimal:2',
        'total_repaid'         => 'decimal:2',
        'emi_amount'           => 'decimal:2',
        'approved_at'          => 'datetime',
        'fully_disbursed_at'   => 'datetime',
        'overdue_since'        => 'datetime',
        'guarantor_notified_at'=> 'datetime',
        'transferred_at'       => 'datetime',
    ];

    public function member(): BelongsTo    { return $this->belongsTo(Member::class); }
    public function guarantor(): BelongsTo { return $this->belongsTo(Member::class, 'guarantor_id'); }
    public function emiCycles(): HasMany   { return $this->hasMany(EmiCycle::class); }
    public function disbursements(): HasMany { return $this->hasMany(Disbursement::class); }

    public function getRepaidPercentAttribute(): float
    {
        if (!$this->settlement_threshold) return 0;
        return round(($this->total_repaid / $this->settlement_threshold) * 100, 1);
    }

    public function getRemainingThresholdAttribute(): float
    {
        return max(0, $this->settlement_threshold - $this->total_repaid);
    }
}
