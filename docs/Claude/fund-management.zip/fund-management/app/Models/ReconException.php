<?php
namespace App\Models;

use App\Enums\ReconSeverity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ReconException extends Model
{
    protected $guarded = [];
    protected $casts = [
        'severity'               => ReconSeverity::class,
        'amount_delta'           => 'decimal:2',
        'auto_resolve_attempted' => 'boolean',
        'raised_at'              => 'datetime',
        'sla_deadline'           => 'datetime',
        'resolved_at'            => 'datetime',
        'is_open'                => 'boolean',
    ];

    public function affectedMember(): BelongsTo
    {
        return $this->belongsTo(Member::class, 'affected_member_id');
    }
}
