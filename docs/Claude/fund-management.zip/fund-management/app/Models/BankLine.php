<?php
namespace App\Models;

use App\Enums\BankLineStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BankLine extends Model
{
    protected $guarded = [];
    protected $casts = [
        'import_date'       => 'date',
        'amount'            => 'decimal:2',
        'adjustment_amount' => 'decimal:2',
        'status'            => BankLineStatus::class,
        'matched_at'        => 'datetime',
    ];

    public function matchedMember(): BelongsTo
    {
        return $this->belongsTo(Member::class, 'matched_member_id');
    }
}
