<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SystemConfig extends Model
{
    protected $guarded = [];
    protected $casts = [
        'grace_period_options' => 'array',
        'emi_tiers'            => 'array',
        'min_fund_balance'     => 'decimal:2',
        'recon_tolerance'      => 'decimal:4',
    ];

    public static function current(): self
    {
        return static::firstOrCreate([], [
            'collection_window_days'        => 5,
            'late_fee_model'                => 'replacement',
            'late_fee_tier1_day'            => 3,
            'late_fee_tier1_amount'         => 50,
            'late_fee_tier2_day'            => 10,
            'late_fee_tier2_amount'         => 100,
            'late_fee_tier3_day'            => 20,
            'late_fee_tier3_amount'         => 200,
            'min_membership_years'          => 2,
            'min_fund_balance'              => 5000,
            'borrow_multiplier'             => 3,
            'max_active_loans'              => 2,
            'settlement_threshold_pct'      => 5,
            'grace_period_options'          => [0, 1, 2],
            'guarantor_warning_threshold'   => 3,
            'guarantor_liability_threshold' => 6,
            'recon_tolerance'               => 0.01,
            'timing_diff_defer_hours'       => 48,
            'bank_match_date_range_days'    => 3,
            'stale_pending_days'            => 30,
            'cash_deposit_unbanked_days'    => 7,
            'migration_instalment_cycles'   => 12,
            'emi_tiers'                     => [
                ['min' => 1000,  'max' => 10000, 'emi' => 1000],
                ['min' => 11000, 'max' => 30000, 'emi' => 1500],
                ['min' => 31000, 'max' => 60000, 'emi' => 2500],
            ],
            'fund_tier_a_pct' => 30,
            'fund_tier_b_pct' => 40,
            'fund_tier_c_pct' => 50,
            'fund_tier_e_pct' => 20,
        ]);
    }
}
