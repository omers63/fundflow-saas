<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Disbursement extends Model
{
    protected $guarded = [];
    protected $casts = ['amount' => 'decimal:2', 'posted_at' => 'datetime'];

    public function loan(): BelongsTo { return $this->belongsTo(Loan::class); }
}
