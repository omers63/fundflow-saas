<?php
namespace App\Models;

use App\Enums\CycleStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ContributionCycle extends Model
{
    protected $guarded = [];

    protected $casts = [
        'cycle_month'      => 'date',
        'due_amount'       => 'decimal:2',
        'collected_amount' => 'decimal:2',
        'late_fee_amount'  => 'decimal:2',
        'status'           => CycleStatus::class,
        'overdue_since'    => 'datetime',
        'collected_at'     => 'datetime',
        'is_migration'     => 'boolean',
    ];

    public function member(): BelongsTo { return $this->belongsTo(Member::class); }

    public function getDaysLateAttribute(): ?int
    {
        return $this->overdue_since?->diffInDays(now());
    }
}
