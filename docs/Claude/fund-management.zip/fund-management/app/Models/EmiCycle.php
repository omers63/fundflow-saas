<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class EmiCycle extends Model
{
    protected $guarded = [];

    protected $casts = [
        'cycle_month'   => 'date',
        'emi_due'       => 'decimal:2',
        'emi_collected' => 'decimal:2',
        'late_fee'      => 'decimal:2',
        'overdue_since' => 'datetime',
        'collected_at'  => 'datetime',
    ];

    public function loan(): BelongsTo { return $this->belongsTo(Loan::class); }
}
