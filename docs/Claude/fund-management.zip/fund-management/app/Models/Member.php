<?php
namespace App\Models;

use App\Enums\MemberStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Member extends Authenticatable
{
    protected $fillable = [
        'name','email','password','phone','national_id',
        'join_date','migration_cutoff_date','status',
        'cash_balance','fund_balance','opening_cash_balance',
        'opening_fund_balance','migration_cleared_at','migration_cleared_by',
    ];

    protected $casts = [
        'join_date'             => 'date',
        'migration_cutoff_date' => 'date',
        'migration_cleared_at'  => 'datetime',
        'status'                => MemberStatus::class,
        'cash_balance'          => 'decimal:2',
        'fund_balance'          => 'decimal:2',
        'opening_cash_balance'  => 'decimal:2',
        'opening_fund_balance'  => 'decimal:2',
        'password'              => 'hashed',
    ];

    protected $hidden = ['password','remember_token'];

    public function loans(): HasMany
    {
        return $this->hasMany(Loan::class);
    }

    public function activeLoans(): HasMany
    {
        return $this->hasMany(Loan::class)
            ->whereIn('status',['active','partially_disbursed']);
    }

    public function contributionCycles(): HasMany
    {
        return $this->hasMany(ContributionCycle::class);
    }

    public function transactions(): HasMany
    {
        return $this->hasMany(Transaction::class);
    }

    public function migrationStubs(): HasMany
    {
        return $this->hasMany(MigrationStub::class);
    }

    public function guaranteedLoans(): HasMany
    {
        return $this->hasMany(Loan::class,'guarantor_id');
    }

    public function getTenureYearsAttribute(): float
    {
        return round($this->join_date->diffInYears(now()),1);
    }

    public function getBorrowCapAttribute(): float
    {
        $config = SystemConfig::first();
        return $this->fund_balance * ($config?->borrow_multiplier ?? 3);
    }

    public function hasActiveLoan(): bool
    {
        return $this->activeLoans()->exists();
    }

    public function isEligibleForLoan(): array
    {
        $config = SystemConfig::first();
        $errors = [];
        $minYears   = $config?->min_membership_years ?? 2;
        $minBalance = $config?->min_fund_balance ?? 5000;
        $maxLoans   = $config?->max_active_loans ?? 2;

        if ($this->tenure_years < $minYears) {
            $errors['tenure'] = "Requires {$minYears} years membership.";
        }
        if ($this->fund_balance < $minBalance) {
            $errors['balance'] = "Minimum fund balance SAR {$minBalance} not met.";
        }
        if ($this->status === MemberStatus::Delinquent) {
            $errors['delinquent'] = 'Account is delinquent.';
        }
        if ($this->status === MemberStatus::Suspended) {
            $errors['suspended'] = 'Account is suspended.';
        }
        if ($this->activeLoans()->count() >= $maxLoans) {
            $errors['loan_limit'] = "Maximum {$maxLoans} active loans reached.";
        }
        return $errors;
    }
}
