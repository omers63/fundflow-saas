<?php
namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}

    public function boot(): void
    {
        // Register Filament panel providers
        $this->app->register(\App\Filament\Admin\AdminPanelProvider::class);
        $this->app->register(\App\Filament\Member\MemberPanelProvider::class);
    }
}
