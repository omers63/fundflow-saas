<?php
namespace App\Filament\Member\Widgets;

use App\Models\Loan;
use Filament\Widgets\Widget;

class ActiveLoanWidget extends Widget
{
    protected static ?int    $sort             = 2;
    protected int | string | array $columnSpan = 2;
    protected static string  $view             = 'filament.member.widgets.active-loan';

    public function getActiveLoan(): ?Loan
    {
        return auth()->user()->activeLoans()->with(['emiCycles','guarantor'])->first();
    }
}
