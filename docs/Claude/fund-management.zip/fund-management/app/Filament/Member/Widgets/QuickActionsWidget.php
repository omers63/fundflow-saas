<?php
namespace App\Filament\Member\Widgets;

use Filament\Widgets\Widget;

class QuickActionsWidget extends Widget
{
    protected static ?int    $sort             = 3;
    protected int | string | array $columnSpan = 2;
    protected static string  $view             = 'filament.member.widgets.quick-actions';
}
