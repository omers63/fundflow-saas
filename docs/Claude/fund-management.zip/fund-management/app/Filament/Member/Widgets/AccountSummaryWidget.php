<?php
namespace App\Filament\Member\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class AccountSummaryWidget extends BaseWidget
{
    protected static ?int $sort = 1;

    protected function getStats(): array
    {
        $member = auth()->user();
        return [
            Stat::make('Cash account', 'SAR ' . number_format($member->cash_balance, 2))
                ->description('Available balance')
                ->icon('heroicon-o-wallet')
                ->color('success'),

            Stat::make('Fund account', 'SAR ' . number_format($member->fund_balance, 2))
                ->description('Accumulated contributions')
                ->icon('heroicon-o-building-library')
                ->color('primary'),

            Stat::make('Borrow capacity', 'SAR ' . number_format($member->borrow_cap, 2))
                ->description('× ' . (\App\Models\SystemConfig::current()->borrow_multiplier) . ' fund balance')
                ->icon('heroicon-o-arrow-trending-up')
                ->color('info'),

            Stat::make('Member since', $member->join_date->format('M Y'))
                ->description($member->tenure_years . ' years tenure')
                ->icon('heroicon-o-user')
                ->color('gray'),
        ];
    }
}
