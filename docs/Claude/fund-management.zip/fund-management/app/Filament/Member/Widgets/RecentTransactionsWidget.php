<?php
namespace App\Filament\Member\Widgets;

use App\Models\Transaction;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class RecentTransactionsWidget extends BaseWidget
{
    protected static ?int    $sort              = 4;
    protected int | string | array $columnSpan  = 'full';
    protected static ?string $heading           = 'Recent transactions';

    public function table(Table $table): Table
    {
        return $table
            ->query(
                Transaction::query()
                    ->where('member_id', auth()->id())
                    ->latest('effective_date')
                    ->limit(8)
            )
            ->columns([
                Tables\Columns\TextColumn::make('description')->limit(50),
                Tables\Columns\TextColumn::make('effective_date')->date()->label('Date'),
                Tables\Columns\TextColumn::make('cr_amount')
                    ->label('Credit')
                    ->money('SAR')
                    ->color('success')
                    ->default('—'),
                Tables\Columns\TextColumn::make('dr_amount')
                    ->label('Debit')
                    ->money('SAR')
                    ->color('danger')
                    ->default('—'),
                Tables\Columns\BadgeColumn::make('tag'),
            ]);
    }
}
