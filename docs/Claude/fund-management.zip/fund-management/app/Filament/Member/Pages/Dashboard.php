<?php
namespace App\Filament\Member\Pages;

use Filament\Pages\Dashboard as BaseDashboard;

class Dashboard extends BaseDashboard
{
    protected static ?string $navigationIcon = 'heroicon-o-home';
    protected static ?string $title          = 'Overview';

    public function getWidgets(): array
    {
        return [
            \App\Filament\Member\Widgets\AccountSummaryWidget::class,
            \App\Filament\Member\Widgets\ActiveLoanWidget::class,
            \App\Filament\Member\Widgets\QuickActionsWidget::class,
            \App\Filament\Member\Widgets\RecentTransactionsWidget::class,
        ];
    }
}
