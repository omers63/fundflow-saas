<?php
namespace App\Filament\Member\Pages;

use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Forms;
use Filament\Pages\Page;
use Filament\Notifications\Notification;

class Statements extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon  = 'heroicon-o-arrow-down-tray';
    protected static ?string $navigationLabel = 'Statements';
    protected static ?string $navigationGroup = 'Self-Service';
    protected static ?int    $navigationSort  = 7;
    protected static string  $view            = 'filament.member.pages.statements';

    public ?array $data = [];

    public function mount(): void { $this->form->fill(['format'=>'pdf']); }

    public function form(Form $form): Form
    {
        $member = auth()->user();
        return $form->schema([
            Forms\Components\Select::make('type')
                ->label('Statement type')
                ->options([
                    'combined'     => 'Combined (cash + fund)',
                    'cash'         => 'Cash account only',
                    'fund'         => 'Fund account only',
                    'loan'         => 'Active loan schedule',
                    'contributions'=> 'Contribution history',
                ])->required(),
            Forms\Components\DatePicker::make('date_from')->label('From')->required(),
            Forms\Components\DatePicker::make('date_to')->label('To')->required(),
            Forms\Components\Select::make('format')
                ->options(['pdf'=>'PDF','xlsx'=>'Excel (.xlsx)','csv'=>'CSV'])
                ->default('pdf')->required(),
        ])->statePath('data');
    }

    public function generate(): void
    {
        $this->form->validate();
        Notification::make()->title('Statement queued')->body('Your statement will be ready shortly.')->success()->send();
    }
}
