<?php
namespace App\Filament\Member\Pages;

use App\Models\Transaction;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Forms;
use Filament\Pages\Page;
use Filament\Notifications\Notification;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Filament\Tables;

class CashAccount extends Page implements HasForms, HasTable
{
    use InteractsWithForms, InteractsWithTable;

    protected static ?string $navigationIcon  = 'heroicon-o-wallet';
    protected static ?string $navigationLabel = 'Cash Account';
    protected static ?string $navigationGroup = 'My Accounts';
    protected static ?int    $navigationSort  = 2;
    protected static string  $view            = 'filament.member.pages.cash-account';

    public ?array $data = [];

    public function mount(): void { $this->form->fill(); }

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Deposit funds')->schema([
                Forms\Components\Select::make('method')
                    ->label('Deposit method')
                    ->options(['bank_transfer'=>'Bank transfer (IBAN)','direct_cash'=>'Direct cash deposit'])
                    ->required(),
                Forms\Components\TextInput::make('amount')
                    ->numeric()->prefix('SAR')->required()->minValue(1),
                Forms\Components\TextInput::make('reference')
                    ->label('Reference / notes (optional)'),
            ])->columns(3),
        ])->statePath('data');
    }

    public function deposit(): void
    {
        $this->form->validate();
        $data   = $this->form->getState();
        $member = auth()->user();
        $member->increment('cash_balance', $data['amount']);
        Transaction::create([
            'member_id'      => $member->id,
            'type'           => 'deposit',
            'description'    => 'Cash deposit — ' . $data['method'],
            'cr_amount'      => $data['amount'],
            'dr_amount'      => 0,
            'account'        => 'cash',
            'reference'      => $data['reference'],
            'tag'            => 'DEPOSIT',
            'effective_date' => now()->toDateString(),
        ]);
        Notification::make()->title('Deposit recorded')->success()->send();
        $this->form->fill();
    }

    public function table(Table $table): Table
    {
        return $table
            ->query(Transaction::where('member_id', auth()->id())->where('account','cash')->latest('effective_date'))
            ->columns([
                Tables\Columns\TextColumn::make('description')->limit(50),
                Tables\Columns\TextColumn::make('effective_date')->date(),
                Tables\Columns\TextColumn::make('cr_amount')->money('SAR')->label('Credit')->color('success'),
                Tables\Columns\TextColumn::make('dr_amount')->money('SAR')->label('Debit')->color('danger'),
                Tables\Columns\BadgeColumn::make('tag'),
            ]);
    }
}
