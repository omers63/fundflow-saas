<?php
namespace App\Filament\Member\Pages;

use App\Models\Transaction;
use Filament\Pages\Page;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Filament\Tables;

class Transactions extends Page implements HasTable
{
    use InteractsWithTable;

    protected static ?string $navigationIcon  = 'heroicon-o-clock';
    protected static ?string $navigationLabel = 'Transactions';
    protected static ?string $navigationGroup = 'History';
    protected static ?int    $navigationSort  = 9;
    protected static string  $view            = 'filament.member.pages.transactions';

    public function table(Table $table): Table
    {
        return $table
            ->query(Transaction::where('member_id', auth()->id())->latest('effective_date'))
            ->columns([
                Tables\Columns\TextColumn::make('description')->limit(50)->searchable(),
                Tables\Columns\TextColumn::make('effective_date')->date()->sortable(),
                Tables\Columns\TextColumn::make('cr_amount')->money('SAR')->label('Credit')->color('success'),
                Tables\Columns\TextColumn::make('dr_amount')->money('SAR')->label('Debit')->color('danger'),
                Tables\Columns\TextColumn::make('account')->badge(),
                Tables\Columns\BadgeColumn::make('tag'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('tag')
                    ->options([
                        'CONTRIBUTION' => 'Contributions',
                        'EMI'          => 'EMI',
                        'DEPOSIT'      => 'Deposits',
                        'LATE_FEE'     => 'Late fees',
                        'LOAN'         => 'Loan events',
                        'CASH_OUT'     => 'Cash outs',
                    ]),
            ]);
    }
}
