<?php
namespace App\Filament\Member\Pages;

use App\Models\Loan;
use Filament\Pages\Page;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Filament\Tables;

class MyLoans extends Page implements HasTable
{
    use InteractsWithTable;

    protected static ?string $navigationIcon  = 'heroicon-o-currency-dollar';
    protected static ?string $navigationLabel = 'My Loans';
    protected static ?string $navigationGroup = 'Loans';
    protected static ?int    $navigationSort  = 4;
    protected static string  $view            = 'filament.member.pages.my-loans';

    public function getActiveLoans(): \Illuminate\Database\Eloquent\Collection
    {
        return auth()->user()->activeLoans()->with(['emiCycles','guarantor'])->get();
    }

    public function table(Table $table): Table
    {
        return $table
            ->query(Loan::where('member_id', auth()->id()))
            ->columns([
                Tables\Columns\TextColumn::make('loan_number')->label('Loan #'),
                Tables\Columns\TextColumn::make('requested_amount')->money('SAR'),
                Tables\Columns\BadgeColumn::make('status'),
                Tables\Columns\TextColumn::make('created_at')->date()->label('Approved'),
                Tables\Columns\TextColumn::make('total_repaid')->money('SAR')->label('Repaid'),
            ])
            ->actions([
                Tables\Actions\Action::make('view')
                    ->url(fn (Loan $r) => route('filament.member.pages.settle-loan', $r))
                    ->label('Settle'),
            ]);
    }
}
