<?php
namespace App\Filament\Member\Pages;

use App\Enums\LoanType;
use App\Models\Loan;
use App\Models\Member;
use App\Models\SystemConfig;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Forms;
use Filament\Pages\Page;
use Filament\Notifications\Notification;

class LoanRequest extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon  = 'heroicon-o-document-text';
    protected static ?string $navigationLabel = 'Request a Loan';
    protected static ?string $navigationGroup = 'Loans';
    protected static ?int    $navigationSort  = 5;
    protected static string  $view            = 'filament.member.pages.loan-request';

    public ?array $data = [];
    public int $step = 1;

    public function mount(): void { $this->form->fill(); }

    public function getEligibilityChecks(): array
    {
        $member = auth()->user();
        $config = SystemConfig::current();
        return [
            ['label' => 'Membership tenure', 'pass' => $member->tenure_years >= $config->min_membership_years, 'detail' => $member->tenure_years . ' yrs — min ' . $config->min_membership_years],
            ['label' => 'Fund balance', 'pass' => $member->fund_balance >= $config->min_fund_balance, 'detail' => 'SAR ' . number_format($member->fund_balance,0) . ' — min SAR ' . number_format($config->min_fund_balance,0)],
            ['label' => 'No delinquency', 'pass' => !in_array($member->status->value, ['delinquent','suspended']), 'detail' => 'Status: ' . $member->status->getLabel()],
            ['label' => 'Active loan count', 'pass' => $member->activeLoans()->count() < $config->max_active_loans, 'detail' => $member->activeLoans()->count() . ' active — max ' . $config->max_active_loans],
            ['label' => 'Borrow limit', 'pass' => true, 'detail' => 'Max SAR ' . number_format($member->borrow_cap,0)],
        ];
    }

    public function form(Form $form): Form
    {
        $member = auth()->user();
        return $form->schema([
            Forms\Components\Wizard::make([
                Forms\Components\Wizard\Step::make('Eligibility')
                    ->description('Pre-qualification check')
                    ->schema([
                        Forms\Components\Placeholder::make('eligibility_info')
                            ->content('All eligibility checks must pass before proceeding.'),
                    ]),

                Forms\Components\Wizard\Step::make('Loan Details')
                    ->schema([
                        Forms\Components\Select::make('type')
                            ->label('Loan type')
                            ->options(LoanType::class)
                            ->default('standard')->required(),
                        Forms\Components\TextInput::make('requested_amount')
                            ->numeric()->prefix('SAR')
                            ->maxValue($member->borrow_cap)
                            ->helperText('Max eligible: SAR ' . number_format($member->borrow_cap,0))
                            ->required(),
                        Forms\Components\Select::make('grace_cycles')
                            ->label('Grace period')
                            ->options([0=>'0 cycles — start immediately',1=>'1 cycle grace',2=>'2 cycles grace'])
                            ->default(0)->required(),
                        Forms\Components\Textarea::make('purpose')
                            ->label('Purpose (optional)'),
                    ])->columns(2),

                Forms\Components\Wizard\Step::make('Guarantor')
                    ->schema([
                        Forms\Components\Select::make('guarantor_id')
                            ->label('Guarantor member')
                            ->options(Member::where('id','!=',auth()->id())
                                ->where('status','active')
                                ->pluck('name','id'))
                            ->searchable()->required(),
                    ]),

                Forms\Components\Wizard\Step::make('Review & Submit')
                    ->schema([
                        Forms\Components\Placeholder::make('review_note')
                            ->content('Please confirm your loan request details below. Once submitted, your request will enter the approval queue.'),
                    ]),
            ]),
        ])->statePath('data');
    }

    public function submit(): void
    {
        $data   = $this->form->getState();
        $member = auth()->user();
        $errors = $member->isEligibleForLoan();

        if (!empty($errors)) {
            Notification::make()->title('Eligibility check failed')->body(implode(' ',$errors))->danger()->send();
            return;
        }

        $count   = Loan::where('type','emergency')->where('status','pending_admin')->count();
        $position = $data['type'] === 'emergency' ? 1 : Loan::where('status','pending_admin')->count() + 1;

        Loan::create([
            'member_id'        => $member->id,
            'guarantor_id'     => $data['guarantor_id'],
            'loan_number'      => 'L-' . str_pad(Loan::count() + 1, 4, '0', STR_PAD_LEFT),
            'type'             => $data['type'],
            'status'           => 'pending_admin',
            'requested_amount' => $data['requested_amount'],
            'grace_cycles'     => $data['grace_cycles'],
            'queue_position'   => $position,
        ]);

        Notification::make()->title('Loan request submitted')->body('Your request is in the approval queue.')->success()->send();
        redirect()->route('filament.member.pages.my-loans');
    }
}
