<?php
namespace App\Filament\Member\Pages;

use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Forms;
use Filament\Pages\Page;
use Filament\Notifications\Notification;

class Settings extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon  = 'heroicon-o-cog-6-tooth';
    protected static ?string $navigationLabel = 'Settings';
    protected static ?string $navigationGroup = 'Self-Service';
    protected static ?int    $navigationSort  = 10;
    protected static string  $view            = 'filament.member.pages.settings';

    public ?array $data = [];

    public function mount(): void
    {
        $this->form->fill(auth()->user()->only('name','email','phone'));
    }

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Tabs::make('Settings')->tabs([
                Forms\Components\Tabs\Tab::make('Profile')->schema([
                    Forms\Components\TextInput::make('name')->required(),
                    Forms\Components\TextInput::make('email')->email()->required(),
                    Forms\Components\TextInput::make('phone')->tel(),
                ])->columns(2),

                Forms\Components\Tabs\Tab::make('Notifications')->schema([
                    Forms\Components\Select::make('notif_emi')
                        ->label('EMI due reminder')
                        ->options(['sms_email'=>'SMS + Email','email'=>'Email only','sms'=>'SMS only','off'=>'Off'])
                        ->default('sms_email'),
                    Forms\Components\Select::make('notif_contribution')
                        ->label('Contribution debit')
                        ->options(['sms_email'=>'SMS + Email','email'=>'Email only'])
                        ->default('sms_email'),
                    Forms\Components\Select::make('notif_late_fee')
                        ->label('Late fee applied')
                        ->options(['sms_email'=>'SMS + Email','email'=>'Email only'])
                        ->default('sms_email'),
                    Forms\Components\Select::make('notif_deposit')
                        ->label('Deposit received')
                        ->options(['email'=>'Email only','sms_email'=>'SMS + Email'])
                        ->default('email'),
                ])->columns(2),

                Forms\Components\Tabs\Tab::make('Security')->schema([
                    Forms\Components\TextInput::make('current_password')->password()->revealable(),
                    Forms\Components\TextInput::make('new_password')->password()->revealable(),
                    Forms\Components\TextInput::make('new_password_confirmation')->password()->revealable()->label('Confirm new password'),
                ])->columns(1),
            ])->columnSpanFull(),
        ])->statePath('data');
    }

    public function save(): void
    {
        $data   = $this->form->getState();
        $member = auth()->user();
        $member->update(['name' => $data['name'], 'email' => $data['email'], 'phone' => $data['phone']]);
        Notification::make()->title('Settings saved')->success()->send();
    }
}
