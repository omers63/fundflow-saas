<?php
namespace App\Filament\Member\Pages;

use App\Models\ContributionCycle;
use Filament\Pages\Page;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Filament\Tables;
use Filament\Widgets\StatsOverviewWidget\Stat;

class Contributions extends Page implements HasTable
{
    use InteractsWithTable;

    protected static ?string $navigationIcon  = 'heroicon-o-calendar-days';
    protected static ?string $navigationLabel = 'Contributions';
    protected static ?string $navigationGroup = 'History';
    protected static ?int    $navigationSort  = 8;
    protected static string  $view            = 'filament.member.pages.contributions';

    public function getStats(): array
    {
        $member = auth()->user();
        return [
            'total'   => $member->fund_balance,
            'missed'  => $member->contributionCycles()->whereIn('status',['overdue','late_t1','late_t2','late_t3'])->count(),
            'exempt'  => $member->contributionCycles()->where('status','exempt')->count(),
        ];
    }

    public function table(Table $table): Table
    {
        return $table
            ->query(ContributionCycle::where('member_id', auth()->id())->latest('cycle_month'))
            ->columns([
                Tables\Columns\TextColumn::make('cycle_month')->date('M Y')->label('Cycle'),
                Tables\Columns\BadgeColumn::make('status'),
                Tables\Columns\TextColumn::make('due_amount')->money('SAR')->label('Due'),
                Tables\Columns\TextColumn::make('collected_amount')->money('SAR')->label('Collected'),
                Tables\Columns\TextColumn::make('late_fee_amount')->money('SAR')->label('Late fee'),
                Tables\Columns\TextColumn::make('days_late')->label('Days late')->default('—'),
            ]);
    }
}
