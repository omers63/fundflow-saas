<?php
namespace App\Filament\Member\Pages;

use App\Models\Transaction;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Forms;
use Filament\Pages\Page;
use Filament\Notifications\Notification;

class CashOut extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon  = 'heroicon-o-banknotes';
    protected static ?string $navigationLabel = 'Cash Out';
    protected static ?string $navigationGroup = 'Self-Service';
    protected static ?int    $navigationSort  = 6;
    protected static string  $view            = 'filament.member.pages.cash-out';

    public ?array $data = [];

    public function mount(): void { $this->form->fill(); }

    public function getAvailableBalance(): float
    {
        $member  = auth()->user();
        $reserved = $member->activeLoans->sum('emi_amount');
        return max(0, $member->cash_balance - $reserved);
    }

    public function form(Form $form): Form
    {
        $available = $this->getAvailableBalance();
        return $form->schema([
            Forms\Components\TextInput::make('amount')
                ->numeric()->prefix('SAR')->required()
                ->maxValue($available)
                ->helperText("Available to withdraw: SAR " . number_format($available,2)),
            Forms\Components\Select::make('destination')
                ->label('Destination account')
                ->options(['registered_iban'=>'Registered IBAN','other'=>'Other bank account'])
                ->required(),
            Forms\Components\TextInput::make('notes')->label('Reference (optional)'),
        ])->statePath('data');
    }

    public function submit(): void
    {
        $data      = $this->form->getState();
        $member    = auth()->user();
        $available = $this->getAvailableBalance();

        if ($data['amount'] > $available) {
            Notification::make()->title('Insufficient balance')->danger()->send();
            return;
        }

        $member->decrement('cash_balance', $data['amount']);
        Transaction::create([
            'member_id'      => $member->id,
            'type'           => 'cash_out',
            'description'    => 'Cash out — ' . $data['destination'],
            'dr_amount'      => $data['amount'],
            'cr_amount'      => 0,
            'account'        => 'cash',
            'reference'      => $data['notes'],
            'tag'            => 'CASH_OUT',
            'effective_date' => now()->toDateString(),
        ]);

        Notification::make()->title('Cash out submitted')->body('Your withdrawal is being processed.')->success()->send();
        $this->form->fill();
    }
}
