<?php
namespace App\Filament\Member\Pages;

use App\Models\Transaction;
use Filament\Pages\Page;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Filament\Tables;

class FundAccount extends Page implements HasTable
{
    use InteractsWithTable;

    protected static ?string $navigationIcon  = 'heroicon-o-building-library';
    protected static ?string $navigationLabel = 'Fund Account';
    protected static ?string $navigationGroup = 'My Accounts';
    protected static ?int    $navigationSort  = 3;
    protected static string  $view            = 'filament.member.pages.fund-account';

    public function table(Table $table): Table
    {
        return $table
            ->query(Transaction::where('member_id', auth()->id())->where('account','fund')->latest('effective_date'))
            ->columns([
                Tables\Columns\TextColumn::make('description')->limit(50),
                Tables\Columns\TextColumn::make('effective_date')->date()->label('Cycle'),
                Tables\Columns\TextColumn::make('cr_amount')->money('SAR')->label('Amount'),
                Tables\Columns\BadgeColumn::make('tag'),
            ]);
    }
}
