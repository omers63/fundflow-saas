<?php
namespace App\Filament\Admin\Resources;

use App\Enums\CycleStatus;
use App\Filament\Admin\Resources\CycleResource\Pages;
use App\Models\ContributionCycle;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class CycleResource extends Resource
{
    protected static ?string $model           = ContributionCycle::class;
    protected static ?string $navigationIcon  = 'heroicon-o-calendar-days';
    protected static ?string $navigationGroup = 'Operations';
    protected static ?string $navigationLabel = 'Collection Cycles';
    protected static ?int    $navigationSort  = 4;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Select::make('member_id')
                ->relationship('member', 'name')->searchable()->preload()->required(),
            Forms\Components\DatePicker::make('cycle_month')->required(),
            Forms\Components\TextInput::make('due_amount')->numeric()->prefix('SAR')->required(),
            Forms\Components\TextInput::make('collected_amount')->numeric()->prefix('SAR')->default(0),
            Forms\Components\TextInput::make('late_fee_amount')->numeric()->prefix('SAR')->default(0),
            Forms\Components\Select::make('status')->options(CycleStatus::class)->required(),
            Forms\Components\DateTimePicker::make('overdue_since'),
            Forms\Components\DateTimePicker::make('collected_at'),
            Forms\Components\Toggle::make('is_migration')->label('Migration cycle'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('member.name')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('cycle_month')->date('M Y')->sortable(),
                Tables\Columns\TextColumn::make('due_amount')->money('SAR'),
                Tables\Columns\TextColumn::make('collected_amount')->money('SAR'),
                Tables\Columns\BadgeColumn::make('status'),
                Tables\Columns\TextColumn::make('late_fee_amount')->money('SAR')->label('Late fee'),
                Tables\Columns\IconColumn::make('is_migration')->boolean()->label('Migration'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')->options(CycleStatus::class),
                Tables\Filters\TernaryFilter::make('is_migration')->label('Migration cycles'),
            ])
            ->headerActions([
                Tables\Actions\Action::make('run_debit_batch')
                    ->label('Run debit batch')
                    ->icon('heroicon-o-play')
                    ->color('success')
                    ->requiresConfirmation()
                    ->action(fn () => \App\Services\CollectionService::runDebitBatch()),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\Action::make('post_manual')
                    ->label('Post manual')
                    ->icon('heroicon-o-pencil-square')
                    ->form([
                        Forms\Components\TextInput::make('amount')->numeric()->prefix('SAR')->required(),
                        Forms\Components\Textarea::make('notes'),
                    ])
                    ->action(fn (ContributionCycle $r, array $d) =>
                        \App\Services\CollectionService::postManual($r, $d['amount'], $d['notes'] ?? ''))
                    ->visible(fn (ContributionCycle $r) =>
                        in_array($r->status->value, ['overdue','late_t1','late_t2','late_t3','partial','pending'])),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListCycles::route('/'),
            'create' => Pages\CreateCycle::route('/create'),
            'edit'   => Pages\EditCycle::route('/{record}/edit'),
        ];
    }
}
