<?php
namespace App\Filament\Admin\Resources;

use App\Enums\ReconSeverity;
use App\Filament\Admin\Resources\ReconResource\Pages;
use App\Models\ReconException;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Notifications\Notification;

class ReconResource extends Resource
{
    protected static ?string $model           = ReconException::class;
    protected static ?string $navigationIcon  = 'heroicon-o-arrows-right-left';
    protected static ?string $navigationGroup = 'Finance';
    protected static ?string $navigationLabel = 'Reconciliation';
    protected static ?int    $navigationSort  = 6;

    public static function getNavigationBadge(): ?string
    {
        return (string) ReconException::where('is_open', true)->count() ?: null;
    }

    public static function getNavigationBadgeColor(): string|array|null
    {
        return ReconException::where('severity', 'critical')->where('is_open', true)->exists()
            ? 'danger' : 'warning';
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('exception_type')->required(),
            Forms\Components\TextInput::make('domain')->required(),
            Forms\Components\Select::make('severity')->options(ReconSeverity::class)->required(),
            Forms\Components\TextInput::make('amount_delta')->numeric()->prefix('SAR'),
            Forms\Components\Toggle::make('is_open')->default(true),
            Forms\Components\Select::make('resolution_action')
                ->options([
                    'post_correction'    => 'Post correction entry',
                    'reverse'            => 'Reverse transaction',
                    'reclassify'         => 'Reclassify',
                    'write_off'          => 'Write-off',
                    'escalate'           => 'Escalate',
                    'override_accept'    => 'Override and accept',
                ]),
            Forms\Components\Select::make('reason_code')
                ->options([
                    'rounding_emi'   => 'Rounding difference — EMI last instalment',
                    'fx_residual'    => 'FX conversion residual',
                    'manual_error'   => 'Manual posting error',
                    'timing_diff'    => 'Timing difference',
                    'other'          => 'Other',
                ]),
            Forms\Components\Textarea::make('resolution_notes')
                ->required(fn ($get) => $get('severity') === 'critical'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('raised_at','desc')
            ->columns([
                Tables\Columns\TextColumn::make('exception_type')->searchable(),
                Tables\Columns\TextColumn::make('domain'),
                Tables\Columns\BadgeColumn::make('severity'),
                Tables\Columns\TextColumn::make('amount_delta')->money('SAR')->label('Delta'),
                Tables\Columns\TextColumn::make('sla_deadline')->label('SLA')
                    ->dateTime()
                    ->color(fn ($record) => match($record?->severity?->value) {
                        'critical' => 'danger',
                        'high'     => 'warning',
                        default    => 'gray',
                    }),
                Tables\Columns\IconColumn::make('is_open')
                    ->boolean()->label('Open'),
                Tables\Columns\TextColumn::make('raised_at')->dateTime()->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('severity')->options(ReconSeverity::class),
                Tables\Filters\TernaryFilter::make('is_open')->label('Open exceptions'),
            ])
            ->headerActions([
                Tables\Actions\Action::make('run_batch')
                    ->label('Run batch now')
                    ->icon('heroicon-o-play')
                    ->color('primary')
                    ->requiresConfirmation()
                    ->action(fn () => \App\Services\ReconciliationService::runNightlyBatch()),
            ])
            ->actions([
                Tables\Actions\Action::make('resolve')
                    ->label('Resolve')
                    ->icon('heroicon-o-wrench-screwdriver')
                    ->color('primary')
                    ->form([
                        Forms\Components\Select::make('resolution_action')
                            ->options([
                                'post_correction' => 'Post correction entry',
                                'reverse'         => 'Reverse transaction',
                                'reclassify'      => 'Reclassify',
                                'write_off'       => 'Write-off',
                                'escalate'        => 'Escalate',
                                'override_accept' => 'Override and accept',
                            ])->required(),
                        Forms\Components\TextInput::make('correction_amount')->numeric()->prefix('SAR'),
                        Forms\Components\Select::make('reason_code')
                            ->options([
                                'rounding_emi' => 'Rounding — EMI last instalment',
                                'fx_residual'  => 'FX conversion residual',
                                'manual_error' => 'Manual posting error',
                                'timing_diff'  => 'Timing difference',
                                'other'        => 'Other',
                            ])->required(),
                        Forms\Components\Textarea::make('resolution_notes')->required(),
                    ])
                    ->action(function (ReconException $record, array $data) {
                        $record->update([
                            'resolution_action' => $data['resolution_action'],
                            'reason_code'       => $data['reason_code'],
                            'resolution_notes'  => $data['resolution_notes'],
                            'resolved_at'       => now(),
                            'resolved_by'       => auth()->id(),
                            'is_open'           => false,
                        ]);
                        \App\Models\AuditLog::record(
                            'RECON_MANUAL_RESOLUTION',
                            'reconciliation',
                            "Exception {$record->exception_type} resolved by admin",
                            'RECON',
                            $data,
                            auth()->id(),
                            $record->id
                        );
                        Notification::make()->title('Exception resolved')->success()->send();
                    })
                    ->visible(fn (ReconException $r) => $r->is_open),
                Tables\Actions\ViewAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListReconExceptions::route('/'),
            'view'   => Pages\ViewReconException::route('/{record}'),
        ];
    }
}
