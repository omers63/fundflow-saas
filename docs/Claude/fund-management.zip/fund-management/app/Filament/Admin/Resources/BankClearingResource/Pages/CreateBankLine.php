<?php
namespace App\Filament\Admin\Resources\BankClearingResource\Pages;
use App\Filament\Admin\Resources\BankClearingResource;
use Filament\Resources\Pages\CreateRecord;
class CreateBankLine extends CreateRecord { protected static string $resource = BankClearingResource::class; }
