<?php
namespace App\Filament\Admin\Resources\MigrationResource\Pages;
use App\Filament\Admin\Resources\MigrationResource;
use Filament\Resources\Pages\ListRecords;
class ListMigrationStubs extends ListRecords { protected static string $resource = MigrationResource::class; }
