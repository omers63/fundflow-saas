<?php
namespace App\Filament\Admin\Resources\BankClearingResource\Pages;
use App\Filament\Admin\Resources\BankClearingResource;
use Filament\Resources\Pages\ListRecords;
class ListBankLines extends ListRecords { protected static string $resource = BankClearingResource::class; }
