<?php
namespace App\Filament\Admin\Resources;

use App\Enums\MemberStatus;
use App\Filament\Admin\Resources\MemberResource\Pages;
use App\Models\Member;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class MemberResource extends Resource
{
    protected static ?string $model = Member::class;
    protected static ?string $navigationIcon  = 'heroicon-o-users';
    protected static ?string $navigationGroup = 'Operations';
    protected static ?int    $navigationSort  = 2;

    public static function getNavigationBadge(): ?string
    {
        return (string) Member::whereIn('status', ['migration_pending', 'delinquent'])->count() ?: null;
    }

    public static function getNavigationBadgeColor(): string|array|null
    {
        return 'warning';
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Personal Information')->schema([
                Forms\Components\TextInput::make('name')->required()->maxLength(255),
                Forms\Components\TextInput::make('email')->email()->required()->unique(ignoreRecord: true),
                Forms\Components\TextInput::make('phone')->tel(),
                Forms\Components\TextInput::make('national_id')->label('National ID / Iqama'),
            ])->columns(2),

            Forms\Components\Section::make('Membership')->schema([
                Forms\Components\DatePicker::make('join_date')->required(),
                Forms\Components\DatePicker::make('migration_cutoff_date')
                    ->label('Migration cutoff date')
                    ->helperText('Leave blank for new (non-migrated) members.'),
                Forms\Components\Select::make('status')
                    ->options(MemberStatus::class)
                    ->required(),
            ])->columns(3),

            Forms\Components\Section::make('Opening Balances')
                ->description('Leave at 0 for new members. For migrated members, enter the balances at cutoff date.')
                ->schema([
                    Forms\Components\TextInput::make('opening_cash_balance')
                        ->numeric()->prefix('SAR')->default(0),
                    Forms\Components\TextInput::make('opening_fund_balance')
                        ->numeric()->prefix('SAR')->default(0),
                ])->columns(2),

            Forms\Components\Section::make('Security')->schema([
                Forms\Components\TextInput::make('password')
                    ->password()->revealable()
                    ->required(fn ($operation) => $operation === 'create')
                    ->dehydrateStateUsing(fn ($state) => filled($state) ? bcrypt($state) : null)
                    ->dehydrated(fn ($state) => filled($state)),
            ])->visibleOn('create'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')->label('ID')->sortable(),
                Tables\Columns\TextColumn::make('name')->searchable()->sortable(),
                Tables\Columns\BadgeColumn::make('status')->sortable(),
                Tables\Columns\TextColumn::make('cash_balance')
                    ->money('SAR')->label('Cash balance')->sortable(),
                Tables\Columns\TextColumn::make('fund_balance')
                    ->money('SAR')->label('Fund balance')->sortable(),
                Tables\Columns\TextColumn::make('activeLoans')
                    ->label('Active loans')
                    ->counts('activeLoans'),
                Tables\Columns\TextColumn::make('join_date')->date()->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')->options(MemberStatus::class),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\Action::make('suspend')
                    ->label('Suspend')
                    ->color('danger')
                    ->icon('heroicon-o-x-circle')
                    ->requiresConfirmation()
                    ->action(fn (Member $record) => $record->update(['status' => MemberStatus::Suspended]))
                    ->visible(fn (Member $record) => $record->status === MemberStatus::Active),
                Tables\Actions\Action::make('reinstate')
                    ->label('Reinstate')
                    ->color('success')
                    ->icon('heroicon-o-check-circle')
                    ->requiresConfirmation()
                    ->action(fn (Member $record) => $record->update(['status' => MemberStatus::Active]))
                    ->visible(fn (Member $record) => $record->status === MemberStatus::Suspended),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            MemberResource\RelationManagers\LoansRelationManager::class,
            MemberResource\RelationManagers\ContributionCyclesRelationManager::class,
            MemberResource\RelationManagers\TransactionsRelationManager::class,
            MemberResource\RelationManagers\MigrationStubsRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListMembers::route('/'),
            'create' => Pages\CreateMember::route('/create'),
            'view'   => Pages\ViewMember::route('/{record}'),
            'edit'   => Pages\EditMember::route('/{record}/edit'),
        ];
    }
}
