<?php
namespace App\Filament\Admin\Resources;

use App\Enums\BankLineStatus;
use App\Filament\Admin\Resources\BankClearingResource\Pages;
use App\Models\BankLine;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class BankClearingResource extends Resource
{
    protected static ?string $model           = BankLine::class;
    protected static ?string $navigationIcon  = 'heroicon-o-building-library';
    protected static ?string $navigationGroup = 'Finance';
    protected static ?string $navigationLabel = 'Bank Clearing';
    protected static ?int    $navigationSort  = 7;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('bank_reference'),
            Forms\Components\DatePicker::make('import_date')->required(),
            Forms\Components\TextInput::make('amount')->numeric()->prefix('SAR')->required(),
            Forms\Components\Textarea::make('description'),
            Forms\Components\Select::make('status')->options(BankLineStatus::class)->required(),
            Forms\Components\Select::make('matched_member_id')
                ->label('Matched member')
                ->relationship('matchedMember', 'name')
                ->searchable()->preload(),
            Forms\Components\TextInput::make('adjustment_amount')->numeric()->prefix('SAR')->default(0),
            Forms\Components\Textarea::make('notes'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('import_date')->date()->sortable(),
                Tables\Columns\TextColumn::make('bank_reference')->searchable(),
                Tables\Columns\TextColumn::make('amount')->money('SAR')->sortable(),
                Tables\Columns\BadgeColumn::make('status'),
                Tables\Columns\TextColumn::make('matchedMember.name')
                    ->label('Matched to')->default('—'),
                Tables\Columns\TextColumn::make('matched_at')->dateTime()->label('Cleared at'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')->options(BankLineStatus::class),
            ])
            ->headerActions([
                Tables\Actions\Action::make('import_statement')
                    ->label('Import statement')
                    ->icon('heroicon-o-arrow-up-tray')
                    ->form([
                        Forms\Components\FileUpload::make('statement_file')
                            ->label('Bank statement (CSV)')
                            ->acceptedFileTypes(['text/csv','application/csv'])
                            ->required(),
                    ])
                    ->action(fn () => \App\Services\BankClearingService::import()),
            ])
            ->actions([
                Tables\Actions\Action::make('match_manually')
                    ->label('Match manually')
                    ->icon('heroicon-o-link')
                    ->form([
                        Forms\Components\Select::make('member_id')
                            ->label('Member')
                            ->relationship('matchedMember','name')
                            ->searchable()->preload()->required(),
                        Forms\Components\Textarea::make('notes'),
                    ])
                    ->action(function (BankLine $record, array $data) {
                        $record->update([
                            'status'            => BankLineStatus::Cleared,
                            'matched_member_id' => $data['member_id'],
                            'matched_at'        => now(),
                            'notes'             => $data['notes'] ?? null,
                        ]);
                    })
                    ->visible(fn (BankLine $r) =>
                        in_array($r->status->value, ['unmatched','ambiguous','amount_mismatch'])),
                Tables\Actions\EditAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListBankLines::route('/'),
            'create' => Pages\CreateBankLine::route('/create'),
            'edit'   => Pages\EditBankLine::route('/{record}/edit'),
        ];
    }
}
