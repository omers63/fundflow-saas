<?php
namespace App\Filament\Admin\Resources\ReconResource\Pages;
use App\Filament\Admin\Resources\ReconResource;
use Filament\Resources\Pages\ViewRecord;
class ViewReconException extends ViewRecord { protected static string $resource = ReconResource::class; }
