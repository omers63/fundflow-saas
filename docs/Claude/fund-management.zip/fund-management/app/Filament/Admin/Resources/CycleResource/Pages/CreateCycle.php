<?php
namespace App\Filament\Admin\Resources\CycleResource\Pages;
use App\Filament\Admin\Resources\CycleResource;
use Filament\Resources\Pages\CreateRecord;
class CreateCycle extends CreateRecord { protected static string $resource = CycleResource::class; }
