<?php
namespace App\Filament\Admin\Resources\BankClearingResource\Pages;
use App\Filament\Admin\Resources\BankClearingResource;
use Filament\Resources\Pages\EditRecord;
class EditBankLine extends EditRecord { protected static string $resource = BankClearingResource::class; }
