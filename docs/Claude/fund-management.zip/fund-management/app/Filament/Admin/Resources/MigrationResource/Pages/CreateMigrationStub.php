<?php
namespace App\Filament\Admin\Resources\MigrationResource\Pages;
use App\Filament\Admin\Resources\MigrationResource;
use Filament\Resources\Pages\CreateRecord;
class CreateMigrationStub extends CreateRecord { protected static string $resource = MigrationResource::class; }
