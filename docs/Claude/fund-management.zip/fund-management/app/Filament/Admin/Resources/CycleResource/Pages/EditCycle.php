<?php
namespace App\Filament\Admin\Resources\CycleResource\Pages;
use App\Filament\Admin\Resources\CycleResource;
use Filament\Resources\Pages\EditRecord;
class EditCycle extends EditRecord { protected static string $resource = CycleResource::class; }
