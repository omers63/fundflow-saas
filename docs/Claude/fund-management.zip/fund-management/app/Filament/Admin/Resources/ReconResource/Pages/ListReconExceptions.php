<?php
namespace App\Filament\Admin\Resources\ReconResource\Pages;
use App\Filament\Admin\Resources\ReconResource;
use Filament\Resources\Pages\ListRecords;
class ListReconExceptions extends ListRecords { protected static string $resource = ReconResource::class; }
