<?php
namespace App\Filament\Admin\Resources\DisbursementResource\Pages;
use App\Filament\Admin\Resources\DisbursementResource;
use Filament\Resources\Pages\ListRecords;
class ListDisbursements extends ListRecords { protected static string $resource = DisbursementResource::class; }
