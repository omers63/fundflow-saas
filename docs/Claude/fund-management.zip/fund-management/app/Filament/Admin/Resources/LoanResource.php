<?php
namespace App\Filament\Admin\Resources;

use App\Enums\LoanStatus;
use App\Enums\LoanType;
use App\Filament\Admin\Resources\LoanResource\Pages;
use App\Models\Loan;
use App\Models\Member;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class LoanResource extends Resource
{
    protected static ?string $model           = Loan::class;
    protected static ?string $navigationIcon  = 'heroicon-o-currency-dollar';
    protected static ?string $navigationGroup = 'Operations';
    protected static ?string $navigationLabel = 'Loan Queue';
    protected static ?int    $navigationSort  = 3;

    public static function getNavigationBadge(): ?string
    {
        return (string) Loan::where('status', LoanStatus::PendingAdmin)->count() ?: null;
    }

    public static function getNavigationBadgeColor(): string|array|null
    {
        return 'danger';
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Loan Request')->schema([
                Forms\Components\Select::make('member_id')
                    ->label('Member')
                    ->relationship('member', 'name')
                    ->searchable()->preload()->required(),
                Forms\Components\Select::make('guarantor_id')
                    ->label('Guarantor')
                    ->relationship('guarantor', 'name')
                    ->searchable()->preload()->required(),
                Forms\Components\Select::make('type')
                    ->options(LoanType::class)->required(),
                Forms\Components\TextInput::make('requested_amount')
                    ->numeric()->prefix('SAR')->required(),
                Forms\Components\Select::make('grace_cycles')
                    ->label('Grace period')
                    ->options([0 => '0 cycles', 1 => '1 cycle', 2 => '2 cycles'])
                    ->default(0)->required(),
                Forms\Components\Select::make('fund_tier')
                    ->options(['tier_a'=>'Tier A','tier_b'=>'Tier B','tier_c'=>'Tier C','tier_e'=>'Tier E (Emergency)'])
                    ->required(),
            ])->columns(2),

            Forms\Components\Section::make('Admin Decision')
                ->description('Complete after eligibility review.')
                ->schema([
                    Forms\Components\Select::make('status')
                        ->options(LoanStatus::class)->required(),
                    Forms\Components\TextInput::make('approved_amount')
                        ->numeric()->prefix('SAR'),
                    Forms\Components\TextInput::make('emi_amount')
                        ->numeric()->prefix('SAR')->label('EMI amount'),
                    Forms\Components\TextInput::make('settlement_threshold')
                        ->numeric()->prefix('SAR'),
                    Forms\Components\Textarea::make('admin_notes')->columnSpanFull(),
                    Forms\Components\Textarea::make('rejection_reason')->columnSpanFull(),
                ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('queue_position')
            ->columns([
                Tables\Columns\TextColumn::make('queue_position')->label('#')->sortable(),
                Tables\Columns\TextColumn::make('member.name')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('requested_amount')->money('SAR')->sortable(),
                Tables\Columns\BadgeColumn::make('type'),
                Tables\Columns\BadgeColumn::make('status'),
                Tables\Columns\TextColumn::make('fund_tier')->label('Fund tier'),
                Tables\Columns\TextColumn::make('guarantor.name')->label('Guarantor'),
                Tables\Columns\TextColumn::make('created_at')->label('Submitted')->date()->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')->options(LoanStatus::class),
                Tables\Filters\SelectFilter::make('type')->options(LoanType::class),
            ])
            ->actions([
                Tables\Actions\Action::make('approve')
                    ->label('Approve')
                    ->color('success')
                    ->icon('heroicon-o-check-circle')
                    ->form([
                        Forms\Components\TextInput::make('approved_amount')
                            ->numeric()->prefix('SAR')->required(),
                        Forms\Components\Select::make('decision')
                            ->options(['full'=>'Full disbursement','partial'=>'Partial disbursement'])
                            ->required(),
                        Forms\Components\Textarea::make('admin_notes'),
                    ])
                    ->action(function (Loan $record, array $data) {
                        $record->update([
                            'status'          => LoanStatus::PartiallyDisbursed,
                            'approved_amount' => $data['approved_amount'],
                            'admin_notes'     => $data['admin_notes'],
                            'approved_at'     => now(),
                        ]);
                    })
                    ->visible(fn (Loan $r) => $r->status === LoanStatus::PendingAdmin),

                Tables\Actions\Action::make('reject')
                    ->label('Reject')
                    ->color('danger')
                    ->icon('heroicon-o-x-circle')
                    ->requiresConfirmation()
                    ->form([
                        Forms\Components\Textarea::make('rejection_reason')->required(),
                    ])
                    ->action(fn (Loan $r, array $d) => $r->update([
                        'status'           => LoanStatus::Rejected,
                        'rejection_reason' => $d['rejection_reason'],
                    ]))
                    ->visible(fn (Loan $r) => $r->status === LoanStatus::PendingAdmin),

                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            LoanResource\RelationManagers\DisbursementsRelationManager::class,
            LoanResource\RelationManagers\EmiCyclesRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListLoans::route('/'),
            'create' => Pages\CreateLoan::route('/create'),
            'view'   => Pages\ViewLoan::route('/{record}'),
            'edit'   => Pages\EditLoan::route('/{record}/edit'),
        ];
    }
}
