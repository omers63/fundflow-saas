<?php
namespace App\Filament\Admin\Resources\LoanResource\RelationManagers;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables\Table;
use Filament\Tables;
class EmiCyclesRelationManager extends RelationManager
{
    protected static string $relationship = 'emiCycles';
    public function form(Form $form): Form { return $form->schema([]); }
    public function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('id'),
            Tables\Columns\TextColumn::make('amount')->money('SAR'),
            Tables\Columns\TextColumn::make('status'),
        ]);
    }
}
