<?php
namespace App\Filament\Admin\Resources\CycleResource\Pages;
use App\Filament\Admin\Resources\CycleResource;
use Filament\Resources\Pages\ListRecords;
class ListCycles extends ListRecords { protected static string $resource = CycleResource::class; }
