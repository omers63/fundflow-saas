<?php
namespace App\Filament\Admin\Resources\MemberResource\RelationManagers;

use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables\Table;
use Filament\Tables;

class ContributionCyclesRelationManager extends RelationManager
{
    protected static string $relationship = 'contributionCycles';

    public function form(Form $form): Form
    {
        return $form->schema([]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id'),
            ]);
    }
}
