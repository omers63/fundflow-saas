<?php
namespace App\Filament\Admin\Resources;

use App\Filament\Admin\Resources\DisbursementResource\Pages;
use App\Models\Disbursement;
use App\Models\Loan;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Notifications\Notification;

class DisbursementResource extends Resource
{
    protected static ?string $model           = Disbursement::class;
    protected static ?string $navigationIcon  = 'heroicon-o-credit-card';
    protected static ?string $navigationGroup = 'Operations';
    protected static ?string $navigationLabel = 'Disbursements';
    protected static ?int    $navigationSort  = 5;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Select::make('loan_id')
                ->label('Loan')
                ->relationship('loan', 'loan_number')
                ->searchable()->preload()->required(),
            Forms\Components\TextInput::make('tranche_number')
                ->numeric()->default(1)->required(),
            Forms\Components\TextInput::make('amount')
                ->numeric()->prefix('SAR')->required(),
            Forms\Components\DateTimePicker::make('posted_at')->required(),
            Forms\Components\Textarea::make('notes'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('loan.member.name')
                    ->label('Member')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('loan.loan_number')
                    ->label('Loan #')->searchable(),
                Tables\Columns\TextColumn::make('loan.approved_amount')
                    ->money('SAR')->label('Approved'),
                Tables\Columns\TextColumn::make('loan.disbursed_amount')
                    ->money('SAR')->label('Disbursed to date'),
                Tables\Columns\TextColumn::make('amount')
                    ->money('SAR')->label('This tranche'),
                Tables\Columns\BadgeColumn::make('loan.status')
                    ->label('Loan status'),
                Tables\Columns\TextColumn::make('posted_at')->dateTime()->sortable(),
            ])
            ->actions([
                Tables\Actions\Action::make('post_tranche')
                    ->label('Post tranche')
                    ->icon('heroicon-o-arrow-up-tray')
                    ->color('primary')
                    ->form([
                        Forms\Components\TextInput::make('amount')
                            ->numeric()->prefix('SAR')->required()
                            ->helperText('Amount to disburse in this tranche.'),
                        Forms\Components\Textarea::make('notes'),
                    ])
                    ->action(function (Disbursement $record, array $data) {
                        $loan = $record->loan;
                        $newTotal = $loan->disbursed_amount + $data['amount'];
                        $loan->update(['disbursed_amount' => $newTotal]);
                        if ($newTotal >= $loan->approved_amount) {
                            $loan->update(['status' => 'active', 'fully_disbursed_at' => now()]);
                            Notification::make()->title('Loan activated')->success()->send();
                        }
                    }),
                Tables\Actions\ViewAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListDisbursements::route('/'),
            'create' => Pages\CreateDisbursement::route('/create'),
        ];
    }
}
