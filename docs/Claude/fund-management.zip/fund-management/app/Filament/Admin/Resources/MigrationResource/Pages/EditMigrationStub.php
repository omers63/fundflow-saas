<?php
namespace App\Filament\Admin\Resources\MigrationResource\Pages;
use App\Filament\Admin\Resources\MigrationResource;
use Filament\Resources\Pages\EditRecord;
class EditMigrationStub extends EditRecord { protected static string $resource = MigrationResource::class; }
