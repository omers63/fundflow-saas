<?php
namespace App\Filament\Admin\Resources;

use App\Enums\MigrationClassification;
use App\Filament\Admin\Resources\MigrationResource\Pages;
use App\Models\MigrationStub;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Notifications\Notification;

class MigrationResource extends Resource
{
    protected static ?string $model           = MigrationStub::class;
    protected static ?string $navigationIcon  = 'heroicon-o-circle-stack';
    protected static ?string $navigationGroup = 'System';
    protected static ?string $navigationLabel = 'Migration';
    protected static ?int    $navigationSort  = 9;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Select::make('member_id')
                ->relationship('member','name')->searchable()->preload()->required(),
            Forms\Components\DatePicker::make('cycle_date')->required(),
            Forms\Components\TextInput::make('amount_due')->numeric()->prefix('SAR'),
            Forms\Components\Select::make('classification')
                ->options(MigrationClassification::class)->required(),
            Forms\Components\Select::make('resolution_method')
                ->options([
                    'A' => 'Method A — Lump-sum',
                    'B' => 'Method B — Instalment plan',
                    'C' => 'Method C — Opening balance offset',
                ])
                ->visible(fn ($get) => $get('classification') === 'backdated_due'),
            Forms\Components\Textarea::make('notes'),
            Forms\Components\TextInput::make('evidence_ref')->label('Evidence reference'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('member.name')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('cycle_date')->date('M Y')->sortable(),
                Tables\Columns\TextColumn::make('amount_due')->money('SAR'),
                Tables\Columns\BadgeColumn::make('classification'),
                Tables\Columns\TextColumn::make('resolution_method')->label('Method'),
                Tables\Columns\TextColumn::make('status'),
                Tables\Columns\TextColumn::make('classified_at')->date()->label('Classified'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('classification')
                    ->options(MigrationClassification::class),
                Tables\Filters\SelectFilter::make('member_id')
                    ->relationship('member','name')
                    ->searchable()->preload()->label('Member'),
            ])
            ->headerActions([
                Tables\Actions\Action::make('batch_classify')
                    ->label('Batch classify')
                    ->icon('heroicon-o-squares-2x2')
                    ->form([
                        Forms\Components\Select::make('member_id')
                            ->label('Member')
                            ->relationship('member','name')
                            ->searchable()->preload()->required(),
                        Forms\Components\DatePicker::make('date_from')->required(),
                        Forms\Components\DatePicker::make('date_to')->required(),
                        Forms\Components\Select::make('classification')
                            ->options(MigrationClassification::class)->required(),
                        Forms\Components\Select::make('resolution_method')
                            ->options(['A'=>'Lump-sum','B'=>'Instalment','C'=>'OB Offset']),
                        Forms\Components\Textarea::make('notes'),
                    ])
                    ->action(function (array $data) {
                        MigrationStub::where('member_id', $data['member_id'])
                            ->where('status', 'open')
                            ->whereBetween('cycle_date', [$data['date_from'], $data['date_to']])
                            ->update([
                                'classification'   => $data['classification'],
                                'resolution_method'=> $data['resolution_method'] ?? null,
                                'classified_by'    => auth()->id(),
                                'classified_at'    => now(),
                                'status'           => $data['classification'] === 'backdated_due' ? 'pending_resolution' : 'closed',
                                'notes'            => $data['notes'] ?? null,
                            ]);
                        Notification::make()->title('Stubs classified')->success()->send();
                    }),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\Action::make('grant_clearance')
                    ->label('Grant clearance')
                    ->icon('heroicon-o-check-badge')
                    ->color('success')
                    ->requiresConfirmation()
                    ->action(function (MigrationStub $record) {
                        $member = $record->member;
                        $hasUnresolved = $member->migrationStubs()
                            ->where('status','open')->exists();
                        if ($hasUnresolved) {
                            Notification::make()->title('Unresolved stubs remain')->danger()->send();
                            return;
                        }
                        $member->update([
                            'status'               => 'active',
                            'migration_cleared_at' => now(),
                            'migration_cleared_by' => auth()->id(),
                        ]);
                        Notification::make()->title('Member cleared — status set to Active')->success()->send();
                    }),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListMigrationStubs::route('/'),
            'create' => Pages\CreateMigrationStub::route('/create'),
            'edit'   => Pages\EditMigrationStub::route('/{record}/edit'),
        ];
    }
}
