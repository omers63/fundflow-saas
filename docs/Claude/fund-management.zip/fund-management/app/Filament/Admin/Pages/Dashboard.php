<?php
namespace App\Filament\Admin\Pages;

use Filament\Pages\Dashboard as BaseDashboard;

class Dashboard extends BaseDashboard
{
    protected static ?string $navigationIcon  = 'heroicon-o-home';
    protected static ?string $navigationGroup = 'Operations';
    protected static ?int    $navigationSort  = 1;
    protected static ?string $title           = 'Dashboard';

    public function getColumns(): int | string | array
    {
        return 4;
    }

    public function getWidgets(): array
    {
        return [
            \App\Filament\Admin\Widgets\StatsOverviewWidget::class,
            \App\Filament\Admin\Widgets\LoanQueueWidget::class,
            \App\Filament\Admin\Widgets\ReconAlertsWidget::class,
            \App\Filament\Admin\Widgets\CycleProgressWidget::class,
            \App\Filament\Admin\Widgets\MemberActivityWidget::class,
            \App\Filament\Admin\Widgets\FundTierWidget::class,
        ];
    }
}
