<?php
namespace App\Filament\Admin\Pages;

use App\Models\AuditLog as AuditLogModel;
use Filament\Pages\Page;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Filament\Tables;

class AuditLog extends Page implements HasTable
{
    use InteractsWithTable;

    protected static ?string $navigationIcon  = 'heroicon-o-clock';
    protected static ?string $navigationGroup = 'System';
    protected static ?string $navigationLabel = 'Audit Log';
    protected static ?int    $navigationSort  = 11;
    protected static string  $view            = 'filament.admin.pages.audit-log';

    public function table(Table $table): Table
    {
        return $table
            ->query(AuditLogModel::query()->latest('created_at'))
            ->columns([
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Timestamp')->dateTime()->sortable(),
                Tables\Columns\TextColumn::make('description')
                    ->limit(60)->searchable(),
                Tables\Columns\TextColumn::make('actor_id')->label('Actor'),
                Tables\Columns\TextColumn::make('entity_id')->label('Entity'),
                Tables\Columns\BadgeColumn::make('tag')
                    ->color(fn ($state) => match($state) {
                        'RECON'     => 'info',
                        'Auto'      => 'success',
                        'Loan'      => 'primary',
                        'Migration' => 'primary',
                        'Override'  => 'warning',
                        default     => 'gray',
                    }),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('tag')
                    ->options([
                        'RECON'     => 'Reconciliation',
                        'Auto'      => 'Auto-resolved',
                        'Loan'      => 'Loan events',
                        'Migration' => 'Migration',
                        'Override'  => 'Admin overrides',
                    ]),
            ])
            ->actions([
                Tables\Actions\Action::make('view_meta')
                    ->label('Details')
                    ->icon('heroicon-o-eye')
                    ->modalContent(fn (AuditLogModel $r) => view(
                        'filament.admin.pages.audit-meta',
                        ['record' => $r]
                    )),
            ]);
    }
}
