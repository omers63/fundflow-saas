<?php
namespace App\Filament\Admin\Pages;

use Filament\Pages\Page;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Forms;
use Filament\Notifications\Notification;

class Reports extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon  = 'heroicon-o-chart-bar';
    protected static ?string $navigationGroup = 'Finance';
    protected static ?string $navigationLabel = 'Reports';
    protected static ?int    $navigationSort  = 8;
    protected static string  $view            = 'filament.admin.pages.reports';

    public ?array $data = [];

    public function mount(): void
    {
        $this->form->fill();
    }

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Custom Report Builder')->schema([
                    Forms\Components\Select::make('report_type')
                        ->options([
                            'collection'   => 'Monthly collection report',
                            'loans'        => 'Loan portfolio report',
                            'recon'        => 'Reconciliation summary',
                            'fund_tiers'   => 'Fund tier utilisation',
                            'member_stmt'  => 'Member statement',
                            'audit'        => 'Audit trail export',
                        ])->required(),
                    Forms\Components\DatePicker::make('date_from')->label('From')->required(),
                    Forms\Components\DatePicker::make('date_to')->label('To')->required(),
                    Forms\Components\Select::make('member_id')
                        ->label('Member (optional)')
                        ->relationship('member','name')
                        ->getRelationshipUsing(fn () => null)
                        ->searchable(),
                    Forms\Components\Select::make('format')
                        ->options(['pdf'=>'PDF','xlsx'=>'Excel (.xlsx)','csv'=>'CSV'])
                        ->default('pdf'),
                ])->columns(2),
            ])
            ->statePath('data');
    }

    public function generate(): void
    {
        $this->form->validate();
        Notification::make()
            ->title('Report generation queued')
            ->body('Your report will be ready for download shortly.')
            ->success()
            ->send();
    }
}
