<?php
namespace App\Filament\Admin\Pages;

use App\Models\SystemConfig;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Forms;
use Filament\Pages\Page;
use Filament\Notifications\Notification;

class Configuration extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon  = 'heroicon-o-adjustments-horizontal';
    protected static ?string $navigationGroup = 'System';
    protected static ?string $navigationLabel = 'Configuration';
    protected static ?int    $navigationSort  = 10;
    protected static string  $view            = 'filament.admin.pages.configuration';

    public ?array $data = [];

    public function mount(): void
    {
        $config = SystemConfig::current();
        $this->form->fill($config->toArray());
    }

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Tabs::make('Configuration')->tabs([

                Forms\Components\Tabs\Tab::make('Collection')->schema([
                    Forms\Components\TextInput::make('collection_window_days')
                        ->numeric()->label('Collection window (days)')->required(),
                    Forms\Components\Select::make('late_fee_model')
                        ->options(['replacement'=>'Replacement','cumulative'=>'Cumulative'])->required(),
                    Forms\Components\TextInput::make('late_fee_tier1_day')
                        ->numeric()->label('Tier 1 threshold (days overdue)'),
                    Forms\Components\TextInput::make('late_fee_tier1_amount')
                        ->numeric()->prefix('SAR')->label('Tier 1 fee amount'),
                    Forms\Components\TextInput::make('late_fee_tier2_day')
                        ->numeric()->label('Tier 2 threshold (days)'),
                    Forms\Components\TextInput::make('late_fee_tier2_amount')
                        ->numeric()->prefix('SAR')->label('Tier 2 fee amount'),
                    Forms\Components\TextInput::make('late_fee_tier3_day')
                        ->numeric()->label('Tier 3 threshold (days)'),
                    Forms\Components\TextInput::make('late_fee_tier3_amount')
                        ->numeric()->prefix('SAR')->label('Tier 3 fee amount'),
                ])->columns(2),

                Forms\Components\Tabs\Tab::make('Loans')->schema([
                    Forms\Components\TextInput::make('min_membership_years')
                        ->numeric()->label('Min. membership years'),
                    Forms\Components\TextInput::make('min_fund_balance')
                        ->numeric()->prefix('SAR')->label('Min. fund balance'),
                    Forms\Components\TextInput::make('borrow_multiplier')
                        ->numeric()->label('Borrow multiplier (×)'),
                    Forms\Components\TextInput::make('max_active_loans')
                        ->numeric()->label('Max active loans per member'),
                    Forms\Components\TextInput::make('settlement_threshold_pct')
                        ->numeric()->suffix('%')->label('Settlement threshold'),
                ])->columns(2),

                Forms\Components\Tabs\Tab::make('Fund Tiers')->schema([
                    Forms\Components\TextInput::make('fund_tier_a_pct')
                        ->numeric()->suffix('%')->label('Tier A allocation (1K–10K)'),
                    Forms\Components\TextInput::make('fund_tier_b_pct')
                        ->numeric()->suffix('%')->label('Tier B allocation (11K–30K)'),
                    Forms\Components\TextInput::make('fund_tier_c_pct')
                        ->numeric()->suffix('%')->label('Tier C allocation (31K–60K)'),
                    Forms\Components\TextInput::make('fund_tier_e_pct')
                        ->numeric()->suffix('%')->label('Tier E (Emergency)'),
                ])->columns(2),

                Forms\Components\Tabs\Tab::make('Reconciliation')->schema([
                    Forms\Components\TextInput::make('recon_tolerance')
                        ->numeric()->prefix('SAR')->label('Auto-resolve tolerance'),
                    Forms\Components\TextInput::make('timing_diff_defer_hours')
                        ->numeric()->label('Timing diff. defer (hours)'),
                    Forms\Components\TextInput::make('bank_match_date_range_days')
                        ->numeric()->label('Bank match date range (± days)'),
                    Forms\Components\TextInput::make('stale_pending_days')
                        ->numeric()->label('Stale pending threshold (days)'),
                    Forms\Components\TextInput::make('cash_deposit_unbanked_days')
                        ->numeric()->label('Unbanked cash alert (days)'),
                ])->columns(2),

                Forms\Components\Tabs\Tab::make('Guarantor Rules')->schema([
                    Forms\Components\TextInput::make('guarantor_warning_threshold')
                        ->numeric()->label('Missed EMIs before warning (X)'),
                    Forms\Components\TextInput::make('guarantor_liability_threshold')
                        ->numeric()->label('Missed EMIs before transfer (Y)'),
                ])->columns(2),

            ])->columnSpanFull(),
        ])->statePath('data');
    }

    public function save(): void
    {
        $config = SystemConfig::current();
        $config->update($this->form->getState());
        Notification::make()->title('Configuration saved')->success()->send();
    }
}
