<?php
namespace App\Filament\Admin\Widgets;

use App\Models\Transaction;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class MemberActivityWidget extends BaseWidget
{
    protected static ?int    $sort    = 5;
    protected int | string | array $columnSpan = 2;
    protected static ?string $heading = 'Recent member activity';

    public function table(Table $table): Table
    {
        return $table
            ->query(Transaction::query()->latest()->limit(8))
            ->columns([
                Tables\Columns\TextColumn::make('member.name')->label('Member'),
                Tables\Columns\TextColumn::make('description')->limit(40),
                Tables\Columns\TextColumn::make('tag')
                    ->badge()
                    ->color(fn ($state) => match($state) {
                        'CONTRIBUTION' => 'success',
                        'EMI'          => 'primary',
                        'DEPOSIT'      => 'info',
                        'LATE_FEE'     => 'warning',
                        'LOAN'         => 'primary',
                        default        => 'gray',
                    }),
                Tables\Columns\TextColumn::make('effective_date')->date()->label('Date'),
            ]);
    }
}
