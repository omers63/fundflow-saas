<?php
namespace App\Filament\Admin\Widgets;

use App\Models\Loan;
use App\Models\Member;
use App\Models\ReconException;
use App\Models\ContributionCycle;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class StatsOverviewWidget extends BaseWidget
{
    protected static ?int $sort = 1;

    protected function getStats(): array
    {
        $activeCycle = now()->format('Y-m-01');

        $totalMembers   = Member::count();
        $cycleCollected = ContributionCycle::where('cycle_month', $activeCycle)
            ->where('status', 'collected')->count();
        $cycleTotal     = ContributionCycle::where('cycle_month', $activeCycle)
            ->whereNotIn('status', ['exempt'])->count();
        $pct            = $cycleTotal > 0 ? round(($cycleCollected / $cycleTotal) * 100) : 0;
        $activeLoans    = Loan::whereIn('status', ['active','partially_disbursed'])->count();
        $queueCount     = Loan::where('status', 'pending_admin')->count();
        $openExceptions = ReconException::where('is_open', true)->count();
        $criticals      = ReconException::where('is_open', true)->where('severity', 'critical')->count();

        return [
            Stat::make('Total members', $totalMembers)
                ->icon('heroicon-o-users')
                ->color('primary'),

            Stat::make('Collected this cycle', "{$pct}%")
                ->description("{$cycleCollected} of {$cycleTotal} members")
                ->icon('heroicon-o-check-circle')
                ->color('success'),

            Stat::make('Active loans', $activeLoans)
                ->description("{$queueCount} in queue")
                ->icon('heroicon-o-currency-dollar')
                ->color($queueCount > 0 ? 'warning' : 'primary'),

            Stat::make('Recon exceptions', $openExceptions)
                ->description($criticals > 0 ? "{$criticals} critical" : 'All clear')
                ->icon('heroicon-o-exclamation-triangle')
                ->color($criticals > 0 ? 'danger' : ($openExceptions > 0 ? 'warning' : 'success')),
        ];
    }
}
