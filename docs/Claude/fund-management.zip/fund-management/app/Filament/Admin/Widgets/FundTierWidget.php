<?php
namespace App\Filament\Admin\Widgets;

use App\Models\Loan;
use App\Models\Member;
use App\Models\SystemConfig;
use Filament\Widgets\Widget;

class FundTierWidget extends Widget
{
    protected static ?int    $sort             = 6;
    protected int | string | array $columnSpan = 2;
    protected static string  $view             = 'filament.admin.widgets.fund-tier';

    public function getTierData(): array
    {
        $config      = SystemConfig::current();
        $masterFund  = Member::sum('fund_balance');

        $tiers = [
            'A' => ['label' => 'Tier A (1K–10K)', 'pct' => $config->fund_tier_a_pct, 'tier' => 'tier_a'],
            'B' => ['label' => 'Tier B (11K–30K)', 'pct' => $config->fund_tier_b_pct, 'tier' => 'tier_b'],
            'C' => ['label' => 'Tier C (31K–60K)', 'pct' => $config->fund_tier_c_pct, 'tier' => 'tier_c'],
            'E' => ['label' => 'Tier E (Emergency)', 'pct' => $config->fund_tier_e_pct, 'tier' => 'tier_e'],
        ];

        foreach ($tiers as $key => $tier) {
            $pool      = $masterFund * ($tier['pct'] / 100);
            $committed = Loan::where('fund_tier', $tier['tier'])
                ->whereIn('status', ['active', 'partially_disbursed'])
                ->sum('disbursed_amount');
            $usedPct   = $pool > 0 ? round(($committed / $pool) * 100) : 0;
            $tiers[$key]['used_pct']   = min(100, $usedPct);
            $tiers[$key]['available']  = max(0, $pool - $committed);
            $tiers[$key]['committed']  = $committed;
        }

        return $tiers;
    }
}
