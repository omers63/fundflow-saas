<?php
namespace App\Filament\Admin\Widgets;

use App\Models\Loan;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class LoanQueueWidget extends BaseWidget
{
    protected static ?int    $sort    = 2;
    protected int | string | array $columnSpan = 2;
    protected static ?string $heading = 'Loan queue — top requests';

    public function table(Table $table): Table
    {
        return $table
            ->query(
                Loan::query()
                    ->where('status', 'pending_admin')
                    ->orderByRaw("CASE WHEN type = 'emergency' THEN 0 ELSE 1 END")
                    ->orderBy('created_at')
                    ->limit(5)
            )
            ->columns([
                Tables\Columns\TextColumn::make('queue_position')->label('#'),
                Tables\Columns\TextColumn::make('member.name')->label('Member'),
                Tables\Columns\TextColumn::make('requested_amount')->money('SAR'),
                Tables\Columns\BadgeColumn::make('type'),
                Tables\Columns\TextColumn::make('guarantor.name')->label('Guarantor'),
            ])
            ->actions([
                Tables\Actions\Action::make('review')
                    ->url(fn (Loan $r) => route('filament.admin.resources.loans.edit', $r))
                    ->label('Review'),
            ]);
    }
}
