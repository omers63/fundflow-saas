<?php
namespace App\Filament\Admin\Widgets;

use App\Models\ContributionCycle;
use Filament\Widgets\Widget;

class CycleProgressWidget extends Widget
{
    protected static ?int    $sort              = 4;
    protected int | string | array $columnSpan  = 'full';
    protected static string  $view              = 'filament.admin.widgets.cycle-progress';

    public function getCycleStats(): array
    {
        $month = now()->format('Y-m-01');
        $base  = ContributionCycle::where('cycle_month', $month);
        $total = max(1, $base->count());

        return [
            'collected' => round($base->clone()->where('status', 'collected')->count() / $total * 100),
            'partial'   => round($base->clone()->where('status', 'partial')->count() / $total * 100),
            'overdue'   => round($base->clone()->whereIn('status', ['overdue','late_t1','late_t2','late_t3'])->count() / $total * 100),
            'exempt'    => round($base->clone()->where('status', 'exempt')->count() / $total * 100),
            'tier1'     => $base->clone()->where('status', 'late_t1')->count(),
            'tier2'     => $base->clone()->where('status', 'late_t2')->count(),
            'tier3'     => $base->clone()->where('status', 'late_t3')->count(),
        ];
    }
}
