<?php
namespace App\Filament\Admin\Widgets;

use App\Models\ReconException;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class ReconAlertsWidget extends BaseWidget
{
    protected static ?int    $sort    = 3;
    protected int | string | array $columnSpan = 2;
    protected static ?string $heading = 'Reconciliation alerts';

    public function table(Table $table): Table
    {
        return $table
            ->query(
                ReconException::query()
                    ->where('is_open', true)
                    ->orderByRaw("CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END")
                    ->limit(5)
            )
            ->columns([
                Tables\Columns\TextColumn::make('exception_type')->limit(35),
                Tables\Columns\BadgeColumn::make('severity'),
                Tables\Columns\TextColumn::make('amount_delta')->money('SAR')->label('Delta'),
                Tables\Columns\TextColumn::make('raised_at')->since()->label('Raised'),
            ])
            ->actions([
                Tables\Actions\Action::make('resolve')
                    ->url(fn (ReconException $r) =>
                        route('filament.admin.resources.recon-exceptions.index'))
                    ->label('Resolve'),
            ]);
    }
}
