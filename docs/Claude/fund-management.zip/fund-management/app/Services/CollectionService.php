<?php
namespace App\Services;

use App\Enums\CycleStatus;
use App\Models\AuditLog;
use App\Models\ContributionCycle;
use App\Models\Member;
use App\Models\SystemConfig;
use App\Models\Transaction;
use Filament\Notifications\Notification;

class CollectionService
{
    public static function runDebitBatch(): void
    {
        $config = SystemConfig::current();
        $month  = now()->format('Y-m-01');

        Member::where('status', 'active')->each(function (Member $member) use ($month, $config) {
            // Skip members with active loans (exempt)
            if ($member->hasActiveLoan()) {
                ContributionCycle::updateOrCreate(
                    ['member_id' => $member->id, 'cycle_month' => $month],
                    ['status' => CycleStatus::Exempt->value, 'due_amount' => 0]
                );
                return;
            }

            $due  = 500; // Configurable per member or global
            $cycle = ContributionCycle::firstOrCreate(
                ['member_id' => $member->id, 'cycle_month' => $month],
                ['due_amount' => $due, 'status' => CycleStatus::Pending->value]
            );

            if ($cycle->status === CycleStatus::Collected) return;

            $balance   = $member->cash_balance;
            $collected = min($balance, $due - $cycle->collected_amount);

            if ($collected > 0) {
                $member->decrement('cash_balance', $collected);
                $member->increment('fund_balance', $collected);
                $cycle->increment('collected_amount', $collected);
                Transaction::create([
                    'member_id'      => $member->id,
                    'type'           => 'contribution',
                    'description'    => 'Contribution — ' . now()->format('M Y'),
                    'dr_amount'      => $collected,
                    'cr_amount'      => 0,
                    'account'        => 'cash',
                    'tag'            => 'CONTRIBUTION',
                    'effective_date' => now()->toDateString(),
                ]);
            }

            $totalCollected = $cycle->collected_amount;
            $cycle->update([
                'status' => $totalCollected >= $due
                    ? CycleStatus::Collected->value
                    : ($totalCollected > 0 ? CycleStatus::Partial->value : CycleStatus::Pending->value),
            ]);
        });

        AuditLog::record('COLLECTION_BATCH_RUN', 'contribution',
            'Monthly debit batch executed for ' . now()->format('M Y'), 'COLLECTION');

        Notification::make()->title('Debit batch complete')->success()->send();
    }

    public static function postManual(ContributionCycle $cycle, float $amount, string $notes): void
    {
        $member = $cycle->member;
        $member->decrement('cash_balance', $amount);
        $member->increment('fund_balance', $amount);
        $cycle->increment('collected_amount', $amount);

        if ($cycle->collected_amount >= $cycle->due_amount) {
            $cycle->update(['status' => CycleStatus::Collected->value, 'collected_at' => now()]);
        }

        Transaction::create([
            'member_id'      => $member->id,
            'type'           => 'contribution_manual',
            'description'    => 'Manual contribution post — ' . $notes,
            'dr_amount'      => $amount,
            'cr_amount'      => 0,
            'account'        => 'cash',
            'tag'            => 'CONTRIBUTION',
            'effective_date' => now()->toDateString(),
        ]);

        AuditLog::record('MANUAL_CONTRIBUTION_POST', 'contribution',
            "Manual contribution SAR {$amount} posted for member #{$member->id}", 'CONTRIBUTION',
            ['amount' => $amount, 'notes' => $notes], auth()->id(), $cycle->id);
    }

    public static function applyLateFees(): void
    {
        $config = SystemConfig::current();
        $tiers  = [
            $config->late_fee_tier1_day => [$config->late_fee_tier1_amount, 'late_t1'],
            $config->late_fee_tier2_day => [$config->late_fee_tier2_amount, 'late_t2'],
            $config->late_fee_tier3_day => [$config->late_fee_tier3_amount, 'late_t3'],
        ];

        ContributionCycle::whereNotIn('status', ['collected','exempt'])
            ->whereNotNull('overdue_since')
            ->each(function (ContributionCycle $cycle) use ($tiers, $config) {
                $days    = $cycle->overdue_since->diffInDays(now());
                $newTier = null;
                $feeAmt  = 0;

                foreach (array_reverse(array_keys((array)$tiers), true) as $threshold) {
                    if ($days >= $threshold) {
                        [$feeAmt, $newTier] = $tiers[$threshold];
                        break;
                    }
                }

                if (!$newTier || $cycle->late_fee_tier === $newTier) return;

                // Replacement model: reverse prior fee if exists
                if ($config->late_fee_model === 'replacement' && $cycle->late_fee_amount > 0) {
                    $cycle->member->increment('cash_balance', $cycle->late_fee_amount);
                }

                $cycle->member->decrement('cash_balance', $feeAmt);
                $cycle->update([
                    'late_fee_amount' => $feeAmt,
                    'late_fee_tier'   => $newTier,
                    'status'          => $newTier,
                ]);
            });
    }
}
