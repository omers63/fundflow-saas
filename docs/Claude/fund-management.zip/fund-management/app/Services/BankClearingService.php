<?php
namespace App\Services;

use App\Enums\BankLineStatus;
use App\Models\AuditLog;
use App\Models\BankLine;
use App\Models\Member;
use App\Models\SystemConfig;
use App\Models\Transaction;

class BankClearingService
{
    public static function import(): void
    {
        // Stub — in production, parse uploaded CSV and create BankLine records
        AuditLog::record('BANK_STATEMENT_IMPORT','bank_clearing',
            'Bank statement import triggered','BANK');
    }

    public static function runAutoMatch(): void
    {
        $config = SystemConfig::current();
        $days   = $config->bank_match_date_range_days;

        BankLine::where('status', BankLineStatus::PendingClearance)->each(function (BankLine $line) use ($days) {
            $candidates = Transaction::whereNull('member_id')
                ->whereBetween('effective_date', [
                    $line->import_date->subDays($days)->toDateString(),
                    $line->import_date->addDays($days)->toDateString(),
                ])
                ->whereBetween('cr_amount', [$line->amount * 0.99, $line->amount * 1.01])
                ->get();

            if ($candidates->count() === 1) {
                $line->update([
                    'status'                 => BankLineStatus::Cleared,
                    'matched_transaction_id' => $candidates->first()->id,
                    'matched_at'             => now(),
                ]);
                AuditLog::record('BANK_AUTO_MATCH','bank_clearing',
                    "Bank line {$line->bank_reference} auto-matched",'Auto');
            } elseif ($candidates->count() > 1) {
                $line->update(['status' => BankLineStatus::Ambiguous]);
                ReconciliationService::raiseException(
                    'RECON_AMBIGUOUS_MATCH','bank_clearing',
                    \App\Enums\ReconSeverity::Medium,
                    $line->amount,
                    "Ambiguous match for bank line {$line->bank_reference}"
                );
            } else {
                $line->update(['status' => BankLineStatus::Unmatched]);
                ReconciliationService::raiseException(
                    'RECON_UNMATCHED_BANK_LINE','bank_clearing',
                    \App\Enums\ReconSeverity::High,
                    $line->amount,
                    "No match found for bank line {$line->bank_reference}"
                );
            }
        });
    }
}
