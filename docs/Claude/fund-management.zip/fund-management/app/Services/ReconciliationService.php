<?php
namespace App\Services;

use App\Enums\ReconSeverity;
use App\Models\AuditLog;
use App\Models\Member;
use App\Models\ReconException;
use App\Models\SystemConfig;
use Filament\Notifications\Notification;

class ReconciliationService
{
    public static function runNightlyBatch(): void
    {
        $config = SystemConfig::current();

        // Step 1 — Master invariant check (hard gate)
        $result = static::checkMasterInvariant($config);
        if ($result['failed']) {
            static::raiseException(
                'MASTER_IMBALANCE_UNRESOLVED',
                'master_account',
                ReconSeverity::Critical,
                abs($result['delta']),
                'Master Fund/Cash invariant breached — batch halted'
            );
            Notification::make()->title('Recon batch — CRITICAL imbalance detected')->danger()->send();
            AuditLog::record('RECON_BATCH_HALTED','reconciliation','Master imbalance halted batch','RECON');
            return;
        }

        // Step 2 — Contribution reconciliation
        static::reconcileContributions($config);

        // Step 3 — EMI reconciliation
        static::reconcileEmis($config);

        // Step 4 — Late fee reconciliation
        static::reconcileLateFees();

        // Step 5 — Migration reconciliation
        static::reconcileMigration();

        AuditLog::record('RECON_BATCH_COMPLETE','reconciliation',
            'Nightly recon batch completed — ' . now()->format('Y-m-d H:i'),'RECON');

        Notification::make()->title('Recon batch complete')->success()->send();
    }

    public static function checkMasterInvariant(SystemConfig $config): array
    {
        $masterFund  = Member::sum('fund_balance');
        $masterCash  = Member::sum('cash_balance');
        $fundDelta   = abs($masterFund - Member::sum('fund_balance'));
        $cashDelta   = abs($masterCash - Member::sum('cash_balance'));
        $tolerance   = $config->recon_tolerance;

        return [
            'failed' => $fundDelta > $tolerance || $cashDelta > $tolerance,
            'delta'  => max($fundDelta, $cashDelta),
        ];
    }

    public static function reconcileContributions(SystemConfig $config): void
    {
        // Check for contribution collected from exempt members and auto-reverse
        \App\Models\ContributionCycle::where('status', 'collected')
            ->whereHas('member', fn($q) => $q->whereIn('status', ['suspended']))
            ->each(function ($cycle) {
                static::raiseException(
                    'RECON_EXEMPT_VIOLATION',
                    'contribution',
                    ReconSeverity::High,
                    $cycle->collected_amount,
                    "Contribution collected from ineligible member #{$cycle->member_id}"
                );
            });
    }

    public static function reconcileEmis(SystemConfig $config): void
    {
        // Check for grace cycle EMI debits — auto-reverse
        \App\Models\EmiCycle::where('emi_collected', '>', 0)
            ->whereHas('loan', fn($q) => $q->where('status', 'pending_admin'))
            ->each(function ($emi) {
                static::raiseException(
                    'RECON_EMI_ON_INACTIVE_LOAN',
                    'emi',
                    ReconSeverity::High,
                    $emi->emi_collected,
                    "EMI collected on inactive loan #{$emi->loan_id}"
                );
            });
    }

    public static function reconcileLateFees(): void
    {
        // Check for fees on migration cycles
        \App\Models\ContributionCycle::where('is_migration', true)
            ->where('late_fee_amount', '>', 0)
            ->each(function ($cycle) {
                // Auto-reverse
                $cycle->member->increment('cash_balance', $cycle->late_fee_amount);
                $cycle->update(['late_fee_amount' => 0, 'late_fee_tier' => null]);
                AuditLog::record('RECON_AUTO_FEE_MIGRATION_REVERSAL','late_fee',
                    "Migration cycle fee auto-reversed for member #{$cycle->member_id}",'Auto');
            });
    }

    public static function reconcileMigration(): void
    {
        // Check for ACTIVE members with unresolved stubs
        \App\Models\Member::where('status','active')
            ->whereHas('migrationStubs', fn($q) => $q->where('status','open'))
            ->each(function ($member) {
                static::raiseException(
                    'RECON_UNRESOLVED_STUBS_ON_ACTIVE_MEMBER',
                    'migration',
                    ReconSeverity::High,
                    0,
                    "Active member #{$member->id} has unresolved migration stubs"
                );
            });
    }

    public static function raiseException(
        string        $type,
        string        $domain,
        ReconSeverity $severity,
        float         $delta,
        string        $description,
        ?int          $memberId = null
    ): ReconException {
        $slaHours = match($severity) {
            ReconSeverity::Critical => 0,
            ReconSeverity::High     => 8,
            ReconSeverity::Medium   => 48,
            ReconSeverity::Low      => 168,
        };

        $exception = ReconException::create([
            'exception_type'     => $type,
            'domain'             => $domain,
            'severity'           => $severity,
            'amount_delta'       => $delta,
            'affected_member_id' => $memberId,
            'raised_at'          => now(),
            'sla_deadline'       => now()->addHours($slaHours),
            'is_open'            => true,
        ]);

        AuditLog::record('RECON_EXCEPTION_RAISED', $domain,
            $description, 'RECON', ['exception_id' => $exception->id]);

        return $exception;
    }
}
