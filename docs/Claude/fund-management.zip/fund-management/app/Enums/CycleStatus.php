<?php
namespace App\Enums;
use Filament\Support\Contracts\HasColor;
use Filament\Support\Contracts\HasLabel;

enum CycleStatus: string implements HasLabel, HasColor
{
    case Pending   = 'pending';
    case Partial   = 'partial';
    case Collected = 'collected';
    case Overdue   = 'overdue';
    case LateT1    = 'late_t1';
    case LateT2    = 'late_t2';
    case LateT3    = 'late_t3';
    case Exempt    = 'exempt';

    public function getLabel(): string
    {
        return match($this) {
            self::Pending   => 'Pending',
            self::Partial   => 'Partial',
            self::Collected => 'Collected',
            self::Overdue   => 'Overdue',
            self::LateT1    => 'Late — Tier 1',
            self::LateT2    => 'Late — Tier 2',
            self::LateT3    => 'Late — Tier 3',
            self::Exempt    => 'Exempt',
        };
    }

    public function getColor(): string|array|null
    {
        return match($this) {
            self::Pending   => 'info',
            self::Partial   => 'warning',
            self::Collected => 'success',
            self::Overdue   => 'warning',
            self::LateT1    => 'warning',
            self::LateT2    => 'danger',
            self::LateT3    => 'danger',
            self::Exempt    => 'gray',
        };
    }
}
