<?php
namespace App\Enums;
use Filament\Support\Contracts\HasColor;
use Filament\Support\Contracts\HasLabel;

enum LoanType: string implements HasLabel, HasColor
{
    case Standard  = 'standard';
    case Emergency = 'emergency';

    public function getLabel(): string
    {
        return match($this) {
            self::Standard  => 'Standard',
            self::Emergency => 'Emergency',
        };
    }

    public function getColor(): string|array|null
    {
        return match($this) {
            self::Standard  => 'info',
            self::Emergency => 'danger',
        };
    }
}
