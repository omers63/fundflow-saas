<?php
namespace App\Enums;
use Filament\Support\Contracts\HasColor;
use Filament\Support\Contracts\HasLabel;

enum MigrationClassification: string implements HasLabel, HasColor
{
    case Unresolved    = 'unresolved';
    case Waived        = 'waived';
    case BackdatedPaid = 'backdated_paid';
    case BackdatedDue  = 'backdated_due';
    case ObAbsorbed    = 'ob_absorbed';
    case Escalated     = 'escalated';

    public function getLabel(): string
    {
        return match($this) {
            self::Unresolved    => 'Unresolved',
            self::Waived        => 'Waived',
            self::BackdatedPaid => 'Backdated — Paid',
            self::BackdatedDue  => 'Backdated — Due',
            self::ObAbsorbed    => 'OB Absorbed',
            self::Escalated     => 'Escalated',
        };
    }

    public function getColor(): string|array|null
    {
        return match($this) {
            self::Unresolved    => 'warning',
            self::Waived        => 'success',
            self::BackdatedPaid => 'info',
            self::BackdatedDue  => 'warning',
            self::ObAbsorbed    => 'gray',
            self::Escalated     => 'danger',
        };
    }
}
