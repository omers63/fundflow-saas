<?php
namespace App\Enums;
use Filament\Support\Contracts\HasColor;
use Filament\Support\Contracts\HasLabel;

enum LoanStatus: string implements HasLabel, HasColor
{
    case PendingAdmin       = 'pending_admin';
    case PartiallyDisbursed = 'partially_disbursed';
    case Active             = 'active';
    case Delinquent         = 'delinquent';
    case Transferred        = 'transferred';
    case Repaid             = 'repaid';
    case Rejected           = 'rejected';

    public function getLabel(): string
    {
        return match($this) {
            self::PendingAdmin       => 'Pending Admin',
            self::PartiallyDisbursed => 'Partially Disbursed',
            self::Active             => 'Active',
            self::Delinquent         => 'Delinquent',
            self::Transferred        => 'Transferred',
            self::Repaid             => 'Repaid',
            self::Rejected           => 'Rejected',
        };
    }

    public function getColor(): string|array|null
    {
        return match($this) {
            self::PendingAdmin       => 'info',
            self::PartiallyDisbursed => 'warning',
            self::Active             => 'success',
            self::Delinquent         => 'danger',
            self::Transferred        => 'danger',
            self::Repaid             => 'gray',
            self::Rejected           => 'gray',
        };
    }
}
