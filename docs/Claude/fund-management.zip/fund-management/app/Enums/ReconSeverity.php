<?php
namespace App\Enums;
use Filament\Support\Contracts\HasColor;
use Filament\Support\Contracts\HasLabel;

enum ReconSeverity: string implements HasLabel, HasColor
{
    case Critical = 'critical';
    case High     = 'high';
    case Medium   = 'medium';
    case Low      = 'low';

    public function getLabel(): string
    {
        return match($this) {
            self::Critical => 'Critical',
            self::High     => 'High',
            self::Medium   => 'Medium',
            self::Low      => 'Low',
        };
    }

    public function getColor(): string|array|null
    {
        return match($this) {
            self::Critical => 'danger',
            self::High     => 'warning',
            self::Medium   => 'info',
            self::Low      => 'gray',
        };
    }

    public function getSla(): string
    {
        return match($this) {
            self::Critical => 'Immediate — batch halted',
            self::High     => 'Same business day',
            self::Medium   => '48 hours',
            self::Low      => 'Next cycle',
        };
    }
}
