<?php
namespace App\Enums;
use Filament\Support\Contracts\HasColor;
use Filament\Support\Contracts\HasLabel;

enum BankLineStatus: string implements HasLabel, HasColor
{
    case PendingClearance = 'pending_clearance';
    case Cleared          = 'cleared';
    case Unmatched        = 'unmatched';
    case Ambiguous        = 'ambiguous';
    case AmountMismatch   = 'amount_mismatch';
    case StalePending     = 'stale_pending';

    public function getLabel(): string
    {
        return match($this) {
            self::PendingClearance => 'Pending Clearance',
            self::Cleared          => 'Cleared',
            self::Unmatched        => 'Unmatched',
            self::Ambiguous        => 'Ambiguous Match',
            self::AmountMismatch   => 'Amount Mismatch',
            self::StalePending     => 'Stale Pending',
        };
    }

    public function getColor(): string|array|null
    {
        return match($this) {
            self::PendingClearance => 'info',
            self::Cleared          => 'success',
            self::Unmatched        => 'danger',
            self::Ambiguous        => 'warning',
            self::AmountMismatch   => 'warning',
            self::StalePending     => 'danger',
        };
    }
}
