<?php
namespace App\Enums;
use Filament\Support\Contracts\HasColor;
use Filament\Support\Contracts\HasLabel;

enum MemberStatus: string implements HasLabel, HasColor
{
    case Active           = 'active';
    case MigrationPending = 'migration_pending';
    case Delinquent       = 'delinquent';
    case Suspended        = 'suspended';

    public function getLabel(): string
    {
        return match($this) {
            self::Active           => 'Active',
            self::MigrationPending => 'Migration Pending',
            self::Delinquent       => 'Delinquent',
            self::Suspended        => 'Suspended',
        };
    }

    public function getColor(): string|array|null
    {
        return match($this) {
            self::Active           => 'success',
            self::MigrationPending => 'warning',
            self::Delinquent       => 'danger',
            self::Suspended        => 'gray',
        };
    }
}
