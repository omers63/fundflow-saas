<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            SystemConfigSeeder::class,
            AdminUserSeeder::class,
            MemberSeeder::class,
            LoanSeeder::class,
            CycleSeeder::class,
            BankLineSeeder::class,
            ReconExceptionSeeder::class,
        ]);
    }
}
