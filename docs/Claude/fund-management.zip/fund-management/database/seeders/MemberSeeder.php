<?php
namespace Database\Seeders;

use App\Enums\MemberStatus;
use App\Models\Member;
use App\Models\MigrationStub;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class MemberSeeder extends Seeder
{
    public function run(): void
    {
        $members = [
            ['name' => 'Youssef Al-Amin',    'email' => 'youssef@example.com',  'join_date' => '2018-03-14', 'cash_balance' => 3240,  'fund_balance' => 18500, 'status' => MemberStatus::Active],
            ['name' => 'Sara Rahman',          'email' => 'sara@example.com',     'join_date' => '2019-06-01', 'cash_balance' => 8100,  'fund_balance' => 24000, 'status' => MemberStatus::Active],
            ['name' => 'Hana Khalil',          'email' => 'hana@example.com',     'join_date' => '2020-01-15', 'cash_balance' => 200,   'fund_balance' => 11000, 'status' => MemberStatus::Active],
            ['name' => 'Omar Mansour',         'email' => 'omar@example.com',     'join_date' => '2015-01-01', 'cash_balance' => 0,     'fund_balance' => 6500,  'status' => MemberStatus::MigrationPending, 'migration_cutoff_date' => '2026-04-01'],
            ['name' => 'Khalid Al-Rashidi',   'email' => 'khalid@example.com',   'join_date' => '2017-09-01', 'cash_balance' => 500,   'fund_balance' => 9000,  'status' => MemberStatus::Delinquent],
            ['name' => 'Nadia Qasim',          'email' => 'nadia@example.com',    'join_date' => '2016-03-20', 'cash_balance' => 12000, 'fund_balance' => 22000, 'status' => MemberStatus::Active],
            ['name' => 'Faisal Nasser',        'email' => 'faisal@example.com',   'join_date' => '2021-07-10', 'cash_balance' => 4500,  'fund_balance' => 7500,  'status' => MemberStatus::Active],
            ['name' => 'Layla Mohammed',       'email' => 'layla@example.com',    'join_date' => '2018-11-05', 'cash_balance' => 6000,  'fund_balance' => 31000, 'status' => MemberStatus::Active],
            ['name' => 'Hassan Karim',         'email' => 'hassan@example.com',   'join_date' => '2012-03-01', 'cash_balance' => 1500,  'fund_balance' => 42000, 'status' => MemberStatus::MigrationPending, 'migration_cutoff_date' => '2026-04-01'],
            ['name' => 'Bilal Saeed',          'email' => 'bilal@example.com',    'join_date' => '2020-05-01', 'cash_balance' => 2800,  'fund_balance' => 9500,  'status' => MemberStatus::Active],
        ];

        foreach ($members as $data) {
            $member = Member::updateOrCreate(
                ['email' => $data['email']],
                array_merge($data, [
                    'password'             => Hash::make('password'),
                    'phone'                => '+966 5' . rand(0,9) . ' ' . rand(100,999) . ' ' . rand(1000,9999),
                    'opening_cash_balance' => $data['cash_balance'],
                    'opening_fund_balance' => $data['fund_balance'],
                ])
            );

            // Create migration stubs for migrated members
            if (isset($data['migration_cutoff_date'])) {
                $start  = Carbon::parse($data['join_date']);
                $cutoff = Carbon::parse($data['migration_cutoff_date']);
                $cursor = $start->copy()->startOfMonth();
                while ($cursor->lessThan($cutoff)) {
                    MigrationStub::firstOrCreate(
                        ['member_id' => $member->id, 'cycle_date' => $cursor->toDateString()],
                        ['amount_due' => 500, 'classification' => 'unresolved', 'status' => 'open']
                    );
                    $cursor->addMonth();
                }
            }
        }

        $this->command->info('Members seeded: ' . Member::count());
    }
}
