<?php
namespace Database\Seeders;

use App\Models\SystemConfig;
use Illuminate\Database\Seeder;

class SystemConfigSeeder extends Seeder
{
    public function run(): void
    {
        SystemConfig::current(); // Creates with defaults if not exists
    }
}
