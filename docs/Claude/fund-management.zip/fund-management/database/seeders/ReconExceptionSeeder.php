<?php
namespace Database\Seeders;

use App\Enums\ReconSeverity;
use App\Models\ReconException;
use Illuminate\Database\Seeder;

class ReconExceptionSeeder extends Seeder
{
    public function run(): void
    {
        ReconException::create([
            'exception_type'     => 'MASTER_IMBALANCE_UNRESOLVED',
            'domain'             => 'master_account',
            'severity'           => ReconSeverity::Critical,
            'amount_delta'       => 0.40,
            'raised_at'          => now()->subMinutes(2),
            'sla_deadline'       => now(),
            'is_open'            => true,
            'auto_resolve_attempted' => true,
            'auto_resolve_result'=> 'Failed — exceeds tolerance',
        ]);

        ReconException::create([
            'exception_type' => 'RECON_UNMATCHED_BANK_LINE',
            'domain'         => 'bank_clearing',
            'severity'       => ReconSeverity::High,
            'amount_delta'   => 1200,
            'raised_at'      => now()->subHours(1),
            'sla_deadline'   => now()->endOfDay(),
            'is_open'        => true,
        ]);

        ReconException::create([
            'exception_type' => 'RECON_AUTO_FEE_TIER_CORRECTION',
            'domain'         => 'late_fee',
            'severity'       => ReconSeverity::Medium,
            'amount_delta'   => 50,
            'raised_at'      => now()->subHours(3),
            'sla_deadline'   => now()->addHours(45),
            'is_open'        => false,
            'resolved_at'    => now()->subHour(),
            'resolution_action' => 'post_correction',
        ]);

        $this->command->info('Recon exceptions seeded: ' . ReconException::count());
    }
}
