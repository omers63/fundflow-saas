<?php
namespace Database\Seeders;

use App\Enums\BankLineStatus;
use App\Models\BankLine;
use App\Models\Member;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class BankLineSeeder extends Seeder
{
    public function run(): void
    {
        $members = Member::take(5)->get();

        // Auto-matched lines
        foreach ($members as $i => $member) {
            BankLine::create([
                'bank_reference'   => 'TRF-' . (7741 + $i) . '-KSA',
                'import_date'      => now()->subDays(rand(1,3))->toDateString(),
                'amount'           => rand(1, 5) * 500,
                'description'      => 'Transfer from ' . $member->name,
                'status'           => BankLineStatus::Cleared,
                'matched_member_id'=> $member->id,
                'matched_at'       => now()->subDay(),
            ]);
        }

        // Unmatched lines
        BankLine::create([
            'bank_reference' => 'TRF-8821-KSA',
            'import_date'    => now()->toDateString(),
            'amount'         => 1200,
            'description'    => 'Unknown depositor',
            'status'         => BankLineStatus::Unmatched,
        ]);

        BankLine::create([
            'bank_reference' => 'DEP-0091',
            'import_date'    => now()->subDay()->toDateString(),
            'amount'         => 450,
            'description'    => 'Amount mismatch — expected 500',
            'status'         => BankLineStatus::AmountMismatch,
        ]);

        // Stale pending
        BankLine::create([
            'bank_reference' => 'TRF-OLD-001',
            'import_date'    => now()->subDays(35)->toDateString(),
            'amount'         => 800,
            'description'    => 'Old pending — no match',
            'status'         => BankLineStatus::StalePending,
        ]);

        $this->command->info('Bank lines seeded: ' . BankLine::count());
    }
}
