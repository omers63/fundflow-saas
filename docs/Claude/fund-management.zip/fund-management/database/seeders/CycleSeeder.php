<?php
namespace Database\Seeders;

use App\Enums\CycleStatus;
use App\Models\ContributionCycle;
use App\Models\Member;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class CycleSeeder extends Seeder
{
    public function run(): void
    {
        $currentMonth = now()->startOfMonth();

        Member::all()->each(function (Member $member) use ($currentMonth) {
            // Generate last 6 months of cycles
            for ($i = 5; $i >= 0; $i--) {
                $month   = $currentMonth->copy()->subMonths($i);
                $hasLoan = $member->hasActiveLoan();

                if ($hasLoan) {
                    $status     = CycleStatus::Exempt;
                    $due        = 0;
                    $collected  = 0;
                } elseif ($i === 0) {
                    // Current month — vary status
                    $rand       = rand(1, 10);
                    $status     = $rand <= 7 ? CycleStatus::Collected
                                : ($rand <= 8 ? CycleStatus::Partial
                                : ($rand <= 9 ? CycleStatus::Overdue : CycleStatus::LateT1));
                    $due        = 500;
                    $collected  = $status === CycleStatus::Collected ? 500
                                : ($status === CycleStatus::Partial ? 200 : 0);
                } else {
                    $status    = CycleStatus::Collected;
                    $due       = 500;
                    $collected = 500;
                }

                ContributionCycle::updateOrCreate(
                    ['member_id' => $member->id, 'cycle_month' => $month->toDateString()],
                    [
                        'due_amount'       => $due,
                        'collected_amount' => $collected,
                        'status'           => $status,
                        'collected_at'     => $collected > 0 ? $month->copy()->addDays(1) : null,
                        'overdue_since'    => in_array($status->value, ['overdue','late_t1','late_t2','late_t3'])
                            ? $month->copy()->addDays(5) : null,
                        'late_fee_amount'  => $status === CycleStatus::LateT1 ? 50 : 0,
                        'late_fee_tier'    => $status === CycleStatus::LateT1 ? 'late_t1' : null,
                    ]
                );
            }
        });

        $this->command->info('Cycles seeded: ' . ContributionCycle::count());
    }
}
