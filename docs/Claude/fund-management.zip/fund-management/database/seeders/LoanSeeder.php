<?php
namespace Database\Seeders;

use App\Enums\LoanStatus;
use App\Enums\LoanType;
use App\Models\EmiCycle;
use App\Models\Loan;
use App\Models\Member;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class LoanSeeder extends Seeder
{
    public function run(): void
    {
        $youssef = Member::where('email', 'youssef@example.com')->first();
        $sara    = Member::where('email', 'sara@example.com')->first();
        $khalid  = Member::where('email', 'khalid@example.com')->first();
        $bilal   = Member::where('email', 'bilal@example.com')->first();
        $nadia   = Member::where('email', 'nadia@example.com')->first();
        $faisal  = Member::where('email', 'faisal@example.com')->first();
        $layla   = Member::where('email', 'layla@example.com')->first();

        if (!$youssef || !$sara) return;

        // Active loan for Youssef — in repayment (5 of 18 EMIs done)
        $loan1 = Loan::updateOrCreate(['loan_number' => 'L-0034'], [
            'member_id'            => $youssef->id,
            'guarantor_id'         => $sara->id,
            'type'                 => LoanType::Standard,
            'status'               => LoanStatus::Active,
            'requested_amount'     => 22000,
            'approved_amount'      => 22000,
            'disbursed_amount'     => 22000,
            'member_portion'       => 18500,
            'master_portion'       => 3500,
            'settlement_threshold' => 12320,
            'total_repaid'         => 7260,
            'emi_amount'           => 1500,
            'fund_tier'            => 'tier_b',
            'loan_tier'            => 'tier_2',
            'grace_cycles'         => 0,
            'queue_position'       => 0,
            'approved_at'          => now()->subYear()->startOfMonth(),
            'fully_disbursed_at'   => now()->subYear()->startOfMonth(),
        ]);

        // Build EMI schedule for loan1
        $startCycle = Carbon::parse('2026-01-01');
        for ($i = 1; $i <= 18; $i++) {
            $cycleDate  = $startCycle->copy()->addMonths($i - 1);
            $isPast     = $cycleDate->lessThan(now()->startOfMonth());
            $isCurrent  = $cycleDate->equalTo(now()->startOfMonth());
            $collected  = ($isPast && $i <= 5) ? 1500 : 0;
            $status     = ($isPast && $i <= 5) ? 'collected' : ($isCurrent ? 'pending' : 'scheduled');

            EmiCycle::updateOrCreate(
                ['loan_id' => $loan1->id, 'cycle_number' => $i],
                [
                    'cycle_month'   => $cycleDate->toDateString(),
                    'emi_due'       => 1500,
                    'emi_collected' => $collected,
                    'status'        => $status,
                    'collected_at'  => $collected > 0 ? $cycleDate : null,
                ]
            );
        }

        // Pending loan request — emergency (Khalid)
        Loan::updateOrCreate(['loan_number' => 'L-0038'], [
            'member_id'        => $khalid->id,
            'guarantor_id'     => $youssef->id,
            'type'             => LoanType::Emergency,
            'status'           => LoanStatus::PendingAdmin,
            'requested_amount' => 8000,
            'fund_tier'        => 'tier_e',
            'loan_tier'        => 'tier_1',
            'grace_cycles'     => 1,
            'queue_position'   => 1,
        ]);

        // Pending loan — standard (Sara)
        Loan::updateOrCreate(['loan_number' => 'L-0039'], [
            'member_id'        => $sara->id,
            'guarantor_id'     => $nadia->id,
            'type'             => LoanType::Standard,
            'status'           => LoanStatus::PendingAdmin,
            'requested_amount' => 22000,
            'fund_tier'        => 'tier_b',
            'loan_tier'        => 'tier_2',
            'grace_cycles'     => 0,
            'queue_position'   => 2,
        ]);

        // Pending loan — standard (Faisal)
        Loan::updateOrCreate(['loan_number' => 'L-0040'], [
            'member_id'        => $faisal->id,
            'guarantor_id'     => $youssef->id,
            'type'             => LoanType::Standard,
            'status'           => LoanStatus::PendingAdmin,
            'requested_amount' => 7500,
            'fund_tier'        => 'tier_a',
            'loan_tier'        => 'tier_1',
            'grace_cycles'     => 0,
            'queue_position'   => 3,
        ]);

        // Partially disbursed loan (Bilal)
        Loan::updateOrCreate(['loan_number' => 'L-0036'], [
            'member_id'        => $bilal->id,
            'guarantor_id'     => $sara->id,
            'type'             => LoanType::Standard,
            'status'           => LoanStatus::PartiallyDisbursed,
            'requested_amount' => 15000,
            'approved_amount'  => 15000,
            'disbursed_amount' => 10000,
            'fund_tier'        => 'tier_b',
            'loan_tier'        => 'tier_2',
            'grace_cycles'     => 0,
            'queue_position'   => 0,
            'approved_at'      => now()->subWeek(),
        ]);

        // Active loan for Nadia — recently activated
        Loan::updateOrCreate(['loan_number' => 'L-0035'], [
            'member_id'            => $nadia->id,
            'guarantor_id'         => $layla->id,
            'type'                 => LoanType::Standard,
            'status'               => LoanStatus::Active,
            'requested_amount'     => 22000,
            'approved_amount'      => 22000,
            'disbursed_amount'     => 22000,
            'member_portion'       => 22000,
            'master_portion'       => 0,
            'settlement_threshold' => 23100,
            'total_repaid'         => 0,
            'emi_amount'           => 1500,
            'fund_tier'            => 'tier_b',
            'loan_tier'            => 'tier_2',
            'grace_cycles'         => 0,
            'queue_position'       => 0,
            'approved_at'          => now()->subMonth(),
            'fully_disbursed_at'   => now()->subMonth(),
        ]);

        $this->command->info('Loans seeded: ' . Loan::count());
    }
}
