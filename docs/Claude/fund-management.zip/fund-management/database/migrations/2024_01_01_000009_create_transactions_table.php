<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('member_id')->nullable();
            $table->string('type');
            $table->string('description');
            $table->decimal('dr_amount', 15, 2)->default(0);
            $table->decimal('cr_amount', 15, 2)->default(0);
            $table->string('account')->default('cash');
            $table->string('reference')->nullable();
            $table->string('tag')->nullable();
            $table->date('effective_date');
            $table->unsignedBigInteger('posted_by')->nullable();
            $table->unsignedBigInteger('loan_id')->nullable();
            $table->unsignedBigInteger('cycle_id')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('transactions'); }
};
