<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('disbursements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('loan_id')->constrained('loans')->cascadeOnDelete();
            $table->unsignedInteger('tranche_number')->default(1);
            $table->decimal('amount', 15, 2);
            $table->timestamp('posted_at');
            $table->unsignedBigInteger('posted_by')->nullable();
            $table->text('notes')->nullable();
            $table->string('journal_entry_ref')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('disbursements'); }
};
