<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('members', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password');
            $table->string('phone')->nullable();
            $table->string('national_id')->nullable();
            $table->date('join_date');
            $table->date('migration_cutoff_date')->nullable();
            $table->string('status')->default('active');
            $table->decimal('cash_balance', 15, 2)->default(0);
            $table->decimal('fund_balance', 15, 2)->default(0);
            $table->decimal('opening_cash_balance', 15, 2)->default(0);
            $table->decimal('opening_fund_balance', 15, 2)->default(0);
            $table->timestamp('migration_cleared_at')->nullable();
            $table->unsignedBigInteger('migration_cleared_by')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('members'); }
};
