<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('system_configs', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('collection_window_days')->default(5);
            $table->string('late_fee_model')->default('replacement');
            $table->unsignedInteger('late_fee_tier1_day')->default(3);
            $table->decimal('late_fee_tier1_amount', 10, 2)->default(50);
            $table->unsignedInteger('late_fee_tier2_day')->default(10);
            $table->decimal('late_fee_tier2_amount', 10, 2)->default(100);
            $table->unsignedInteger('late_fee_tier3_day')->default(20);
            $table->decimal('late_fee_tier3_amount', 10, 2)->default(200);
            $table->unsignedInteger('min_membership_years')->default(2);
            $table->decimal('min_fund_balance', 15, 2)->default(5000);
            $table->decimal('borrow_multiplier', 5, 2)->default(3);
            $table->unsignedInteger('max_active_loans')->default(2);
            $table->decimal('settlement_threshold_pct', 5, 2)->default(5);
            $table->json('grace_period_options')->nullable();
            $table->unsignedInteger('guarantor_warning_threshold')->default(3);
            $table->unsignedInteger('guarantor_liability_threshold')->default(6);
            $table->decimal('recon_tolerance', 10, 4)->default(0.01);
            $table->unsignedInteger('timing_diff_defer_hours')->default(48);
            $table->unsignedInteger('bank_match_date_range_days')->default(3);
            $table->unsignedInteger('stale_pending_days')->default(30);
            $table->unsignedInteger('cash_deposit_unbanked_days')->default(7);
            $table->unsignedInteger('migration_instalment_cycles')->default(12);
            $table->json('emi_tiers')->nullable();
            $table->decimal('fund_tier_a_pct', 5, 2)->default(30);
            $table->decimal('fund_tier_b_pct', 5, 2)->default(40);
            $table->decimal('fund_tier_c_pct', 5, 2)->default(50);
            $table->decimal('fund_tier_e_pct', 5, 2)->default(20);
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('system_configs'); }
};
