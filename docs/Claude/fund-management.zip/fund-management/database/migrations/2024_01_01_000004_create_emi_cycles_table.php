<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('emi_cycles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('loan_id')->constrained('loans')->cascadeOnDelete();
            $table->unsignedInteger('cycle_number');
            $table->date('cycle_month');
            $table->decimal('emi_due', 15, 2);
            $table->decimal('emi_collected', 15, 2)->default(0);
            $table->decimal('late_fee', 15, 2)->default(0);
            $table->string('status')->default('pending');
            $table->timestamp('overdue_since')->nullable();
            $table->timestamp('collected_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('emi_cycles'); }
};
