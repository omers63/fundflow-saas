<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('loans', function (Blueprint $table) {
            $table->id();
            $table->foreignId('member_id')->constrained('members')->cascadeOnDelete();
            $table->foreignId('guarantor_id')->constrained('members');
            $table->string('loan_number')->unique();
            $table->string('type')->default('standard');
            $table->string('status')->default('pending_admin');
            $table->decimal('requested_amount', 15, 2);
            $table->decimal('approved_amount', 15, 2)->nullable();
            $table->decimal('disbursed_amount', 15, 2)->default(0);
            $table->decimal('member_portion', 15, 2)->default(0);
            $table->decimal('master_portion', 15, 2)->default(0);
            $table->decimal('settlement_threshold', 15, 2)->nullable();
            $table->decimal('total_repaid', 15, 2)->default(0);
            $table->decimal('emi_amount', 15, 2)->nullable();
            $table->string('fund_tier')->nullable();
            $table->string('loan_tier')->nullable();
            $table->unsignedTinyInteger('grace_cycles')->default(0);
            $table->string('first_emi_cycle')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->timestamp('fully_disbursed_at')->nullable();
            $table->timestamp('overdue_since')->nullable();
            $table->timestamp('guarantor_notified_at')->nullable();
            $table->timestamp('transferred_at')->nullable();
            $table->text('admin_notes')->nullable();
            $table->text('rejection_reason')->nullable();
            $table->unsignedBigInteger('queue_position')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('loans'); }
};
