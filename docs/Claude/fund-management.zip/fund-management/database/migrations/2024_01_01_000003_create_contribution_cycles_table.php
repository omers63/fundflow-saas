<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('contribution_cycles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('member_id')->constrained('members')->cascadeOnDelete();
            $table->date('cycle_month');
            $table->decimal('due_amount', 15, 2)->default(0);
            $table->decimal('collected_amount', 15, 2)->default(0);
            $table->decimal('late_fee_amount', 15, 2)->default(0);
            $table->string('late_fee_tier')->nullable();
            $table->string('status')->default('pending');
            $table->timestamp('overdue_since')->nullable();
            $table->timestamp('collected_at')->nullable();
            $table->boolean('is_migration')->default(false);
            $table->string('origin')->default('live');
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('contribution_cycles'); }
};
