<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('recon_exceptions', function (Blueprint $table) {
            $table->id();
            $table->string('exception_type');
            $table->string('domain');
            $table->string('severity')->default('medium');
            $table->decimal('amount_delta', 15, 4)->default(0);
            $table->unsignedBigInteger('affected_member_id')->nullable();
            $table->unsignedBigInteger('affected_loan_id')->nullable();
            $table->unsignedBigInteger('affected_cycle_id')->nullable();
            $table->boolean('auto_resolve_attempted')->default(false);
            $table->string('auto_resolve_result')->nullable();
            $table->timestamp('raised_at');
            $table->timestamp('sla_deadline')->nullable();
            $table->unsignedBigInteger('assigned_to')->nullable();
            $table->string('resolution_action')->nullable();
            $table->text('resolution_notes')->nullable();
            $table->string('reason_code')->nullable();
            $table->timestamp('resolved_at')->nullable();
            $table->unsignedBigInteger('resolved_by')->nullable();
            $table->boolean('is_open')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('recon_exceptions'); }
};
