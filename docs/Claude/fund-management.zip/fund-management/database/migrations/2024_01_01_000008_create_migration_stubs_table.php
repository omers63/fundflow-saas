<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('migration_stubs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('member_id')->constrained('members')->cascadeOnDelete();
            $table->date('cycle_date');
            $table->decimal('amount_due', 15, 2)->default(0);
            $table->string('classification')->default('unresolved');
            $table->string('resolution_method')->nullable();
            $table->unsignedBigInteger('classified_by')->nullable();
            $table->timestamp('classified_at')->nullable();
            $table->string('status')->default('open');
            $table->text('notes')->nullable();
            $table->string('evidence_ref')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('migration_stubs'); }
};
