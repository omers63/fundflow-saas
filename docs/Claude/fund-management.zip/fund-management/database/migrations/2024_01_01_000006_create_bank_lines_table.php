<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('bank_lines', function (Blueprint $table) {
            $table->id();
            $table->string('bank_reference')->nullable();
            $table->date('import_date');
            $table->decimal('amount', 15, 2);
            $table->text('description')->nullable();
            $table->string('status')->default('pending_clearance');
            $table->unsignedBigInteger('matched_member_id')->nullable();
            $table->unsignedBigInteger('matched_transaction_id')->nullable();
            $table->timestamp('matched_at')->nullable();
            $table->decimal('adjustment_amount', 15, 2)->default(0);
            $table->text('notes')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('bank_lines'); }
};
