<x-filament-panels::page>
    @php $checks = $this->getEligibilityChecks(); $allPass = collect($checks)->every(fn($c)=>$c['pass']); @endphp
    @if(!$allPass)
    <div class="flex items-start gap-2 p-3 mb-4 rounded-lg bg-danger-50 border border-danger-200 text-danger-700 text-sm">
        <x-heroicon-o-exclamation-circle class="w-4 h-4 mt-0.5 flex-shrink-0"/>
        <span>Some eligibility checks failed. Admin override may be required.</span>
    </div>
    @else
    <div class="flex items-start gap-2 p-3 mb-4 rounded-lg bg-success-50 border border-success-200 text-success-700 text-sm">
        <x-heroicon-o-check-circle class="w-4 h-4 mt-0.5 flex-shrink-0"/>
        <span>All eligibility checks passed. You may proceed with your loan request.</span>
    </div>
    @endif
    <x-filament::section heading="Eligibility checks" class="mb-4">
        <div class="divide-y divide-gray-100">
            @foreach($checks as $check)
            <div class="flex items-center gap-3 py-2 text-sm">
                @if($check['pass'])
                    <x-heroicon-o-check-circle class="w-4 h-4 text-success-500 flex-shrink-0"/>
                @else
                    <x-heroicon-o-x-circle class="w-4 h-4 text-danger-500 flex-shrink-0"/>
                @endif
                <span class="flex-1 font-medium">{{ $check['label'] }}</span>
                <span class="text-gray-400 text-xs">{{ $check['detail'] }}</span>
            </div>
            @endforeach
        </div>
    </x-filament::section>
    <form wire:submit="submit">
        {{ $this->form }}
        <div class="flex justify-end mt-4">
            <x-filament::button type="submit" icon="heroicon-m-paper-airplane" :disabled="!$allPass">
                Submit loan request
            </x-filament::button>
        </div>
    </form>
</x-filament-panels::page>
