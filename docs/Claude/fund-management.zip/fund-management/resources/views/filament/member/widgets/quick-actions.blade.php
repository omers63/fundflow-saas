<x-filament-widgets::widget>
    <x-filament::section heading="Quick actions">
        @php
            $member = auth()->user();
            $actions = [
                ['icon'=>'heroicon-o-arrow-down-left','color'=>'text-success-600','bg'=>'bg-success-50','title'=>'Deposit funds','sub'=>'Bank transfer or direct cash','route'=>'filament.member.pages.cash-account'],
                ['icon'=>'heroicon-o-document-text','color'=>'text-primary-600','bg'=>'bg-primary-50','title'=>'Request a loan','sub'=>'Max eligible: SAR '.number_format($member->borrow_cap,0),'route'=>'filament.member.pages.loan-request'],
                ['icon'=>'heroicon-o-banknotes','color'=>'text-info-600','bg'=>'bg-info-50','title'=>'Cash out','sub'=>'Available: SAR '.number_format($member->cash_balance,0),'route'=>'filament.member.pages.cash-out'],
                ['icon'=>'heroicon-o-arrow-down-tray','color'=>'text-warning-600','bg'=>'bg-warning-50','title'=>'Download statement','sub'=>'Cash, fund, or loan history','route'=>'filament.member.pages.statements'],
            ];
        @endphp
        <div class="space-y-2">
            @foreach($actions as $a)
            <a href="{{ route($a['route']) }}" class="flex items-center gap-3 p-2.5 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                <div class="w-8 h-8 rounded-lg {{ $a['bg'] }} flex items-center justify-center flex-shrink-0">
                    <x-dynamic-component :component="$a['icon']" class="w-4 h-4 {{ $a['color'] }}" />
                </div>
                <div class="flex-1 min-w-0">
                    <div class="text-sm font-medium">{{ $a['title'] }}</div>
                    <div class="text-xs text-gray-500">{{ $a['sub'] }}</div>
                </div>
                <x-heroicon-m-chevron-right class="w-4 h-4 text-gray-400" />
            </a>
            @endforeach
        </div>
    </x-filament::section>
</x-filament-widgets::widget>
