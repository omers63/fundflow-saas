<x-filament-panels::page>
    <x-filament::section heading="Frequently asked questions">
        @php
        $faqs = [
            ['q'=>'When is my contribution collected?','a'=>'Your contribution is auto-debited from your cash account on Day 1 of the collection window each month. If your balance is insufficient, a partial debit is posted and the remainder is collected when funds arrive. The window stays open for a configurable number of days before late fees begin.'],
            ['q'=>'Why am I exempt from contributions?','a'=>'Members with an active loan — including those in a grace period — are automatically exempt from the monthly contribution. This prevents double-charging. The exemption lifts in the cycle after your loan is fully repaid.'],
            ['q'=>'How is my loan repayment threshold calculated?','a'=>'Your loan is fully repaid when the master fund portion plus a settlement threshold percentage (configured by the fund administrator) of the original loan amount has been repaid. You can see your specific threshold on the My Loans page.'],
            ['q'=>'What happens if I miss EMI payments?','a'=>'Missed EMIs follow the same late fee tiers as contributions. After a configured number of consecutive missed EMIs, your guarantor is formally notified. After a further threshold, the loan is transferred to your guarantor and your account is suspended.'],
            ['q'=>'How do I partially settle my loan?','a'=>'Go to My Loans and use the Settle action. Enter a partial amount (minimum 1 EMI) and choose whether to roll up your schedule (shortening it) or skip upcoming cycles (giving you a gap before EMIs resume).'],
            ['q'=>'How do I add funds to my cash account?','a'=>'Go to Cash Account and use the Deposit form. You can deposit via bank transfer (IBAN) or direct cash. Bank transfers are credited once the bank import is matched — typically within 1–2 business days.'],
            ['q'=>'What is my guarantor responsible for?','a'=>'Your guarantor is responsible for the master fund portion of your loan plus the settlement threshold percentage, if you miss the configured number of consecutive EMI payments. Their liability does not include your own fund equity portion.'],
            ['q'=>'How do I request a cash out?','a'=>'Go to Cash Out. You can withdraw up to your available balance (cash balance minus any reserved EMI). Withdrawals are processed within 1–2 business days to your registered IBAN.'],
        ];
        @endphp
        <div class="divide-y divide-gray-100" x-data="{open:null}">
            @foreach($faqs as $i => $faq)
            <div class="py-3">
                <button type="button" @click="open = open === {{ $i }} ? null : {{ $i }}"
                    class="flex justify-between items-center w-full text-left text-sm font-medium focus:outline-none">
                    <span>{{ $faq['q'] }}</span>
                    <x-heroicon-m-chevron-down class="w-4 h-4 text-gray-400 transition-transform" x-bind:class="open === {{ $i }} ? 'rotate-180' : ''" />
                </button>
                <div x-show="open === {{ $i }}" x-cloak class="mt-2 text-sm text-gray-500 leading-relaxed">
                    {{ $faq['a'] }}
                </div>
            </div>
            @endforeach
        </div>
    </x-filament::section>
</x-filament-panels::page>
