<x-filament-panels::page>
    <form wire:submit="save">
        {{ $this->form }}
        <div class="flex justify-end mt-4">
            <x-filament::button type="submit" icon="heroicon-m-check">Save settings</x-filament::button>
        </div>
    </form>
</x-filament-panels::page>
