<x-filament-panels::page>
    <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <x-filament::section heading="Generate statement">
            <form wire:submit="generate">
                {{ $this->form }}
                <div class="flex justify-end mt-3">
                    <x-filament::button type="submit" icon="heroicon-m-arrow-down-tray">Download statement</x-filament::button>
                </div>
            </form>
        </x-filament::section>
        <x-filament::section heading="Recent statements">
            <table class="w-full text-sm">
                <thead class="text-xs text-gray-400 border-b border-gray-100">
                    <tr><th class="p-2 text-left">Statement</th><th class="p-2 text-left">Period</th><th class="p-2"></th></tr>
                </thead>
                <tbody>
                    @foreach([['Combined — Q1 2026','Jan–Mar 2026'],['Loan schedule','All time'],['Combined — 2025','Full year 2025']] as [$name,$period])
                    <tr class="border-b border-gray-50">
                        <td class="p-2">{{ $name }}</td>
                        <td class="p-2 text-gray-400 text-xs">{{ $period }}</td>
                        <td class="p-2 text-right"><x-filament::button size="xs" color="gray" icon="heroicon-m-arrow-down-tray">PDF</x-filament::button></td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </x-filament::section>
    </div>
</x-filament-panels::page>
