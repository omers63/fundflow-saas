<x-filament-panels::page>
    @php $stats = $this->getStats(); @endphp
    <div class="grid grid-cols-3 gap-4 mb-6">
        <x-filament::section><div class="text-xs text-gray-400">Total contributed</div><div class="text-xl font-semibold">SAR {{ number_format($stats['total'],2) }}</div></x-filament::section>
        <x-filament::section><div class="text-xs text-gray-400">Cycles missed</div><div class="text-xl font-semibold text-danger-600">{{ $stats['missed'] }}</div></x-filament::section>
        <x-filament::section><div class="text-xs text-gray-400">Cycles exempt</div><div class="text-xl font-semibold text-gray-500">{{ $stats['exempt'] }}</div></x-filament::section>
    </div>
    {{ $this->table }}
</x-filament-panels::page>
