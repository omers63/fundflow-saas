<x-filament-panels::page>
    @foreach($this->getActiveLoans() as $loan)
    <x-filament::section heading="Loan {{ $loan->loan_number }}" class="mb-4">
        <div class="flex justify-between items-baseline mb-2">
            <span class="text-2xl font-semibold">SAR {{ number_format($loan->requested_amount,2) }}</span>
            <span class="text-xs text-gray-500">{{ $loan->emiCycles->where('status','collected')->count() }} of {{ $loan->emiCycles->count() }} EMIs · EMI: SAR {{ number_format($loan->emi_amount,2) }}</span>
        </div>
        <div class="w-full bg-gray-100 rounded-full h-2 mb-1">
            <div class="bg-success-500 h-2 rounded-full" style="width:{{ $loan->repaid_percent }}%"></div>
        </div>
        <div class="flex justify-between text-xs text-gray-400 mb-4">
            <span>SAR {{ number_format($loan->total_repaid,2) }} repaid</span>
            <span>SAR {{ number_format($loan->remaining_threshold,2) }} remaining to threshold</span>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4 text-sm">
            <div class="bg-gray-50 p-2 rounded-lg"><div class="text-xs text-gray-400">Threshold</div><div class="font-medium">SAR {{ number_format($loan->settlement_threshold,2) }}</div></div>
            <div class="bg-gray-50 p-2 rounded-lg"><div class="text-xs text-gray-400">Guarantor</div><div class="font-medium">{{ $loan->guarantor?->name ?? '—' }}</div></div>
            <div class="bg-gray-50 p-2 rounded-lg"><div class="text-xs text-gray-400">Fund tier</div><div class="font-medium">{{ strtoupper($loan->fund_tier ?? '—') }}</div></div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-xs">
                <thead class="bg-gray-50 text-gray-400"><tr><th class="p-2 text-left">Cycle</th><th class="p-2 text-left">Due</th><th class="p-2 text-left">Status</th><th class="p-2 text-left">Collected</th></tr></thead>
                <tbody>
                @foreach($loan->emiCycles->sortBy('cycle_number')->take(10) as $emi)
                <tr class="border-t border-gray-100">
                    <td class="p-2">{{ \Carbon\Carbon::parse($emi->cycle_month)->format('M Y') }}</td>
                    <td class="p-2">{{ number_format($emi->emi_due,0) }}</td>
                    <td class="p-2"><span class="px-1.5 py-0.5 rounded text-xs font-medium {{ match($emi->status) { 'collected'=>'bg-success-100 text-success-700', 'pending'=>'bg-info-100 text-info-700', 'overdue'=>'bg-warning-100 text-warning-700', default=>'bg-gray-100 text-gray-600' } }}">{{ ucfirst($emi->status) }}</span></td>
                    <td class="p-2">{{ $emi->emi_collected > 0 ? number_format($emi->emi_collected,0) : '—' }}</td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </x-filament::section>
    @endforeach
    <x-filament::section heading="Loan history">{{ $this->table }}</x-filament::section>
</x-filament-panels::page>
