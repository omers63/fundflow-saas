<x-filament-panels::page>
    @php $member = auth()->user(); $config = \App\Models\SystemConfig::current(); @endphp
    <x-filament::section class="mb-6" style="background:linear-gradient(135deg,#EEEDFE,#DDD9FC)">
        <div class="text-3xl font-semibold text-primary-700">SAR {{ number_format($member->fund_balance, 2) }}</div>
        <div class="text-sm text-primary-600 mt-1">Accumulated since {{ $member->join_date->format('M Y') }}</div>
        <div class="grid grid-cols-2 gap-4 mt-4 border-t border-primary-200 pt-4 text-sm">
            <div><div class="text-xs text-primary-500">Monthly contribution</div><div class="font-medium text-primary-800">SAR 500 / cycle</div></div>
            <div><div class="text-xs text-primary-500">Borrow multiplier</div><div class="font-medium text-primary-800">×{{ $config->borrow_multiplier }} → max SAR {{ number_format($member->borrow_cap,0) }}</div></div>
            <div><div class="text-xs text-primary-500">Contribution status</div>
                <div>@if($member->hasActiveLoan())<span class="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">Exempt (active loan)</span>@else<span class="text-xs bg-success-100 text-success-700 px-2 py-0.5 rounded-full">Active</span>@endif</div>
            </div>
            <div><div class="text-xs text-primary-500">Total contributions</div><div class="font-medium text-primary-800">SAR {{ number_format($member->fund_balance,2) }}</div></div>
        </div>
    </x-filament::section>
    <x-filament::section heading="Fund account history">{{ $this->table }}</x-filament::section>
</x-filament-panels::page>
