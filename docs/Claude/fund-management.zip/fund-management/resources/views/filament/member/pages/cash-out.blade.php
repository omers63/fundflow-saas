<x-filament-panels::page>
    @php $member = auth()->user(); $available = $this->getAvailableBalance(); @endphp
    <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <x-filament::section heading="Cash out request">
            <div class="grid grid-cols-2 gap-3 mb-4 text-sm border-b border-gray-100 pb-4">
                <div><div class="text-xs text-gray-400">Cash balance</div><div class="font-medium">SAR {{ number_format($member->cash_balance,2) }}</div></div>
                <div><div class="text-xs text-gray-400">Reserved (EMI)</div><div class="font-medium text-warning-600">SAR {{ number_format($member->activeLoans->sum('emi_amount'),2) }}</div></div>
                <div><div class="text-xs text-gray-400">Available to withdraw</div><div class="font-semibold text-success-600">SAR {{ number_format($available,2) }}</div></div>
                <div><div class="text-xs text-gray-400">Processing time</div><div class="font-medium">1–2 business days</div></div>
            </div>
            <form wire:submit="submit">
                {{ $this->form }}
                <div class="flex justify-end mt-3">
                    <x-filament::button type="submit" icon="heroicon-m-arrow-up-right">Submit cash out</x-filament::button>
                </div>
            </form>
        </x-filament::section>
        <x-filament::section heading="Cash out history">
            <table class="w-full text-sm">
                <thead class="text-xs text-gray-400 border-b border-gray-100">
                    <tr><th class="p-2 text-left">Date</th><th class="p-2 text-left">Amount</th><th class="p-2 text-left">Status</th></tr>
                </thead>
                <tbody>
                @foreach(\App\Models\Transaction::where('member_id',auth()->id())->where('type','cash_out')->latest()->take(10)->get() as $t)
                <tr class="border-b border-gray-50">
                    <td class="p-2">{{ $t->effective_date->format('d M Y') }}</td>
                    <td class="p-2 text-danger-600">SAR {{ number_format($t->dr_amount,2) }}</td>
                    <td class="p-2"><span class="text-xs bg-success-100 text-success-700 px-2 py-0.5 rounded-full">Processed</span></td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </x-filament::section>
    </div>
</x-filament-panels::page>
