@php $loan = $this->getActiveLoan(); @endphp
<x-filament-widgets::widget>
    @if($loan)
    <x-filament::section heading="Active loan — {{ $loan->loan_number }}">
        @if($loan->emiCycles()->where('status','pending')->where('cycle_month','<=',now()->format('Y-m-01'))->exists())
        <div class="flex items-start gap-2 p-3 mb-4 rounded-lg bg-warning-50 border border-warning-200 text-warning-700 text-sm">
            <x-heroicon-o-clock class="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>EMI of <strong>SAR {{ number_format($loan->emi_amount,2) }}</strong> is due this cycle. Ensure your cash account is funded.</span>
        </div>
        @endif
        <div class="flex justify-between items-baseline mb-2">
            <span class="text-2xl font-semibold">SAR {{ number_format($loan->requested_amount,2) }}</span>
            <span class="text-xs text-gray-500">{{ $loan->emiCycles->where('status','collected')->count() }} of {{ $loan->emiCycles->count() }} EMIs</span>
        </div>
        <div class="w-full bg-gray-100 rounded-full h-2 mb-1">
            <div class="bg-success-500 h-2 rounded-full" style="width:{{ $loan->repaid_percent }}%"></div>
        </div>
        <div class="flex justify-between text-xs text-gray-500 mb-4">
            <span>SAR {{ number_format($loan->total_repaid,2) }} repaid</span>
            <span>SAR {{ number_format($loan->remaining_threshold,2) }} to threshold</span>
        </div>
        <div class="grid grid-cols-3 gap-3 mb-4">
            <div class="bg-gray-50 rounded-lg p-2 text-center">
                <div class="text-xs text-gray-500">Threshold</div>
                <div class="text-sm font-semibold">SAR {{ number_format($loan->settlement_threshold,2) }}</div>
            </div>
            <div class="bg-gray-50 rounded-lg p-2 text-center">
                <div class="text-xs text-gray-500">EMI</div>
                <div class="text-sm font-semibold">SAR {{ number_format($loan->emi_amount,2) }}</div>
            </div>
            <div class="bg-gray-50 rounded-lg p-2 text-center">
                <div class="text-xs text-gray-500">Guarantor</div>
                <div class="text-sm font-semibold">{{ $loan->guarantor?->name ?? '—' }}</div>
            </div>
        </div>
        <div class="flex gap-2">
            <a href="{{ route('filament.member.pages.my-loans') }}" class="flex-1 text-center text-xs py-2 px-3 rounded-lg border border-gray-200 hover:bg-gray-50">
                View schedule
            </a>
            <a href="{{ route('filament.member.pages.settle-loan', $loan) }}" class="flex-1 text-center text-xs py-2 px-3 rounded-lg border border-primary-300 text-primary-700 hover:bg-primary-50">
                Settle loan
            </a>
        </div>
    </x-filament::section>
    @else
    <x-filament::section heading="Loans">
        <div class="text-center py-6 text-gray-400">
            <x-heroicon-o-currency-dollar class="w-10 h-10 mx-auto mb-2" />
            <p class="text-sm">No active loans.</p>
            <a href="{{ route('filament.member.pages.loan-request') }}" class="text-sm text-primary-600 hover:underline mt-1 inline-block">
                Request a loan →
            </a>
        </div>
    </x-filament::section>
    @endif
</x-filament-widgets::widget>
