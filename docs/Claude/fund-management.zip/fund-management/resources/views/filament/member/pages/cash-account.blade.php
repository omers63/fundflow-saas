<x-filament-panels::page>
    @php $member = auth()->user(); @endphp
    <div class="grid grid-cols-1 gap-6 lg:grid-cols-2 mb-6">
        <x-filament::section heading="Cash account balance">
            <div class="text-3xl font-semibold">SAR {{ number_format($member->cash_balance, 2) }}</div>
            <div class="text-sm text-gray-500 mt-1">Available balance</div>
            <div class="grid grid-cols-2 gap-3 mt-4 border-t border-gray-100 pt-4 text-sm">
                <div><div class="text-xs text-gray-400">Pending clearance</div><div class="font-medium">SAR 0.00</div></div>
                <div><div class="text-xs text-gray-400">Reserved (next EMI)</div><div class="font-medium">SAR {{ number_format($member->activeLoans->first()?->emi_amount ?? 0, 2) }}</div></div>
            </div>
        </x-filament::section>
        <x-filament::section heading="Deposit funds">
            <x-filament::info-list>
                <x-filament::info-list.entry label="">
                    <x-slot:state>
                        <p class="text-sm text-info-700 bg-info-50 border border-info-200 rounded-lg p-2.5">
                            Direct cash deposits are credited immediately. Bank transfers are credited once the bank import is matched (typically 1–2 business days).
                        </p>
                    </x-slot:state>
                </x-filament::info-list.entry>
            </x-filament::info-list>
            <form wire:submit="deposit" class="mt-3">
                {{ $this->form }}
                <div class="flex justify-end mt-3">
                    <x-filament::button type="submit" icon="heroicon-m-check">Confirm deposit</x-filament::button>
                </div>
            </form>
        </x-filament::section>
    </div>
    <x-filament::section heading="Transaction history">
        {{ $this->table }}
    </x-filament::section>
</x-filament-panels::page>
