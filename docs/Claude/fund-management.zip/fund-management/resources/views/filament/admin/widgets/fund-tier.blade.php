@php $tiers = $this->getTierData(); @endphp
<x-filament-widgets::widget>
    <x-filament::section heading="Fund tier utilisation">
        <div class="space-y-3">
            @foreach($tiers as $key => $tier)
            @php
                $color = $tier['used_pct'] >= 85 ? 'bg-danger-500'
                       : ($tier['used_pct'] >= 60 ? 'bg-warning-400' : 'bg-success-500');
            @endphp
            <div>
                <div class="flex justify-between text-xs text-gray-500 mb-1">
                    <span>{{ $tier['label'] }}</span>
                    <span class="font-semibold">{{ $tier['used_pct'] }}% committed</span>
                </div>
                <div class="w-full bg-gray-100 rounded-full h-2">
                    <div class="{{ $color }} h-2 rounded-full transition-all" style="width:{{ $tier['used_pct'] }}%"></div>
                </div>
            </div>
            @endforeach
        </div>
    </x-filament::section>
</x-filament-widgets::widget>
