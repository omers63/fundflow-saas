<div class="space-y-2 p-4 text-sm">
    <div><strong>Event:</strong> {{ $record->event_type }}</div>
    <div><strong>Domain:</strong> {{ $record->domain }}</div>
    <div><strong>Description:</strong> {{ $record->description }}</div>
    <div><strong>Actor:</strong> {{ $record->actor_id ?? 'System' }}</div>
    <div><strong>Entity:</strong> {{ $record->entity_type }} #{{ $record->entity_id }}</div>
    @if($record->meta)
    <div><strong>Meta:</strong><pre class="mt-1 text-xs bg-gray-100 p-2 rounded">{{ json_encode($record->meta, JSON_PRETTY_PRINT) }}</pre></div>
    @endif
</div>
