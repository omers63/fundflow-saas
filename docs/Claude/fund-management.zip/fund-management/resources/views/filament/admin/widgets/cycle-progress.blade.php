@php $stats = $this->getCycleStats(); @endphp
<x-filament-widgets::widget>
    <x-filament::section heading="Cycle collection progress — {{ now()->format('M Y') }}">
        <div class="grid grid-cols-1 gap-4 sm:grid-cols-4">
            @foreach([['label'=>'Collected','pct'=>$stats['collected'],'color'=>'bg-success-500'],['label'=>'Partially due','pct'=>$stats['partial'],'color'=>'bg-warning-400'],['label'=>'Overdue','pct'=>$stats['overdue'],'color'=>'bg-danger-500'],['label'=>'Exempt','pct'=>$stats['exempt'],'color'=>'bg-gray-300']] as $item)
            <div>
                <div class="flex justify-between text-xs text-gray-500 mb-1">
                    <span>{{ $item['label'] }}</span><span class="font-semibold">{{ $item['pct'] }}%</span>
                </div>
                <div class="w-full bg-gray-100 rounded-full h-2">
                    <div class="{{ $item['color'] }} h-2 rounded-full" style="width:{{ $item['pct'] }}%"></div>
                </div>
            </div>
            @endforeach
        </div>
        <div class="mt-4 grid grid-cols-3 gap-3 border-t border-gray-100 pt-4">
            @foreach([['label'=>'Late Tier 1 (day 3+)', 'count'=>$stats['tier1'], 'color'=>'text-warning-600'],['label'=>'Late Tier 2 (day 10+)', 'count'=>$stats['tier2'], 'color'=>'text-danger-500'],['label'=>'Late Tier 3 (day 20+)', 'count'=>$stats['tier3'], 'color'=>'text-danger-700']] as $t)
            <div class="text-center">
                <div class="text-xl font-semibold {{ $t['color'] }}">{{ $t['count'] }}</div>
                <div class="text-xs text-gray-500">{{ $t['label'] }}</div>
            </div>
            @endforeach
        </div>
    </x-filament::section>
</x-filament-widgets::widget>
