<x-filament-panels::page>
    <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {{-- Standard Reports --}}
        <x-filament::section heading="Standard Reports">
            @php
                $reports = [
                    ['icon'=>'heroicon-o-calendar-days', 'color'=>'text-success-600', 'bg'=>'bg-success-50', 'title'=>'Monthly collection report', 'desc'=>'Per-member collection status, fees, exemptions'],
                    ['icon'=>'heroicon-o-currency-dollar', 'color'=>'text-primary-600', 'bg'=>'bg-primary-50', 'title'=>'Loan portfolio report', 'desc'=>'Active, repaid, delinquent loans — all tiers'],
                    ['icon'=>'heroicon-o-arrows-right-left', 'color'=>'text-warning-600', 'bg'=>'bg-warning-50', 'title'=>'Reconciliation summary', 'desc'=>'Exceptions, resolutions, auto-resolve log'],
                    ['icon'=>'heroicon-o-chart-bar', 'color'=>'text-info-600', 'bg'=>'bg-info-50', 'title'=>'Fund tier utilisation', 'desc'=>'Availability, committed, disbursed per tier'],
                ];
            @endphp
            @foreach($reports as $r)
            <div class="flex items-center gap-3 p-3 border border-gray-200 rounded-xl mb-2 hover:bg-gray-50">
                <div class="flex-shrink-0 w-9 h-9 rounded-lg {{ $r['bg'] }} flex items-center justify-center">
                    <x-dynamic-component :component="$r['icon']" class="w-5 h-5 {{ $r['color'] }}" />
                </div>
                <div class="flex-1 min-w-0">
                    <div class="text-sm font-medium">{{ $r['title'] }}</div>
                    <div class="text-xs text-gray-500">{{ $r['desc'] }}</div>
                </div>
                <x-filament::button size="sm" color="gray" icon="heroicon-m-arrow-down-tray">
                    Download
                </x-filament::button>
            </div>
            @endforeach
        </x-filament::section>

        {{-- Custom Report Builder --}}
        <x-filament::section heading="Custom Report">
            <form wire:submit="generate">
                {{ $this->form }}
                <div class="mt-4 flex justify-end">
                    <x-filament::button type="submit" icon="heroicon-m-arrow-down-tray">
                        Generate report
                    </x-filament::button>
                </div>
            </form>
        </x-filament::section>
    </div>
</x-filament-panels::page>
