# Fund Management System — FilamentPHP v3 Project

A full-stack fund management system built on Laravel 11 + FilamentPHP v3,
covering dual portals (Admin + Member), contribution collection, loan lifecycle,
bank clearing, reconciliation, and migration workflows.

---

## Quick start

```bash
# 1. Install dependencies
composer install
npm install && npm run build

# 2. Environment setup
cp .env.example .env
php artisan key:generate

# 3. Database
touch database/database.sqlite
php artisan migrate
php artisan db:seed

# 4. Run
php artisan serve
```

## Default credentials

| Portal | URL | Email | Password |
|--------|-----|-------|----------|
| Admin  | /admin | admin@fundmanagement.com | password |
| Member | /portal | youssef@example.com | password |

---

## Portal structure

### Admin portal (`/admin`)

| Page | Path |
|------|------|
| Dashboard | `/admin` |
| Members | `/admin/members` |
| Loan queue | `/admin/loans` |
| Collection cycles | `/admin/cycles` |
| Disbursements | `/admin/disbursements` |
| Reconciliation | `/admin/recon-exceptions` |
| Bank clearing | `/admin/bank-lines` |
| Reports | `/admin/reports` |
| Migration | `/admin/migration-stubs` |
| Configuration | `/admin/configuration` |
| Audit log | `/admin/audit-log` |

### Member portal (`/portal`)

| Page | Path |
|------|------|
| Overview | `/portal` |
| Cash account | `/portal/cash-account` |
| Fund account | `/portal/fund-account` |
| My loans | `/portal/my-loans` |
| Request a loan | `/portal/loan-request` |
| Contributions | `/portal/contributions` |
| Transactions | `/portal/transactions` |
| Cash out | `/portal/cash-out` |
| Statements | `/portal/statements` |
| Settings | `/portal/settings` |
| Help & FAQ | `/portal/help` |

---

## Architecture

```
app/
├── Enums/                    # MemberStatus, LoanStatus, LoanType,
│                             # CycleStatus, ReconSeverity, BankLineStatus,
│                             # MigrationClassification
├── Models/                   # Member, Loan, ContributionCycle, EmiCycle,
│                             # Disbursement, BankLine, ReconException,
│                             # MigrationStub, Transaction, SystemConfig,
│                             # AuditLog, User
├── Services/
│   ├── CollectionService.php     # Debit batch, late fees, manual posting
│   ├── ReconciliationService.php # Nightly batch, master invariant, domain checks
│   └── BankClearingService.php   # Import, auto-match, clearing
├── Filament/
│   ├── Admin/
│   │   ├── AdminPanelProvider.php
│   │   ├── Pages/              # Dashboard, Reports, Configuration, AuditLog
│   │   ├── Resources/          # Member, Loan, Cycle, Disbursement,
│   │   │                       # BankClearing, Recon, Migration
│   │   └── Widgets/            # StatsOverview, LoanQueue, ReconAlerts,
│   │                           # CycleProgress, MemberActivity, FundTier
│   └── Member/
│       ├── MemberPanelProvider.php
│       ├── Pages/              # Dashboard, CashAccount, FundAccount,
│       │                       # MyLoans, LoanRequest, Contributions,
│       │                       # Transactions, CashOut, Statements,
│       │                       # Settings, Help
│       └── Widgets/            # AccountSummary, ActiveLoan,
│                               # QuickActions, RecentTransactions
database/
├── migrations/                 # All 12 migration files
└── seeders/                    # SystemConfig, Admin, Members, Loans,
                                # Cycles, BankLines, ReconExceptions
```

## Key business rules implemented

- **Contribution exemption**: Members with active loans are automatically skipped in the debit batch.
- **Loan queue ordering**: Emergency requests jump to the front; standard requests are FIFO.
- **Late fee tiers**: Nightly job applies tiered fees (replacement or cumulative model) based on `overdue_since`.
- **Loan activation gate**: Repayment schedule only builds after full disbursement (`disbursed_amount >= approved_amount`).
- **Migration stub generation**: Stubs created as `UNRESOLVED` (never `MISSED`) — late fee engine suppressed.
- **Master account invariant**: Recon batch asserts `Master Fund = Σ member funds` before any posting.
- **Guarantor escalation**: Auto-transfer and member suspension after Y missed EMIs.
- **Reconciliation severity SLAs**: Critical = immediate (batch halted), High = same day, Medium = 48h, Low = next cycle.

## Scheduled jobs

| Job | Schedule |
|-----|----------|
| Nightly recon batch | Daily at 00:01 |
| Late fee application | Daily at 01:00 |
| Bank auto-match | Every 30 minutes |
